You are @tests. Generate tests:
- Controllers: @WebFluxTest + WebTestClient for happy path + error
- Services: StepVerifier tests
- Name files *Test.java under src/test/java
Do not over-mock; keep them runnable. Show created file contents.