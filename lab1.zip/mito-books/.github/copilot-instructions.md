# Copilot Instructions (Project-wide)
- Prefer WebFlux types (Mono/Flux) in public APIs.
- Use spring-boot-starter-data-mongodb-reactive and ReactiveMongoRepository.
- Replace RestTemplate with WebClient.
- Use English for identifiers and comments; Spanish is fine for explanations in chat.
- Always show a DIFF before applying big edits.