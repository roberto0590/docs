package com.mitocode.controller;

import com.mitocode.dto.CategoryDTO;
import com.mitocode.dto.GenericResponse;
import com.mitocode.model.Category;
import com.mitocode.service.ICategoryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.util.Arrays;

@Slf4j
@RestController
@RequestMapping("/categories")
@RequiredArgsConstructor
public class CategoryController {

    private final ICategoryService service;
    @Qualifier("defaultMapper")
    private final ModelMapper modelMapper;

    @GetMapping
    public Mono<ResponseEntity<GenericResponse<CategoryDTO>>> getAllCategories() {
        log.info("Getting all categories");
        return service.findAll()
                .map(this::convertToDto)
                .collectList()
                .map(list -> ResponseEntity.ok(new GenericResponse<>(200, "success", list)));
    }

    @GetMapping("/{id}")
    public Mono<ResponseEntity<GenericResponse<CategoryDTO>>> getCategoryById(@PathVariable("id") String id) {
        log.info("Getting category by id: {}", id);
        return service.findById(id)
                .map(this::convertToDto)
                .map(dto -> ResponseEntity.ok(new GenericResponse<>(200, "success", Arrays.asList(dto))));
    }

    @PostMapping
    public Mono<ResponseEntity<Void>> save(@RequestBody CategoryDTO dto) {
        log.info("Creating new category: {}", dto.getCategoryName());
        return service.save(convertToEntity(dto))
                .map(savedCategory -> {
                    URI location = URI.create("/categories/" + savedCategory.getIdCategory());
                    return ResponseEntity.created(location).<Void>build();
                });
    }

    @PutMapping("/{id}")
    public Mono<ResponseEntity<GenericResponse<CategoryDTO>>> update(@PathVariable("id") String id, @RequestBody CategoryDTO dto) {
        log.info("Updating category with id: {}", id);
        return service.update(id, convertToEntity(dto))
                .map(this::convertToDto)
                .map(updatedDto -> ResponseEntity.ok(new GenericResponse<>(200, "success", Arrays.asList(updatedDto))));
    }

    @DeleteMapping("/{id}")
    public Mono<ResponseEntity<Void>> delete(@PathVariable("id") String id) {
        log.info("Deleting category with id: {}", id);
        return service.delete(id)
                .then(Mono.fromCallable(() -> ResponseEntity.noContent().<Void>build()));
    }

    private CategoryDTO convertToDto(Category obj) {
        return modelMapper.map(obj, CategoryDTO.class);
    }

    private Category convertToEntity(CategoryDTO dto) {
        return modelMapper.map(dto, Category.class);
    }

}
