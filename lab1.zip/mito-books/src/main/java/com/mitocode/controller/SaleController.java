package com.mitocode.controller;

import com.mitocode.dto.GenericResponse;
import com.mitocode.dto.SaleDTO;
import com.mitocode.model.Sale;
import com.mitocode.service.ISaleService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.util.Arrays;

@Slf4j
@RestController
@RequestMapping("/sales")
@RequiredArgsConstructor
public class SaleController {

    private final ISaleService service;
    @Qualifier("saleMapper")
    private final ModelMapper modelMapper;

    @GetMapping
    public Mono<ResponseEntity<GenericResponse<SaleDTO>>> getAllSales() {
        log.info("Getting all sales");
        return service.findAll()
                .map(this::convertToDto)
                .collectList()
                .map(list -> ResponseEntity.ok(new GenericResponse<>(200, "success", list)));
    }

    @GetMapping("/{id}")
    public Mono<ResponseEntity<GenericResponse<SaleDTO>>> getSaleById(@PathVariable("id") String id) {
        log.info("Getting sale by id: {}", id);
        return service.findById(id)
                .map(this::convertToDto)
                .map(dto -> ResponseEntity.ok(new GenericResponse<>(200, "success", Arrays.asList(dto))));
    }

    @PostMapping
    public Mono<ResponseEntity<Void>> save(@Valid @RequestBody SaleDTO dto) {
        log.info("Creating new sale for client: {}", dto.getClient() != null ? dto.getClient().getFirstName() : "unknown");
        return service.save(convertToEntity(dto))
                .map(savedSale -> {
                    URI location = URI.create("/sales/" + savedSale.getIdSale());
                    return ResponseEntity.created(location).<Void>build();
                });
    }

    @PutMapping("/{id}")
    public Mono<ResponseEntity<GenericResponse<SaleDTO>>> update(@PathVariable("id") String id, @Valid @RequestBody SaleDTO dto) {
        log.info("Updating sale with id: {}", id);
        return service.update(id, convertToEntity(dto))
                .map(this::convertToDto)
                .map(updatedDto -> ResponseEntity.ok(new GenericResponse<>(200, "success", Arrays.asList(updatedDto))));
    }

    @DeleteMapping("/{id}")
    public Mono<ResponseEntity<Void>> delete(@PathVariable("id") String id) {
        log.info("Deleting sale with id: {}", id);
        return service.delete(id)
                .then(Mono.fromCallable(() -> ResponseEntity.noContent().<Void>build()));
    }

    private SaleDTO convertToDto(Sale obj) {
        return modelMapper.map(obj, SaleDTO.class);
    }

    private Sale convertToEntity(SaleDTO dto) {
        return modelMapper.map(dto, Sale.class);
    }

}
