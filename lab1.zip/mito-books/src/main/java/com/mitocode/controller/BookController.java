package com.mitocode.controller;

import com.mitocode.dto.BookDTO;
import com.mitocode.dto.GenericResponse;
import com.mitocode.model.Book;
import com.mitocode.service.IBookService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.util.Arrays;

@Slf4j
@RestController
@RequestMapping("/books")
@RequiredArgsConstructor
public class BookController {

    private final IBookService service;

    @Qualifier("defaultMapper")
    private final ModelMapper modelMapper;

    @GetMapping
    public Mono<ResponseEntity<GenericResponse<BookDTO>>> getAllBooks() {
        log.info("Getting all books");
        return service.findAll()
                .map(this::convertToDto)
                .collectList()
                .map(list -> ResponseEntity.ok(new GenericResponse<>(200, "success", list)));
    }

    @GetMapping("/{id}")
    public Mono<ResponseEntity<GenericResponse<BookDTO>>> getBookById(@PathVariable("id") String id) {
        log.info("Getting book by id: {}", id);
        return service.findById(id)
                .map(this::convertToDto)
                .map(dto -> ResponseEntity.ok(new GenericResponse<>(200, "success", Arrays.asList(dto))));
    }

    @PostMapping
    public Mono<ResponseEntity<Void>> save(@Valid @RequestBody BookDTO dto) {
        log.info("Creating new book: {}", dto.getTitle());
        return service.save(convertToEntity(dto))
                .map(savedBook -> {
                    URI location = URI.create("/books/" + savedBook.getIdBook());
                    return ResponseEntity.created(location).<Void>build();
                });
    }

    @PutMapping("/{id}")
    public Mono<ResponseEntity<GenericResponse<BookDTO>>> update(@PathVariable("id") String id, @Valid @RequestBody BookDTO dto) {
        log.info("Updating book with id: {}", id);
        return service.update(id, convertToEntity(dto))
                .map(this::convertToDto)
                .map(updatedDto -> ResponseEntity.ok(new GenericResponse<>(200, "success", Arrays.asList(updatedDto))));
    }

    @DeleteMapping("/{id}")
    public Mono<ResponseEntity<Void>> delete(@PathVariable("id") String id) {
        log.info("Deleting book with id: {}", id);
        return service.delete(id)
                .then(Mono.fromCallable(() -> ResponseEntity.noContent().<Void>build()));
    }

    @GetMapping("/byCategory")
    public Mono<ResponseEntity<GenericResponse<BookDTO>>> getBooksByCategory(@RequestParam("category") String category) {
        log.info("Getting books by category: {}", category);
        return service.getBooksByCategory(category)
                .map(this::convertToDto)
                .collectList()
                .map(books -> ResponseEntity.ok(new GenericResponse<>(200, "success", books)));
    }

    private BookDTO convertToDto(Book obj) {
        return modelMapper.map(obj, BookDTO.class);
    }

    private Book convertToEntity(BookDTO dto) {
        return modelMapper.map(dto, Book.class);
    }

}
