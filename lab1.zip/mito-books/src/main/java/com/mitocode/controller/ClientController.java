package com.mitocode.controller;

import com.mitocode.dto.ClientDTO;
import com.mitocode.dto.GenericResponse;
import com.mitocode.model.Client;
import com.mitocode.service.IClientService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.util.Arrays;

@Slf4j
@RestController
@RequestMapping("/clients")
@RequiredArgsConstructor
public class ClientController {

    private final IClientService service;
    @Qualifier("clientMapper")
    private final ModelMapper modelMapper;

    @GetMapping
    public Mono<ResponseEntity<GenericResponse<ClientDTO>>> getAllClients() {
        log.info("Getting all clients");
        return service.findAll()
                .map(this::convertToDto)
                .collectList()
                .map(list -> ResponseEntity.ok(new GenericResponse<>(200, "success", list)));
    }

    @GetMapping("/{id}")
    public Mono<ResponseEntity<GenericResponse<ClientDTO>>> getClientById(@PathVariable("id") String id) {
        log.info("Getting client by id: {}", id);
        return service.findById(id)
                .map(this::convertToDto)
                .map(dto -> ResponseEntity.ok(new GenericResponse<>(200, "success", Arrays.asList(dto))));
    }

    @PostMapping
    public Mono<ResponseEntity<Void>> save(@Valid @RequestBody ClientDTO dto) {
        log.info("Creating new client: {}", dto.getFirstName());
        return service.save(convertToEntity(dto))
                .map(savedClient -> {
                    URI location = URI.create("/clients/" + savedClient.getIdClient());
                    return ResponseEntity.created(location).<Void>build();
                });
    }

    @PutMapping("/{id}")
    public Mono<ResponseEntity<GenericResponse<ClientDTO>>> update(@PathVariable("id") String id, @Valid @RequestBody ClientDTO dto) {
        log.info("Updating client with id: {}", id);
        return service.update(id, convertToEntity(dto))
                .map(this::convertToDto)
                .map(updatedDto -> ResponseEntity.ok(new GenericResponse<>(200, "success", Arrays.asList(updatedDto))));
    }

    @DeleteMapping("/{id}")
    public Mono<ResponseEntity<Void>> delete(@PathVariable("id") String id) {
        log.info("Deleting client with id: {}", id);
        return service.delete(id)
                .then(Mono.fromCallable(() -> ResponseEntity.noContent().<Void>build()));
    }

    private ClientDTO convertToDto(Client obj) {
        return modelMapper.map(obj, ClientDTO.class);
    }

    private Client convertToEntity(ClientDTO dto) {
        return modelMapper.map(dto, Client.class);
    }

}
