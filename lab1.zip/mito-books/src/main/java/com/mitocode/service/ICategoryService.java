package com.mitocode.service;

import com.mitocode.model.Category;


public interface ICategoryService extends ICRUD<Category, String> {

}
