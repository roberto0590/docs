package com.mitocode.repo;

import com.mitocode.model.Category;

public interface ICategoryRepo extends IGenericRepo<Category, String> {

}

