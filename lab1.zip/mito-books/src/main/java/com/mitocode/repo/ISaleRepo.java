package com.mitocode.repo;

import com.mitocode.model.Sale;

public interface ISaleRepo extends IGenericRepo<Sale, String> {


}
