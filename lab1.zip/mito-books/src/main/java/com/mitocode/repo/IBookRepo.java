package com.mitocode.repo;

import com.mitocode.model.Book;
import reactor.core.publisher.Flux;

public interface IBookRepo extends IGenericRepo<Book, String> {

    // Derived query method for MongoDB - finds books by category name
    Flux<Book> findByCategoryNameContainingIgnoreCase(String name);
}
