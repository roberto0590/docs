package com.mitocode.model;

import org.springframework.data.mongodb.core.mapping.DBRef;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SaleDetail {

    @DBRef
    private Book book;

    private double unitPrice;

    private short quantity;

    private boolean status;
}
