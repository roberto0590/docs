package com.mitocode.controller;

import com.mitocode.dto.BookDTO;
import com.mitocode.model.Book;
import com.mitocode.model.Category;
import com.mitocode.service.IBookService;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@WebFluxTest(BookController.class)
class BookControllerTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockBean
    private IBookService bookService;

    @MockBean
    private ModelMapper modelMapper;

    @Test
    void getAllBooks_ShouldReturnBooks() {
        // Given
        Category category = new Category("1", "Fiction", true);
        Book book = new Book("1", category, "Test Book", "123456789", "http://photo.url", true);
        BookDTO bookDTO = new BookDTO(1, 1, "Test Book", "123456789", "http://photo.url", true);
        
        when(bookService.findAll()).thenReturn(Flux.just(book));
        when(modelMapper.map(book, BookDTO.class)).thenReturn(bookDTO);

        // When & Then
        webTestClient.get()
                .uri("/books")
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.status").isEqualTo(200)
                .jsonPath("$.message").isEqualTo("success")
                .jsonPath("$.data[0].title").isEqualTo("Test Book");
    }

    @Test
    void getBookById_ShouldReturnBook() {
        // Given
        String bookId = "1";
        Category category = new Category("1", "Fiction", true);
        Book book = new Book(bookId, category, "Test Book", "123456789", "http://photo.url", true);
        BookDTO bookDTO = new BookDTO(1, 1, "Test Book", "123456789", "http://photo.url", true);
        
        when(bookService.findById(bookId)).thenReturn(Mono.just(book));
        when(modelMapper.map(book, BookDTO.class)).thenReturn(bookDTO);

        // When & Then
        webTestClient.get()
                .uri("/books/{id}", bookId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.status").isEqualTo(200)
                .jsonPath("$.data[0].title").isEqualTo("Test Book");
    }

    @Test
    void getBooksByCategory_ShouldReturnBooksFromCategory() {
        // Given
        String categoryName = "Fiction";
        Category category = new Category("1", "Fiction", true);
        Book book = new Book("1", category, "Fiction Book", "123456789", "http://photo.url", true);
        BookDTO bookDTO = new BookDTO(1, 1, "Fiction Book", "123456789", "http://photo.url", true);
        
        when(bookService.getBooksByCategory(categoryName)).thenReturn(Flux.just(book));
        when(modelMapper.map(book, BookDTO.class)).thenReturn(bookDTO);

        // When & Then
        webTestClient.get()
                .uri("/books/byCategory?category={category}", categoryName)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.status").isEqualTo(200)
                .jsonPath("$.data[0].title").isEqualTo("Fiction Book");
    }

    @Test
    void saveBook_ShouldReturnCreated() {
        // Given
        BookDTO bookDTO = new BookDTO(null, 1, "New Book", "987654321", "http://photo.url", true);
        Category category = new Category("1", "Fiction", true);
        Book book = new Book(null, category, "New Book", "987654321", "http://photo.url", true);
        Book savedBook = new Book("1", category, "New Book", "987654321", "http://photo.url", true);
        
        when(modelMapper.map(bookDTO, Book.class)).thenReturn(book);
        when(bookService.save(any(Book.class))).thenReturn(Mono.just(savedBook));

        // When & Then
        webTestClient.post()
                .uri("/books")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(bookDTO)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().location("/books/1");
    }

    @Test
    void deleteBook_ShouldReturnNoContent() {
        // Given
        String bookId = "1";
        when(bookService.delete(bookId)).thenReturn(Mono.empty());

        // When & Then
        webTestClient.delete()
                .uri("/books/{id}", bookId)
                .exchange()
                .expectStatus().isNoContent()
                .expectBody().isEmpty();
    }
}