package com.mitocode.controller;

import com.mitocode.dto.ClientDTO;
import com.mitocode.model.Client;
import com.mitocode.service.IClientService;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.time.LocalDate;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@WebFluxTest(ClientController.class)
class ClientControllerTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockBean
    private IClientService clientService;

    @MockBean
    private ModelMapper modelMapper;

    @Test
    void getAllClients_ShouldReturnClients() {
        // Given
        Client client = new Client("1", "John", "Doe", LocalDate.of(1990, 1, 1));
        ClientDTO clientDTO = new ClientDTO(1, "John", "Doe", LocalDate.of(1990, 1, 1));
        
        when(clientService.findAll()).thenReturn(Flux.just(client));
        when(modelMapper.map(client, ClientDTO.class)).thenReturn(clientDTO);

        // When & Then
        webTestClient.get()
                .uri("/clients")
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.status").isEqualTo(200)
                .jsonPath("$.message").isEqualTo("success")
                .jsonPath("$.data[0].firstName").isEqualTo("John");
    }

    @Test
    void getClientById_ShouldReturnClient() {
        // Given
        String clientId = "1";
        Client client = new Client(clientId, "John", "Doe", LocalDate.of(1990, 1, 1));
        ClientDTO clientDTO = new ClientDTO(1, "John", "Doe", LocalDate.of(1990, 1, 1));
        
        when(clientService.findById(clientId)).thenReturn(Mono.just(client));
        when(modelMapper.map(client, ClientDTO.class)).thenReturn(clientDTO);

        // When & Then
        webTestClient.get()
                .uri("/clients/{id}", clientId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.status").isEqualTo(200)
                .jsonPath("$.data[0].firstName").isEqualTo("John");
    }

    @Test
    void saveClient_ShouldReturnCreated_WhenValidData() {
        // Given
        ClientDTO clientDTO = new ClientDTO(null, "Jane", "Smith", LocalDate.of(1985, 5, 15));
        Client client = new Client(null, "Jane", "Smith", LocalDate.of(1985, 5, 15));
        Client savedClient = new Client("1", "Jane", "Smith", LocalDate.of(1985, 5, 15));
        
        when(modelMapper.map(clientDTO, Client.class)).thenReturn(client);
        when(clientService.save(any(Client.class))).thenReturn(Mono.just(savedClient));

        // When & Then
        webTestClient.post()
                .uri("/clients")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(clientDTO)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().location("/clients/1");
    }

    @Test
    void saveClient_ShouldReturnBadRequest_WhenInvalidData() {
        // Given - Invalid client with short name (less than 3 characters)
        ClientDTO invalidClientDTO = new ClientDTO(null, "Jo", "Doe", LocalDate.of(1990, 1, 1));

        // When & Then
        webTestClient.post()
                .uri("/clients")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(invalidClientDTO)
                .exchange()
                .expectStatus().isBadRequest();
    }

    @Test
    void updateClient_ShouldReturnUpdatedClient() {
        // Given
        String clientId = "1";
        ClientDTO clientDTO = new ClientDTO(1, "John", "Updated", LocalDate.of(1990, 1, 1));
        Client client = new Client(clientId, "John", "Updated", LocalDate.of(1990, 1, 1));
        Client updatedClient = new Client(clientId, "John", "Updated", LocalDate.of(1990, 1, 1));
        
        when(modelMapper.map(clientDTO, Client.class)).thenReturn(client);
        when(clientService.update(clientId, client)).thenReturn(Mono.just(updatedClient));
        when(modelMapper.map(updatedClient, ClientDTO.class)).thenReturn(clientDTO);

        // When & Then
        webTestClient.put()
                .uri("/clients/{id}", clientId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(clientDTO)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.status").isEqualTo(200)
                .jsonPath("$.data[0].surname").isEqualTo("Updated");
    }

    @Test
    void deleteClient_ShouldReturnNoContent() {
        // Given
        String clientId = "1";
        when(clientService.delete(clientId)).thenReturn(Mono.empty());

        // When & Then
        webTestClient.delete()
                .uri("/clients/{id}", clientId)
                .exchange()
                .expectStatus().isNoContent()
                .expectBody().isEmpty();
    }
}