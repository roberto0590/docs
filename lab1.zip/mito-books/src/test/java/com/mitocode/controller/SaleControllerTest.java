package com.mitocode.controller;

import com.mitocode.dto.SaleDTO;
import com.mitocode.model.Sale;
import com.mitocode.service.ISaleService;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@WebFluxTest(SaleController.class)
class SaleControllerTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockBean
    private ISaleService saleService;

    @MockBean
    private ModelMapper modelMapper;

    @Test
    void getAllSales_ShouldReturnSales() {
        // Given
        Sale sale = new Sale();
        sale.setIdSale("1");
        sale.setTotal(59.98);
        
        SaleDTO saleDTO = new SaleDTO();
        saleDTO.setIdSale(1);
        saleDTO.setTotalSale(59.98);
        
        when(saleService.findAll()).thenReturn(Flux.just(sale));
        when(modelMapper.map(sale, SaleDTO.class)).thenReturn(saleDTO);

        // When & Then
        webTestClient.get()
                .uri("/sales")
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.status").isEqualTo(200)
                .jsonPath("$.message").isEqualTo("success");
    }

    @Test
    void getSaleById_ShouldReturnSale() {
        // Given
        String saleId = "1";
        Sale sale = new Sale();
        sale.setIdSale(saleId);
        sale.setTotal(59.98);
        
        SaleDTO saleDTO = new SaleDTO();
        saleDTO.setIdSale(1);
        saleDTO.setTotalSale(59.98);
        
        when(saleService.findById(saleId)).thenReturn(Mono.just(sale));
        when(modelMapper.map(sale, SaleDTO.class)).thenReturn(saleDTO);

        // When & Then
        webTestClient.get()
                .uri("/sales/{id}", saleId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.status").isEqualTo(200);
    }

    @Test
    void deleteSale_ShouldReturnNoContent() {
        // Given
        String saleId = "1";
        when(saleService.delete(saleId)).thenReturn(Mono.empty());

        // When & Then
        webTestClient.delete()
                .uri("/sales/{id}", saleId)
                .exchange()
                .expectStatus().isNoContent()
                .expectBody().isEmpty();
    }
}