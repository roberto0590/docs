package com.mitocode.controller;

import com.mitocode.dto.CategoryDTO;
import com.mitocode.model.Category;
import com.mitocode.service.ICategoryService;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@WebFluxTest(CategoryController.class)
class CategoryControllerTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockBean
    private ICategoryService categoryService;

    @MockBean
    private ModelMapper modelMapper;

    @Test
    void getAllCategories_ShouldReturnCategories() {
        // Given
        Category category = new Category("1", "Fiction", true);
        CategoryDTO categoryDTO = new CategoryDTO(1, "Fiction", true);
        
        when(categoryService.findAll()).thenReturn(Flux.just(category));
        when(modelMapper.map(category, CategoryDTO.class)).thenReturn(categoryDTO);

        // When & Then
        webTestClient.get()
                .uri("/categories")
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.status").isEqualTo(200)
                .jsonPath("$.message").isEqualTo("success")
                .jsonPath("$.data[0].categoryName").isEqualTo("Fiction");
    }

    @Test
    void getCategoryById_ShouldReturnCategory() {
        // Given
        String categoryId = "1";
        Category category = new Category(categoryId, "Fiction", true);
        CategoryDTO categoryDTO = new CategoryDTO(1, "Fiction", true);
        
        when(categoryService.findById(categoryId)).thenReturn(Mono.just(category));
        when(modelMapper.map(category, CategoryDTO.class)).thenReturn(categoryDTO);

        // When & Then
        webTestClient.get()
                .uri("/categories/{id}", categoryId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.status").isEqualTo(200)
                .jsonPath("$.data[0].categoryName").isEqualTo("Fiction");
    }

    @Test
    void getCategoryById_ShouldReturn404WhenNotFound() {
        // Given
        String categoryId = "999";
        when(categoryService.findById(categoryId)).thenReturn(Mono.empty());

        // When & Then
        webTestClient.get()
                .uri("/categories/{id}", categoryId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .isEmpty();
    }

    @Test
    void saveCategory_ShouldReturnCreated() {
        // Given
        CategoryDTO categoryDTO = new CategoryDTO(null, "New Category", true);
        Category category = new Category(null, "New Category", true);
        Category savedCategory = new Category("1", "New Category", true);
        
        when(modelMapper.map(categoryDTO, Category.class)).thenReturn(category);
        when(categoryService.save(any(Category.class))).thenReturn(Mono.just(savedCategory));

        // When & Then
        webTestClient.post()
                .uri("/categories")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(categoryDTO)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().location("/categories/1");
    }

    @Test
    void updateCategory_ShouldReturnUpdatedCategory() {
        // Given
        String categoryId = "1";
        CategoryDTO categoryDTO = new CategoryDTO(1, "Updated Category", true);
        Category category = new Category(categoryId, "Updated Category", true);
        Category updatedCategory = new Category(categoryId, "Updated Category", true);
        
        when(modelMapper.map(categoryDTO, Category.class)).thenReturn(category);
        when(categoryService.update(anyString(), any(Category.class))).thenReturn(Mono.just(updatedCategory));
        when(modelMapper.map(updatedCategory, CategoryDTO.class)).thenReturn(categoryDTO);

        // When & Then
        webTestClient.put()
                .uri("/categories/{id}", categoryId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(categoryDTO)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.status").isEqualTo(200)
                .jsonPath("$.data[0].categoryName").isEqualTo("Updated Category");
    }

    @Test
    void deleteCategory_ShouldReturnNoContent() {
        // Given
        String categoryId = "1";
        when(categoryService.delete(categoryId)).thenReturn(Mono.empty());

        // When & Then
        webTestClient.delete()
                .uri("/categories/{id}", categoryId)
                .exchange()
                .expectStatus().isNoContent()
                .expectBody().isEmpty();
    }
}