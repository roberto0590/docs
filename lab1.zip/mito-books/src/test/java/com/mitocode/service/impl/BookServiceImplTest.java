package com.mitocode.service.impl;

import com.mitocode.model.Book;
import com.mitocode.model.Category;
import com.mitocode.repo.IBookRepo;
import com.mitocode.service.IBookService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BookServiceImplTest {

    @Mock
    private IBookRepo bookRepo;

    private IBookService bookService;

    @BeforeEach
    void setUp() {
        bookService = new BookServiceImpl(bookRepo);
    }

    @Test
    void findAll_ShouldReturnAllBooks() {
        // Given
        Category category = new Category("1", "Fiction", true);
        Book book1 = new Book("1", category, "Book 1", "123456789", "http://photo1.url", true);
        Book book2 = new Book("2", category, "Book 2", "987654321", "http://photo2.url", true);
        
        when(bookRepo.findAll()).thenReturn(Flux.just(book1, book2));

        // When & Then
        StepVerifier.create(bookService.findAll())
                .expectNext(book1)
                .expectNext(book2)
                .expectComplete()
                .verify();
    }

    @Test
    void findById_ShouldReturnBook_WhenExists() {
        // Given
        String bookId = "1";
        Category category = new Category("1", "Fiction", true);
        Book book = new Book(bookId, category, "Test Book", "123456789", "http://photo.url", true);
        
        when(bookRepo.findById(bookId)).thenReturn(Mono.just(book));

        // When & Then
        StepVerifier.create(bookService.findById(bookId))
                .expectNext(book)
                .expectComplete()
                .verify();
    }

    @Test
    void getBooksByCategory_ShouldReturnBooksFromCategory() {
        // Given
        String categoryName = "Fiction";
        Category category = new Category("1", "Fiction", true);
        Book book1 = new Book("1", category, "Fiction Book 1", "123456789", "http://photo1.url", true);
        Book book2 = new Book("2", category, "Fiction Book 2", "987654321", "http://photo2.url", true);
        
        when(bookRepo.findByCategoryNameContainingIgnoreCase(categoryName))
                .thenReturn(Flux.just(book1, book2));

        // When & Then
        StepVerifier.create(bookService.getBooksByCategory(categoryName))
                .expectNext(book1)
                .expectNext(book2)
                .expectComplete()
                .verify();
    }

    @Test
    void getBooksByCategory_ShouldReturnEmpty_WhenNoBooksFound() {
        // Given
        String categoryName = "NonExistent";
        
        when(bookRepo.findByCategoryNameContainingIgnoreCase(categoryName))
                .thenReturn(Flux.empty());

        // When & Then
        StepVerifier.create(bookService.getBooksByCategory(categoryName))
                .expectComplete()
                .verify();
    }

    @Test
    void save_ShouldReturnSavedBook() {
        // Given
        Category category = new Category("1", "Fiction", true);
        Book bookToSave = new Book(null, category, "New Book", "123456789", "http://photo.url", true);
        Book savedBook = new Book("1", category, "New Book", "123456789", "http://photo.url", true);
        
        when(bookRepo.save(bookToSave)).thenReturn(Mono.just(savedBook));

        // When & Then
        StepVerifier.create(bookService.save(bookToSave))
                .expectNext(savedBook)
                .expectComplete()
                .verify();
    }

    @Test
    void delete_ShouldCompleteSuccessfully_WhenExists() {
        // Given
        String bookId = "1";
        Category category = new Category("1", "Fiction", true);
        Book existingBook = new Book(bookId, category, "Test Book", "123456789", "http://photo.url", true);
        
        when(bookRepo.findById(bookId)).thenReturn(Mono.just(existingBook));
        when(bookRepo.deleteById(bookId)).thenReturn(Mono.empty());

        // When & Then
        StepVerifier.create(bookService.delete(bookId))
                .expectComplete()
                .verify();
    }
}