package com.mitocode.service.impl;

import com.mitocode.exception.ModelNotFoundException;
import com.mitocode.model.Category;
import com.mitocode.repo.ICategoryRepo;
import com.mitocode.service.ICategoryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CategoryServiceImplTest {

    @Mock
    private ICategoryRepo categoryRepo;

    private ICategoryService categoryService;

    @BeforeEach
    void setUp() {
        categoryService = new CategoryServiceImpl(categoryRepo);
    }

    @Test
    void findAll_ShouldReturnAllCategories() {
        // Given
        Category category1 = new Category("1", "Fiction", true);
        Category category2 = new Category("2", "Non-Fiction", true);
        
        when(categoryRepo.findAll()).thenReturn(Flux.just(category1, category2));

        // When & Then
        StepVerifier.create(categoryService.findAll())
                .expectNext(category1)
                .expectNext(category2)
                .expectComplete()
                .verify();
    }

    @Test
    void findById_ShouldReturnCategory_WhenExists() {
        // Given
        String categoryId = "1";
        Category category = new Category(categoryId, "Fiction", true);
        
        when(categoryRepo.findById(categoryId)).thenReturn(Mono.just(category));

        // When & Then
        StepVerifier.create(categoryService.findById(categoryId))
                .expectNext(category)
                .expectComplete()
                .verify();
    }

    @Test
    void findById_ShouldThrowException_WhenNotExists() {
        // Given
        String categoryId = "999";
        
        when(categoryRepo.findById(categoryId)).thenReturn(Mono.empty());

        // When & Then
        StepVerifier.create(categoryService.findById(categoryId))
                .expectErrorMatches(throwable -> throwable instanceof ModelNotFoundException &&
                        throwable.getMessage().contains("ID NOT FOUND: 999"))
                .verify();
    }

    @Test
    void save_ShouldReturnSavedCategory() {
        // Given
        Category categoryToSave = new Category(null, "New Category", true);
        Category savedCategory = new Category("1", "New Category", true);
        
        when(categoryRepo.save(categoryToSave)).thenReturn(Mono.just(savedCategory));

        // When & Then
        StepVerifier.create(categoryService.save(categoryToSave))
                .expectNext(savedCategory)
                .expectComplete()
                .verify();
    }

    @Test
    void update_ShouldReturnUpdatedCategory_WhenExists() {
        // Given
        String categoryId = "1";
        Category existingCategory = new Category(categoryId, "Old Name", true);
        Category categoryToUpdate = new Category(categoryId, "Updated Name", true);
        
        when(categoryRepo.findById(categoryId)).thenReturn(Mono.just(existingCategory));
        when(categoryRepo.save(categoryToUpdate)).thenReturn(Mono.just(categoryToUpdate));

        // When & Then
        StepVerifier.create(categoryService.update(categoryId, categoryToUpdate))
                .expectNext(categoryToUpdate)
                .expectComplete()
                .verify();
    }

    @Test
    void update_ShouldThrowException_WhenNotExists() {
        // Given
        String categoryId = "999";
        Category categoryToUpdate = new Category(categoryId, "Updated Name", true);
        
        when(categoryRepo.findById(categoryId)).thenReturn(Mono.empty());

        // When & Then
        StepVerifier.create(categoryService.update(categoryId, categoryToUpdate))
                .expectErrorMatches(throwable -> throwable instanceof ModelNotFoundException &&
                        throwable.getMessage().contains("ID NOT FOUND: 999"))
                .verify();
    }

    @Test
    void delete_ShouldCompleteSuccessfully_WhenExists() {
        // Given
        String categoryId = "1";
        Category existingCategory = new Category(categoryId, "Fiction", true);
        
        when(categoryRepo.findById(categoryId)).thenReturn(Mono.just(existingCategory));
        when(categoryRepo.deleteById(categoryId)).thenReturn(Mono.empty());

        // When & Then
        StepVerifier.create(categoryService.delete(categoryId))
                .expectComplete()
                .verify();
    }

    @Test
    void delete_ShouldThrowException_WhenNotExists() {
        // Given
        String categoryId = "999";
        
        when(categoryRepo.findById(categoryId)).thenReturn(Mono.empty());

        // When & Then
        StepVerifier.create(categoryService.delete(categoryId))
                .expectErrorMatches(throwable -> throwable instanceof ModelNotFoundException &&
                        throwable.getMessage().contains("ID NOT FOUND: 999"))
                .verify();
    }
}