package com.mitocode.dto;

//JPA Projection
public interface IProcedureDTO {

    Integer getQuantityfn();
    String getDatetimefn();
}
