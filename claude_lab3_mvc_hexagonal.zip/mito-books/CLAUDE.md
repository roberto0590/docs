# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Spring Boot 3.5.6 REST API for a bookstore management system using Java 21, JPA/Hibernate, and PostgreSQL.

## Build & Development Commands

### Build and Run
```bash
# Build the project (Maven Wrapper)
./mvnw clean install

# Run the application
./mvnw spring-boot:run

# Run tests
./mvnw test

# Run a single test class
./mvnw test -Dtest=ClassName

# Run a single test method
./mvnw test -Dtest=ClassName#methodName
```

### Database
```bash
# Start PostgreSQL via Docker Compose
docker-compose up -d

# Stop PostgreSQL
docker-compose down
```

The application uses Spring Boot Docker Compose support, which automatically starts containers defined in `docker-compose.yml` when running the application.

Database configuration is in `.env` file. Schema is auto-created on startup (`spring.jpa.hibernate.ddl-auto=create`).

## Architecture

### Hexagonal Architecture (Ports & Adapters)

The codebase follows a strict hexagonal architecture with three main layers:

#### Layer Structure

```
src/main/java/com/mitocode/{context}/
├── domain/                           # Layer 1: Domain (Business Core)
│   ├── model/
│   │   ├── entity/                   # Domain entities (pure POJOs)
│   │   ├── vo/                       # Value Objects
│   │   ├── enums/                    # Domain enumerations
│   │   ├── exception/                # Domain exceptions
│   │   └── constant/                 # Domain constants
│   └── port/
│       ├── in/                       # Input Ports (use case interfaces)
│       └── out/                      # Output Ports (repository interfaces)
│
├── application/                      # Layer 2: Application (Use Cases)
│   ├── usecase/                      # Use case implementations
│   ├── dto/                          # Application DTOs (Commands/Results)
│   ├── mapper/                       # Application mappers
│   └── service/                      # Service orchestration (optional)
│
└── infrastructure/                   # Layer 3: Infrastructure (Adapters)
    ├── in/rest/
    │   ├── controller/               # REST controllers
    │   ├── api/                      # OpenAPI interfaces (Scalar docs)
    │   ├── dto/                      # Request/Response DTOs
    │   ├── mapper/                   # Web mappers
    │   ├── service/                  # Facade services (DTO → Command)
    │   └── exception/                # HTTP exception handlers
    ├── out/
    │   ├── persistence/
    │   │   ├── entity/               # JPA entities (suffixed *JpaEntity)
    │   │   ├── repository/           # Spring Data repositories
    │   │   ├── adapter/              # Repository adapters (implement ports)
    │   │   └── mapper/               # JPA mappers
    │   └── client/
    │       ├── internal/             # Internal company clients
    │       │   ├── api/              # API specifications
    │       │   ├── adapter/          # Client adapters
    │       │   ├── dto/              # Request/Response DTOs
    │       │   └── mapper/           # Client mappers
    │       └── external/             # External third-party clients
    │           ├── api/              # API specifications
    │           ├── adapter/          # Client adapters
    │           ├── dto/              # Request/Response DTOs
    │           └── mapper/           # Client mappers
    ├── config/                       # Configuration
    └── shared/
        ├── util/                     # Reusable utilities
        └── config/                   # Shared configuration
```

### Key Architectural Principles

**Dependency Rules (STRICT):**
```
✅ ALLOWED:
Infrastructure → Application → Domain
Infrastructure → Domain

❌ PROHIBITED:
Domain → Application
Domain → Infrastructure
Application → Infrastructure
```

**Domain Layer (Pure - NO external dependencies):**
- Plain Java POJOs (no JPA, no Spring, no Jakarta)
- Only Java standard library (`java.util.*`, `java.time.*`, etc.)
- Business logic and domain rules
- Interfaces defining what it needs (Output Ports) and what it provides (Input Ports)
- Allowed Lombok: `@Getter`, `@Builder`, `@AllArgsConstructor` (NOT `@Entity`, `@Data`)

**Application Layer (Depends only on Domain):**
- Use case implementations (business workflows)
- Implements Input Ports from `domain/port/in/`
- Depends on Output Ports from `domain/port/out/`
- Commands and Results DTOs
- No web/persistence frameworks (only `@Service`, `@Transactional`)

**Infrastructure Layer (Can depend on everything):**
- Implements adapters for external systems
- JPA entities separate from domain entities (`*JpaEntity` suffix)
- Spring Data repositories
- REST controllers depend on Input Ports (interfaces), NOT implementations
- Mappers convert between layers

### Nomenclature Conventions

**Domain Layer:**
- Entity: `Book.java` (pure POJO)
- Value Object: `ISBN.java`, `Money.java`
- Exception: `BookNotFoundException.java`
- Output Port: `BookRepositoryPort.java`
- Input Port: `CreateBookUseCase.java`

**Application Layer:**
- UseCase Impl: `CreateBookUseCaseImpl.java` (implements `CreateBookUseCase`)
- Command: `CreateBookCommand.java`
- Result: `CreateBookResult.java`
- Mapper: `BookApplicationMapper.java`

**Infrastructure Layer:**
- Controller: `BookController.java`
- Request DTO: `CreateBookRequestDto.java`
- Response DTO: `CreateBookResponseDto.java`
- Web Mapper: `BookWebMapper.java`
- JPA Entity: `BookJpaEntity.java` (NOT `Book.java`)
- Spring Data Repo: `SpringDataBookRepository.java`
- Adapter: `BookRepositoryAdapter.java` (implements `BookRepositoryPort`)
- JPA Mapper: `BookJpaMapper.java`

### SOLID Principles Applied

**Single Responsibility Principle (SRP):**
- Each use case does ONE thing: `CreateBookUseCaseImpl`, `UpdateBookUseCaseImpl`, `DeleteBookUseCaseImpl`
- NO generic CRUD services combining multiple operations

**Dependency Inversion Principle (DIP):**
- Controllers inject Input Port interfaces (`CreateBookUseCase`), NOT implementations
- Use cases inject Output Port interfaces (`BookRepositoryPort`), NOT adapters

**Open/Closed Principle (OCP):**
- New functionality = new use case class (extend via new classes, not modifying existing ones)

### Exception Handling

**Domain Exceptions** (`domain/model/exception/`):
- Business rule violations: `BookNotFoundException`, `InvalidISBNException`
- Thrown by domain entities and use cases

**Infrastructure Exception Handler** (`infrastructure/in/rest/exception/GlobalErrorHandler`):
- Catches domain exceptions and converts to HTTP responses
- Returns standardized `GenericResponse<CustomErrorResponse>`

### Validation Strategy

**Domain Validation** (constructor/method level):
```java
// domain/model/entity/Category.java
public Category(String name) {
    if (name == null || name.isBlank()) {
        throw new IllegalArgumentException("Name cannot be blank");
    }
    this.name = name;
}
```

**Infrastructure Validation** (Jakarta Bean Validation):
```java
// infrastructure/in/rest/dto/CreateCategoryRequestDto.java
import jakarta.validation.constraints.NotNull;

public class CreateCategoryRequestDto {
    @NotNull
    private String name;
}
```

### Entity Relationships

**Domain Level:**
- Relationships defined as object references
- No JPA annotations

**Infrastructure Level (JPA):**
- Book → Category (ManyToOne)
- Sale → Client (ManyToOne)
- Sale → SaleDetail (OneToMany with cascade)

### Lombok Configuration

**`lombok.config`:**
- Configured to make `@Qualifier` copyable to generated constructors
- Use minimal Lombok in domain (`@Getter`, `@Builder`, `@AllArgsConstructor`)
- Avoid `@Data` to maintain control over equals/hashCode

## Common Patterns

### Adding a New Entity with Hexagonal Architecture

Follow this strict order for each new entity (e.g., `Product`):

#### 1. Domain Layer (Pure Business Logic)

**a. Create Domain Entity** (`domain/model/entity/Product.java`):
```java
// Pure POJO - NO JPA annotations
public class Product {
    private Long id;
    private String name;
    private BigDecimal price;

    // Constructor with validation
    public Product(Long id, String name, BigDecimal price) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Product name cannot be blank");
        }
        if (price == null || price.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Price must be positive");
        }
        this.id = id;
        this.name = name;
        this.price = price;
    }

    // Business methods
    public void applyDiscount(BigDecimal percentage) {
        // Business logic here
    }
}
```

**b. Create Value Objects** (`domain/model/vo/`) if needed:
```java
public record Money(BigDecimal amount, Currency currency) {
    public Money {
        if (amount.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Amount cannot be negative");
        }
    }
}
```

**c. Create Domain Exceptions** (`domain/model/exception/ProductNotFoundException.java`):
```java
public class ProductNotFoundException extends RuntimeException {
    public ProductNotFoundException(Long id) {
        super("Product not found with id: " + id);
    }
}
```

**d. Create Output Port** (`domain/port/out/ProductRepositoryPort.java`):
```java
public interface ProductRepositoryPort {
    Product save(Product product);
    Optional<Product> findById(Long id);
    List<Product> findAll();
    void deleteById(Long id);
    // Custom queries as needed
}
```

**e. Create Input Ports (Use Cases)** (`domain/port/in/`):
```java
// CreateProductUseCase.java
public interface CreateProductUseCase {
    Product create(CreateProductCommand command);
}

// FindProductUseCase.java
public interface FindProductUseCase {
    Optional<Product> findById(Long id);
    List<Product> findAll();
}

// UpdateProductUseCase.java
public interface UpdateProductUseCase {
    Product update(UpdateProductCommand command);
}

// DeleteProductUseCase.java
public interface DeleteProductUseCase {
    void deleteById(Long id);
}
```

#### 2. Application Layer (Use Cases)

**a. Create Commands and Results** (`application/dto/`):
```java
// CreateProductCommand.java
public record CreateProductCommand(String name, BigDecimal price) {}

// UpdateProductCommand.java
public record UpdateProductCommand(Long id, String name, BigDecimal price) {}
```

**b. Create Use Case Implementations** (`application/usecase/`):
```java
// CreateProductUseCaseImpl.java
@Service
public class CreateProductUseCaseImpl implements CreateProductUseCase {
    private final ProductRepositoryPort productRepository;

    public CreateProductUseCaseImpl(ProductRepositoryPort productRepository) {
        this.productRepository = productRepository;
    }

    @Override
    @Transactional
    public Product create(CreateProductCommand command) {
        Product product = new Product(null, command.name(), command.price());
        return productRepository.save(product);
    }
}

// FindProductUseCaseImpl.java
@Service
public class FindProductUseCaseImpl implements FindProductUseCase {
    private final ProductRepositoryPort productRepository;

    public FindProductUseCaseImpl(ProductRepositoryPort productRepository) {
        this.productRepository = productRepository;
    }

    @Override
    public Optional<Product> findById(Long id) {
        return productRepository.findById(id);
    }

    @Override
    public List<Product> findAll() {
        return productRepository.findAll();
    }
}
```

**c. Create Application Mapper** (`application/mapper/ProductApplicationMapper.java`):
```java
@Component
public class ProductApplicationMapper {
    public CreateProductCommand toCommand(String name, BigDecimal price) {
        return new CreateProductCommand(name, price);
    }
}
```

#### 3. Infrastructure Layer (Adapters)

**a. Create JPA Entity** (`infrastructure/out/persistence/entity/ProductJpaEntity.java`):
```java
@Entity
@Table(name = "products")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ProductJpaEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private BigDecimal price;
}
```

**b. Create Spring Data Repository** (`infrastructure/out/persistence/repository/SpringDataProductRepository.java`):
```java
public interface SpringDataProductRepository extends JpaRepository<ProductJpaEntity, Long> {
    // Custom JPQL queries
    @Query("SELECT p FROM ProductJpaEntity p WHERE p.price > :minPrice")
    List<ProductJpaEntity> findByPriceGreaterThan(@Param("minPrice") BigDecimal minPrice);
}
```

**c. Create JPA Mapper** (`infrastructure/out/persistence/mapper/ProductJpaMapper.java`):
```java
@Component
public class ProductJpaMapper {
    public Product toDomain(ProductJpaEntity entity) {
        return new Product(entity.getId(), entity.getName(), entity.getPrice());
    }

    public ProductJpaEntity toEntity(Product domain) {
        return new ProductJpaEntity(domain.getId(), domain.getName(), domain.getPrice());
    }
}
```

**d. Create Repository Adapter** (`infrastructure/out/persistence/adapter/ProductRepositoryAdapter.java`):
```java
@Component
public class ProductRepositoryAdapter implements ProductRepositoryPort {
    private final SpringDataProductRepository repository;
    private final ProductJpaMapper mapper;

    public ProductRepositoryAdapter(SpringDataProductRepository repository,
                                   ProductJpaMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    @Override
    public Product save(Product product) {
        ProductJpaEntity entity = mapper.toEntity(product);
        ProductJpaEntity saved = repository.save(entity);
        return mapper.toDomain(saved);
    }

    @Override
    public Optional<Product> findById(Long id) {
        return repository.findById(id).map(mapper::toDomain);
    }

    @Override
    public List<Product> findAll() {
        return repository.findAll().stream()
                .map(mapper::toDomain)
                .toList();
    }

    @Override
    public void deleteById(Long id) {
        repository.deleteById(id);
    }
}
```

**e. Create Request/Response DTOs** (`infrastructure/in/rest/dto/`):
```java
// CreateProductRequestDto.java
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;

public record CreateProductRequestDto(
    @NotBlank String name,
    @Positive BigDecimal price
) {}

// ProductResponseDto.java
public record ProductResponseDto(Long id, String name, BigDecimal price) {}
```

**f. Create Web Mapper** (`infrastructure/in/rest/mapper/ProductWebMapper.java`):
```java
@Component
public class ProductWebMapper {
    public CreateProductCommand toCommand(CreateProductRequestDto dto) {
        return new CreateProductCommand(dto.name(), dto.price());
    }

    public ProductResponseDto toResponse(Product domain) {
        return new ProductResponseDto(domain.getId(), domain.getName(), domain.getPrice());
    }
}
```

**g. Create REST Controller** (`infrastructure/in/rest/controller/ProductController.java`):
```java
@RestController
@RequestMapping("/api/products")
@RequiredArgsConstructor
public class ProductController {
    // Inject USE CASE INTERFACES, not implementations
    private final CreateProductUseCase createProductUseCase;
    private final FindProductUseCase findProductUseCase;
    private final UpdateProductUseCase updateProductUseCase;
    private final DeleteProductUseCase deleteProductUseCase;
    private final ProductWebMapper mapper;

    @PostMapping
    public ResponseEntity<GenericResponse<ProductResponseDto>> create(
            @Valid @RequestBody CreateProductRequestDto request) {
        CreateProductCommand command = mapper.toCommand(request);
        Product product = createProductUseCase.create(command);
        ProductResponseDto response = mapper.toResponse(product);
        return ResponseEntity.ok(new GenericResponse<>(true, response));
    }

    @GetMapping("/{id}")
    public ResponseEntity<GenericResponse<ProductResponseDto>> findById(@PathVariable Long id) {
        Optional<Product> product = findProductUseCase.findById(id);
        ProductResponseDto response = mapper.toResponse(product.orElseThrow(
            () -> new ProductNotFoundException(id)
        ));
        return ResponseEntity.ok(new GenericResponse<>(true, response));
    }

    @GetMapping
    public ResponseEntity<GenericResponse<List<ProductResponseDto>>> findAll() {
        List<Product> products = findProductUseCase.findAll();
        List<ProductResponseDto> response = products.stream()
                .map(mapper::toResponse)
                .toList();
        return ResponseEntity.ok(new GenericResponse<>(true, response));
    }
}
```

### Custom Repository Queries in Hexagonal Architecture

**Step 1: Add method to Output Port** (`domain/port/out/ProductRepositoryPort.java`):
```java
public interface ProductRepositoryPort {
    // ... existing methods
    List<Product> findExpensiveProducts(BigDecimal minPrice);
}
```

**Step 2: Implement in Spring Data Repository** (`infrastructure/out/persistence/repository/SpringDataProductRepository.java`):
```java
@Query("SELECT p FROM ProductJpaEntity p WHERE p.price > :minPrice")
List<ProductJpaEntity> findByPriceGreaterThan(@Param("minPrice") BigDecimal minPrice);
```

**Step 3: Implement in Adapter** (`infrastructure/out/persistence/adapter/ProductRepositoryAdapter.java`):
```java
@Override
public List<Product> findExpensiveProducts(BigDecimal minPrice) {
    return repository.findByPriceGreaterThan(minPrice).stream()
            .map(mapper::toDomain)
            .toList();
}
```

### Custom Business Operations (Use Cases)

**Never modify existing use cases.** Always create new ones:

**Step 1: Define Input Port** (`domain/port/in/ApplyDiscountToProductUseCase.java`):
```java
public interface ApplyDiscountToProductUseCase {
    Product applyDiscount(ApplyDiscountCommand command);
}
```

**Step 2: Create Command** (`application/dto/ApplyDiscountCommand.java`):
```java
public record ApplyDiscountCommand(Long productId, BigDecimal percentage) {}
```

**Step 3: Implement Use Case** (`application/usecase/ApplyDiscountToProductUseCaseImpl.java`):
```java
@Service
public class ApplyDiscountToProductUseCaseImpl implements ApplyDiscountToProductUseCase {
    private final ProductRepositoryPort productRepository;

    @Override
    @Transactional
    public Product applyDiscount(ApplyDiscountCommand command) {
        Product product = productRepository.findById(command.productId())
                .orElseThrow(() -> new ProductNotFoundException(command.productId()));
        product.applyDiscount(command.percentage());
        return productRepository.save(product);
    }
}
```

**Step 4: Add Controller Endpoint** (`infrastructure/in/rest/controller/ProductController.java`):
```java
@PatchMapping("/{id}/discount")
public ResponseEntity<GenericResponse<ProductResponseDto>> applyDiscount(
        @PathVariable Long id,
        @RequestParam BigDecimal percentage) {
    ApplyDiscountCommand command = new ApplyDiscountCommand(id, percentage);
    Product product = applyDiscountToProductUseCase.applyDiscount(command);
    ProductResponseDto response = mapper.toResponse(product);
    return ResponseEntity.ok(new GenericResponse<>(true, response));
}
```

### Validation Checklist

Before considering the implementation complete, verify:

- [ ] Domain entities have NO `@Entity`, `@Table`, or any JPA annotations
- [ ] Domain entities have NO `jakarta.*` or `org.springframework.*` imports (except Lombok basics)
- [ ] Controllers inject USE CASE INTERFACES (`CreateProductUseCase`), NOT implementations (`CreateProductUseCaseImpl`)
- [ ] Use cases inject OUTPUT PORT INTERFACES (`ProductRepositoryPort`), NOT adapters (`ProductRepositoryAdapter`)
- [ ] Each use case has exactly ONE public method (SRP)
- [ ] JPA entities are named with `*JpaEntity` suffix
- [ ] All mappers are in the correct layer (Application, Web, JPA)
- [ ] Domain validation is in constructors/methods, Jakarta validation is in Request DTOs