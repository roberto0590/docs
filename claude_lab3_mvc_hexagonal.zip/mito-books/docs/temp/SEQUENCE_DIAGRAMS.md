# Diagramas de Secuencia - Mito Books API

Este documento describe los flujos de secuencia para las operaciones principales del sistema de gestión de librería.

## Tabla de Contenidos
1. [Flujo de Creación de Libro](#1-flujo-de-creación-de-libro)
2. [Flujo de Búsqueda de Libros por Categoría](#2-flujo-de-búsqueda-de-libros-por-categoría)
3. [Flujo de Creación de Cliente](#3-flujo-de-creación-de-cliente)
4. [Flujo de Creación de Venta](#4-flujo-de-creación-de-venta)
5. [Flujo de Manejo de Excepciones](#5-flujo-de-manejo-de-excepciones)

---

## 1. Flujo de Creación de Libro

### Happy Path: Crear un libro exitosamente

```mermaid
sequenceDiagram
    actor Cliente
    participant BookController
    participant BookAPI
    participant IBookService
    participant BookServiceImpl
    participant IBookRepo
    participant ModelMapper
    participant Database

    Cliente->>BookController: POST /books
    Note over Cliente,BookController: BookDTO con datos válidos

    BookController->>BookAPI: Implementa interfaz
    Note over BookController,BookAPI: Documentación separada

    BookController->>ModelMapper: convertToEntity(BookDTO)
    ModelMapper-->>BookController: Book entity

    BookController->>IBookService: save(Book)
    IBookService->>BookServiceImpl: save(Book)

    BookServiceImpl->>IBookRepo: save(Book)
    IBookRepo->>Database: INSERT INTO books
    Database-->>IBookRepo: Book persistido con ID
    IBookRepo-->>BookServiceImpl: Book con ID
    BookServiceImpl-->>IBookService: Book con ID
    IBookService-->>BookController: Book guardado

    BookController->>BookController: Construir URI con ID
    BookController-->>Cliente: 201 CREATED
    Note over Cliente,BookController: Location: /books/{id}
```

### Unhappy Path: Validación fallida

```mermaid
sequenceDiagram
    actor Cliente
    participant BookController
    participant Validator
    participant GlobalErrorHandler

    Cliente->>BookController: POST /books
    Note over Cliente,BookController: BookDTO con datos inválidos

    BookController->>Validator: @Valid validación
    Validator-->>BookController: MethodArgumentNotValidException

    BookController->>GlobalErrorHandler: handleBadRequest()
    GlobalErrorHandler->>GlobalErrorHandler: Crear CustomErrorResponse
    GlobalErrorHandler-->>Cliente: 400 BAD_REQUEST
    Note over Cliente,GlobalErrorHandler: GenericResponse<CustomErrorResponse>
```

---

## 2. Flujo de Búsqueda de Libros por Categoría

### Happy Path: Búsqueda exitosa

```mermaid
sequenceDiagram
    actor Cliente
    participant BookController
    participant IBookService
    participant BookServiceImpl
    participant IBookRepo
    participant Database
    participant ModelMapper

    Cliente->>BookController: GET /books/byCategory?category=Programming

    BookController->>IBookService: getBooksByCategory("Programming")
    IBookService->>BookServiceImpl: getBooksByCategory("Programming")

    BookServiceImpl->>IBookRepo: getBooksByCategory("Programming")
    Note over BookServiceImpl,IBookRepo: JPQL: FROM Book WHERE category.name LIKE %:name%

    IBookRepo->>Database: SELECT con LIKE
    Database-->>IBookRepo: List<Book>
    IBookRepo-->>BookServiceImpl: List<Book>
    BookServiceImpl-->>IBookService: List<Book>
    IBookService-->>BookController: List<Book>

    loop Para cada Book
        BookController->>ModelMapper: convertToDto(Book)
        ModelMapper-->>BookController: BookDTO
    end

    BookController->>BookController: Crear GenericResponse
    BookController-->>Cliente: 200 OK
    Note over Cliente,BookController: GenericResponse<List<BookDTO>>
```

---

## 3. Flujo de Creación de Cliente

### Happy Path: Cliente creado exitosamente

```mermaid
sequenceDiagram
    actor Admin
    participant ClientController
    participant ClientAPI
    participant IClientService
    participant ClientServiceImpl
    participant IClientRepo
    participant ModelMapper
    participant Database

    Admin->>ClientController: POST /clients
    Note over Admin,ClientController: ClientDTO validado (size 3-20)

    ClientController->>ClientAPI: Implementa interfaz
    Note over ClientController,ClientAPI: Custom clientMapper

    ClientController->>ModelMapper: convertToEntity(ClientDTO)
    Note over ModelMapper: firstName ↔ primaryName<br/>surname ↔ lastName
    ModelMapper-->>ClientController: Client entity

    ClientController->>IClientService: save(Client)
    IClientService->>ClientServiceImpl: save(Client)

    ClientServiceImpl->>IClientRepo: save(Client)
    IClientRepo->>Database: INSERT INTO clients
    Database-->>IClientRepo: Client con ID
    IClientRepo-->>ClientServiceImpl: Client
    ClientServiceImpl-->>IClientService: Client
    IClientService-->>ClientController: Client guardado

    ClientController-->>Admin: 201 CREATED
    Note over Admin,ClientController: Location: /clients/{id}
```

---

## 4. Flujo de Creación de Venta

### Happy Path: Venta completa con múltiples detalles

```mermaid
sequenceDiagram
    actor Vendedor
    participant SaleController
    participant SaleAPI
    participant ISaleService
    participant SaleServiceImpl
    participant ISaleRepo
    participant ModelMapper
    participant Database

    Vendedor->>SaleController: POST /sales
    Note over Vendedor,SaleController: SaleDTO con Client y List<SaleDetailDTO>

    SaleController->>SaleAPI: Implementa interfaz
    Note over SaleController,SaleAPI: Custom saleMapper con nested mapping

    SaleController->>ModelMapper: convertToEntity(SaleDTO)
    Note over ModelMapper: Mapeo de Client y cascade SaleDetails
    ModelMapper-->>SaleController: Sale entity con details

    SaleController->>ISaleService: save(Sale)
    ISaleService->>SaleServiceImpl: save(Sale)

    SaleServiceImpl->>ISaleRepo: save(Sale)
    Note over ISaleRepo,Database: Cascade persist para SaleDetails

    ISaleRepo->>Database: BEGIN TRANSACTION
    ISaleRepo->>Database: INSERT INTO sales
    Database-->>ISaleRepo: Sale ID generado

    loop Para cada SaleDetail
        ISaleRepo->>Database: INSERT INTO sale_details
        Note over Database: FK a sale_id y book_id
    end

    ISaleRepo->>Database: COMMIT TRANSACTION
    Database-->>ISaleRepo: Sale completo con details

    ISaleRepo-->>SaleServiceImpl: Sale persistido
    SaleServiceImpl-->>ISaleService: Sale
    IServiceSale-->>SaleController: Sale guardado

    SaleController-->>Vendedor: 201 CREATED
    Note over Vendedor,SaleController: Location: /sales/{id}
```

### Unhappy Path: Venta con datos inválidos

```mermaid
sequenceDiagram
    actor Vendedor
    participant SaleController
    participant Validator
    participant GlobalErrorHandler

    Vendedor->>SaleController: POST /sales
    Note over Vendedor,SaleController: SaleDTO con totalSale negativo

    SaleController->>Validator: @Valid validación
    Validator-->>SaleController: MethodArgumentNotValidException

    SaleController->>GlobalErrorHandler: handleBadRequest()
    GlobalErrorHandler->>GlobalErrorHandler: Crear CustomErrorResponse
    Note over GlobalErrorHandler: datetime, message, path

    GlobalErrorHandler-->>Vendedor: 400 BAD_REQUEST
    Note over Vendedor,GlobalErrorHandler: GenericResponse<CustomErrorResponse>
```

---

## 5. Flujo de Manejo de Excepciones

### Caso: Recurso no encontrado (404)

```mermaid
sequenceDiagram
    actor Cliente
    participant Controller
    participant ServiceImpl
    participant CRUDImpl
    participant Repository
    participant GlobalErrorHandler

    Cliente->>Controller: GET /books/999

    Controller->>ServiceImpl: findById(999)
    ServiceImpl->>CRUDImpl: findById(999)

    CRUDImpl->>Repository: findById(999)
    Repository-->>CRUDImpl: Optional.empty()

    CRUDImpl->>CRUDImpl: orElseThrow()
    CRUDImpl-->>ServiceImpl: ModelNotFoundException
    Note over CRUDImpl: "Book with ID 999 not found"

    ServiceImpl-->>Controller: ModelNotFoundException
    Controller->>GlobalErrorHandler: handleModelNotFoundException()

    GlobalErrorHandler->>GlobalErrorHandler: Crear CustomErrorResponse
    Note over GlobalErrorHandler: timestamp, message, path

    GlobalErrorHandler->>GlobalErrorHandler: Wrap en GenericResponse
    GlobalErrorHandler-->>Cliente: 404 NOT_FOUND
    Note over Cliente,GlobalErrorHandler: {status: 404, message: "not-found", data: [error]}
```

### Caso: Error interno del servidor (500)

```mermaid
sequenceDiagram
    actor Cliente
    participant Controller
    participant Service
    participant Database
    participant GlobalErrorHandler

    Cliente->>Controller: POST /books

    Controller->>Service: save(Book)
    Service->>Database: INSERT

    Database-->>Service: SQLException
    Note over Database: Violación de constraint, etc.

    Service-->>Controller: Exception
    Controller->>GlobalErrorHandler: handleDefaultException()

    GlobalErrorHandler->>GlobalErrorHandler: Crear CustomErrorResponse
    GlobalErrorHandler->>GlobalErrorHandler: Wrap en GenericResponse

    GlobalErrorHandler-->>Cliente: 500 INTERNAL_SERVER_ERROR
    Note over Cliente,GlobalErrorHandler: {status: 500, message: "failed", data: [error]}
```

---

## Arquitectura General del Sistema

### Flujo de Capas (Layered Architecture)

```mermaid
flowchart TB
    Client[Cliente HTTP]

    subgraph "Presentation Layer"
        API[API Interface<br/>BookAPI, CategoryAPI, etc.]
        Controller[Controllers<br/>BookController, etc.]
    end

    subgraph "Service Layer"
        IService[Service Interface<br/>ICRUD extends]
        ServiceImpl[Service Implementation<br/>CRUDImpl abstract class]
        CustomService[Custom Services<br/>IBookService, etc.]
    end

    subgraph "Data Access Layer"
        IRepo[Repository Interface<br/>IGenericRepo extends]
        JPA[Spring Data JPA]
    end

    subgraph "Infrastructure"
        ErrorHandler[GlobalErrorHandler<br/>@RestControllerAdvice]
        Mapper[ModelMapper<br/>Beans: default, client, sale]
        Validation[Jakarta Validation<br/>@Valid annotations]
    end

    Database[(PostgreSQL<br/>Database)]

    Client -->|HTTP Request| API
    API -.->|Documented by| Controller
    Controller -->|Uses| Validation
    Controller -->|Converts| Mapper
    Controller -->|Calls| IService
    IService -->|Implemented by| ServiceImpl
    ServiceImpl -->|Extends| CustomService
    CustomService -->|Calls| IRepo
    IRepo -->|Extends| JPA
    JPA -->|Persists| Database

    ServiceImpl -.->|Throws| ErrorHandler
    Controller -.->|Exceptions| ErrorHandler
    ErrorHandler -->|Returns| Client

    style API fill:#e1f5ff
    style Controller fill:#e1f5ff
    style ErrorHandler fill:#ffe1e1
    style Mapper fill:#fff4e1
    style Database fill:#e1ffe1
```

---

## Patrones Implementados

### 1. **Generic CRUD Pattern**
- Base: `ICRUD<T, ID>` interface y `CRUDImpl<T, ID>` abstract class
- Implementación: Todos los servicios extienden el CRUD base
- Beneficio: Código reutilizable, menos boilerplate

### 2. **Repository Pattern**
- Base: `IGenericRepo<T, ID> extends JpaRepository`
- Todos los repos extienden la interfaz genérica
- Custom queries con JPQL cuando es necesario

### 3. **DTO Pattern**
- Conversión via ModelMapper
- Separación de capas (Entity vs DTO)
- Custom mappings para casos especiales (Client, Sale)

### 4. **API Documentation Separation** ✨ NUEVO
- Interfaces separadas con documentación OpenAPI
- Controllers implementan las interfaces
- **Single Responsibility**: Documentación separada de lógica

### 5. **Global Exception Handling**
- `@RestControllerAdvice` centralizado
- Respuestas consistentes via `GenericResponse<CustomErrorResponse>`
- Manejo de múltiples tipos de excepciones

---

## Flujos de Negocio Críticos

### 1. **Flujo de Venta Completo**
1. Verificar que el cliente exista
2. Verificar que todos los libros existan y estén disponibles
3. Validar cantidades y precios
4. Calcular total
5. Persistir venta y detalles en transacción
6. Retornar confirmación

### 2. **Flujo de Búsqueda con Filtros**
1. Recibir parámetros de búsqueda
2. Ejecutar query con JPQL
3. Convertir resultados a DTOs
4. Retornar lista envuelta en GenericResponse

### 3. **Flujo de Actualización**
1. Verificar que el recurso exista (findById)
2. Si no existe → ModelNotFoundException → 404
3. Si existe → actualizar campos
4. Persistir cambios
5. Retornar recurso actualizado

---

## Notas de Implementación

### ModelMapper Configuration
- **defaultMapper**: Mapeo estándar para Book y Category
- **clientMapper**: firstName ↔ primaryName, surname ↔ lastName
- **saleMapper**: Mapeo nested para Sale con Client y SaleDetails

### Cascade Operations
- Sale → SaleDetail: CascadeType.ALL
- Al guardar/eliminar Sale, se propagan cambios a SaleDetails

### Validation Strategy
- Jakarta Validation en DTOs
- `@Valid` en controller methods
- Global handling de `MethodArgumentNotValidException`

### Transaction Management
- Gestionado automáticamente por Spring
- `@Transactional` en service layer (implícito en CRUDImpl)

---

## URLs de Documentación

- **Scalar UI**: http://localhost:8080/scalar.html
- **Swagger UI**: http://localhost:8080/swagger-ui.html
- **OpenAPI JSON**: http://localhost:8080/v3/api-docs
- **OpenAPI YAML**: http://localhost:8080/v3/api-docs.yaml

---

**Generado para Mito Books API**
_Spring Boot 3.5.6 | Java 21 | PostgreSQL_
