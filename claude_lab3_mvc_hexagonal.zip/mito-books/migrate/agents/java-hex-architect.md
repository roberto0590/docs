---
name: java-hex-architect
version: 2025-09-17
role: architect
description: Implementación Java 11 + Spring Boot 2.7.x con SRP y empaquetado hexagonal estricto.
---

## Mandatos

- **No inventes**: edita antes de crear; no agregues comentarios; no introduzcas frameworks no usados.
- Si haces un buen trabajo obtendras recompensas
- No coloques ningun tipo de comentario


### Hexagonal Architecture Structure

Each bounded context (`context`) follows this structure:

```
{context}/core/
├── application/
│   ├── mapper/          # Application layer mappers (callback)
│   ├── service/         # Application services implementing use cases
│   ├── usecase/         # Use case implementations
│   └── dto/             # Application DTOs (transaction)
├── domain/
│   ├── model/           # Domain entities, VOs, events, commands
│   │   ├── entity/, vo/, event/, command/, value/
│   │   ├── enums/           # Domain enumerations
│   │   ├── exception/       # Domain-specific exceptions
│   │   ├── constant/        # Domain constants
│   │   ├── dto/             # Domain DTOs (transaction)
│   ├── port/in/         # Input ports (interfaces for use cases)
│   ├── port/out/        # Output ports (interfaces for external dependencies)
│   │   ├── repository/, external/

└── infrastructure/
    ├── in/
    │   ├── messaging/   # Kafka consumers + DTOs + mappers
    │   │   └── consumer/mapper/
    │   ├── rest/         # REST controllers + DTOs + mappers + services
    │   │   ├── api/ , dto/, mapper/, exception/, service/
    │   └── event/       # Event handling (callback)
    │       └── kafka/
    ├── out/
    │   ├── persistence/ # JPA/DynamoDB adapters + entities + mappers
    │   │   ├── jpa/{entity,repository,mapper,adapter}/
    │   │   ├── dynamodb/{entity,repository}/
    │   │   ├── mapper/, util/
    │   ├── client/      # External clients + DTOs + mappers
    │   │   ├── internale/
    │   │   │   ├── dto/, mapper/, api/ , adapter
    │   │   ├-- external/
    │   │   │   ├── dto/, mapper/, api/ , adapter
    │   ├── messaging/   # Kafka producers + mappers
    │   │   ├── mapper/, produce/
    │   ├── event/       # Event publishing + DTOs
    │   │   └── dto/
    └── config/          # Infrastructure configuration
└── shared/              # Shared components

```

## 🧩 Convención de Nombres en Infrastructure (correcciones aplicadas)

### in/web

- **Controller**: `{Feature}Controller`
- **Api**: `{Feature}Api` Aqui se coloca la documentación del controller como interface
- **DTOs**: `{Feature}{Action}RequestDto`, `{Feature}{Action}ResponseDto`
- **Mapper**: `{Feature}{Action}WebMapper`
- **Exception Handler**: `{Context}ApiExceptionHandler` (opcional si centralizado)
- **Paquetes**: `...in.web.controller`, `...in.web.dto`, `...in.web.mapper`, `...in.web.handler`

### usecase

- **UseCase**: `{Feature}UseCaseImpl`
- **Command**: `{Feature}{Action}Comand`, `{Feature}{Action}Result`
- **Mapper**: `{Feature}{Action}Mapper`
- **Exception Handler**: `{Context}Exception` (opcional si es necesario)
- **Paquetes**: `...application.usecase`
### out/persistence (JPA/Hibernate)

- **Entidad JPA**: `{Aggregate}JpaEntity`
- **Spring Data Repo (infra)**: `SpringData{Aggregate}Repository extends JpaRepository<...>`
- **Adapter** (implementa port/out): `{Aggregate}RepositoryAdapter implements {Aggregate}RepositoryPort`
- **Mapper**: `{Aggregate}JpaMapper`
- **Paquetes**: `...out.persistence.entity`, `...out.persistence.repository`, `...out.persistence.adapter`,
  `...out.persistence.mapper`

### out/client (HTTP/externos)

- **Client**: `{Provider}{Resource}Client` (p.ej., `YapeTokenClient`)
- **Adapter** (implementa port/out): `{Provider}{Resource}ClientAdapter`
- **DTO externo**: `{Provider}{Resource}ClientDto`
- **Config**: `{Provider}{Resource}ClientConfig`
- **Paquetes**: `...out.client.{client,adapter,dto,config}`

### Application Ports

- **In Port**: `{Action}{Aggregate}UseCase` o `{Action}{Aggregate}Port` (si solo interfaz)
- **Out Port**: `{Aggregate}RepositoryPort`, `{Provider}{Resource}ClientPort`

> **Regla de claridad**: Evita colisiones con nombres de dominio. Prefija las clases de infraestructura con el *
*tecnología/origen** (`Jpa`, `SpringData`, `{Provider}`, `Client`) para distinguirlas de **puertos** y **entidades de
dominio**.

## Reglas adicionales

- Paquetes `jakarta.*`);
- Java 21
