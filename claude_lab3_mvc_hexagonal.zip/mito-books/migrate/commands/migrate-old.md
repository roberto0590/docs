---
description: Comando maestro que ejecuta todo el workflow de migración MVC a Hexagonal con validaciones automáticas
---

# 🎯 Comando Maestro de Migración

Este comando ejecuta TODO el workflow de migración de forma automatizada, con checkpoints de validación en cada fase.

## ⚙️ Arquitectura Hexagonal Target (Java 21 + Spring Boot 3.5.6)

La migración seguirá la estructura hexagonal estricta definida en `java-hex-architect`:

```
{context}/core/
├── application/
│   ├── mapper/          # Application layer mappers
│   ├── service/         # Application services implementing use cases
│   ├── usecase/         # Use case implementations
│   └── dto/             # Application DTOs
├── domain/
│   ├── model/
│   │   ├── entity/      # Domain entities
│   │   ├── vo/          # Value objects
│   │   ├── event/       # Domain events
│   │   ├── command/     # Domain commands
│   │   ├── enums/       # Domain enumerations
│   │   ├── exception/   # Domain-specific exceptions
│   │   ├── constant/    # Domain constants
│   │   └── dto/         # Domain DTOs
│   ├── port/in/         # Input ports (use case interfaces)
│   └── port/out/        # Output ports (repository/external interfaces)
└── infrastructure/
    ├── in/web/
    │   ├── controller/  # REST controllers
    │   ├── dto/         # Request/Response DTOs
    │   ├── mapper/      # Web layer mappers
    │   └── exception/   # Exception handlers
    ├── out/persistence/
    │   ├── entity/      # JPA entities
    │   ├── repository/  # Spring Data repositories
    │   ├── adapter/     # Repository adapters
    │   └── mapper/      # Persistence mappers
    └── config/          # Spring configuration

**Convenciones de nomenclatura (obligatorias):**

**Web Layer (in/web):**
- Api Interface: `{Feature}Api` (documentación del controller como interfaz)
- Controller: `{Feature}Controller` (implementa `{Feature}Api`)
- DTOs Web: `{Feature}{Action}RequestDto`, `{Feature}{Action}ResponseDto`
- Mapper Web: `{Feature}{Action}WebMapper`
- Exception Handler: `{Context}ApiExceptionHandler`

**UseCase Layer (application/usecase):**
- UseCase Impl: `{Feature}UseCaseImpl`
- Command: `{Feature}{Action}Command`, `{Feature}{Action}Result`
- Mapper: `{Feature}{Action}Mapper`

**Persistence Layer (out/persistence):**
- Entidad JPA: `{Aggregate}JpaEntity`
- Spring Data Repo: `SpringData{Aggregate}Repository`
- Adapter: `{Aggregate}RepositoryAdapter`
- Mapper JPA: `{Aggregate}JpaMapper`

**Ports:**
- In Port: `{Action}{Aggregate}UseCase` o `{Action}{Aggregate}Port`
- Out Port: `{Aggregate}RepositoryPort`
```

## Flujo de Ejecución

Ejecutarás un ÚNICO comando: `/migrate`

Este comando internamente:
1. ✅ Valida el proyecto MVC
2. 📊 Genera/Actualiza documentación OpenAPI con Scalar
3. 🔍 Analiza la arquitectura actual
4. 📝 Genera Historias de Usuario (con parte técnica Y de negocio)
5. 🗺️ Mapea APIs contra documentación Scalar
6. 🔄 Migra capa por capa (con checkpoints)
7. 🧪 Genera y ejecuta tests
8. ✅ Valida que TODO se cumplió

## Comando de Inicio

```bash
/migrate [opciones]

Opciones:
  --project-path <path>    Ruta del proyecto MVC (default: actual)
  --strategy <type>        progressive|complete (default: progressive)
  --skip-backup           No crear backup (NO recomendado)
  --dry-run               Simula sin hacer cambios
  --with-scalar           Genera documentación OpenAPI con Scalar
  --auto-approve          No pide confirmación en checkpoints (peligroso)
```

## Ejemplo de Uso

```bash
# Migración completa con Scalar
/migrate --with-scalar

# Migración progresiva (por módulos)
/migrate --strategy progressive --with-scalar

# Dry run para ver qué haría
/migrate --dry-run --with-scalar
```

## Flujo Detallado

### FASE 0: Pre-validación y Detección de Progreso 🔍

**IMPORTANTE:** El comando detecta automáticamente qué fases ya están completas y te permite continuar desde donde quedaste.

```typescript
🔍 FASE 0: Validando estado del proyecto...

1. Detectando progreso de migración existente...
   📋 Leyendo estado desde .migration/state.json

   Estado actual:
   ✅ FASE 1: OpenAPI YAML - COMPLETA (api-docs/openapi.yaml existe)
   ✅ FASE 2: Análisis - COMPLETO (migration/analisis/architecture-report.md existe)
   ⏸️  FASE 3: Historias de Usuario - PENDIENTE
   ⏸️  FASE 4: Mapeo APIs - PENDIENTE
   ⏸️  FASE 5: Migración por capas - PARCIAL
      ✅ Category - Migrada a hexagonal (detectado: domain/category/*)
      ⏸️  Book - Pendiente
      ⏸️  Client - Pendiente
      ⏸️  Sale - Pendiente
   ⏸️  FASE 6: Tests - PENDIENTE
   ⏸️  FASE 7: Validación - PENDIENTE

2. Validando integridad del proyecto...
   ✓ Verificando que es proyecto Spring Boot 3.5.6
   ✓ Verificando estructura de paquetes
   ✓ Verificando que existen tests

3. Creando/Actualizando backup incremental...
   ✓ Backup guardado en .backup/2025-01-15-10-30-00/
   ✓ Solo archivos nuevos/modificados respaldados

✅ Pre-validación COMPLETA

🎯 ESTRATEGIA: Continuar desde FASE 3 (Historias de Usuario)
   - Category ya migrada: Se usará como referencia
   - Pendientes: Book, Client, Sale

💡 ¿Quieres continuar desde donde quedaste?
   [SÍ - CONTINUAR] [NO - REINICIAR TODO] [VER DETALLE]
```

**Detección automática de progreso:**

El comando verifica la existencia de:
- `api-docs/openapi.yaml` → FASE 1 completa
- `migration/analisis/architecture-report.md` → FASE 2 completa
- `migration/historias-usuario/*.md` → FASE 3 completa
- `api-contracts/**/*.yaml` → FASE 4 completa
- Estructura hexagonal por entidad:
  - `domain/{entity}/**` → Dominio migrado
  - `application/{entity}/**` → Aplicación migrada
  - `infrastructure/{entity}/**` → Infraestructura migrada
- Tests por entidad → Tests completos
- `.migration/state.json` → Estado persistido

**Archivo de estado (.migration/state.json):**
```json
{
  "version": "1.0.0",
  "lastUpdated": "2025-01-15T10:30:00Z",
  "phases": {
    "phase1_openapi": {
      "status": "completed",
      "completedAt": "2025-01-15T09:15:00Z",
      "artifacts": ["api-docs/openapi.yaml"]
    },
    "phase2_analysis": {
      "status": "completed",
      "completedAt": "2025-01-15T09:30:00Z",
      "artifacts": ["migration/analisis/architecture-report.md"]
    },
    "phase3_hu": {
      "status": "pending",
      "artifacts": []
    },
    "phase4_api_mapping": {
      "status": "pending",
      "artifacts": []
    },
    "phase5_migration": {
      "status": "in_progress",
      "entities": {
        "Category": {
          "status": "completed",
          "layers": {
            "domain": "completed",
            "application": "completed",
            "infrastructure": "completed"
          },
          "validations": {
            "hexagonal_structure": true,
            "naming_conventions": true,
            "no_layer_violations": true
          }
        },
        "Book": {"status": "pending"},
        "Client": {"status": "pending"},
        "Sale": {"status": "pending"}
      }
    },
    "phase6_tests": {
      "status": "pending",
      "artifacts": []
    },
    "phase7_validation": {
      "status": "pending",
      "artifacts": []
    }
  }
}
```

Si algo falla, el comando se detiene y te dice qué arreglar.

### FASE 1: Documentación de APIs (OpenAPI YAML) 📊

**¿Por qué primero?** Necesitamos la verdad absoluta de los contratos de API.

**IMPORTANTE:** Solo se genera el archivo YAML (NO se levanta servidor Scalar para hacer el proceso más rápido).

```typescript
📊 FASE 1: Generando documentación OpenAPI YAML...

Acciones:
1. Detectando rutas y endpoints desde controllers...
   ✓ Escaneando @RestController, @RequestMapping, @GetMapping, etc.
   ✓ Encontrados 25 endpoints

2. Generando schemas OpenAPI desde @Schema, @Operation, DTOs...
   ✓ POST /api/books - Create Book
   ✓ GET /api/books/{id} - Get Book
   ✓ PUT /api/books/{id} - Update Book
   ✓ DELETE /api/books/{id} - Delete Book
   ✓ GET /api/books/category/{name} - Get Books by Category
   ...

3. Generando archivo openapi.yaml...
   ✓ Documentación generada en api-docs/openapi.yaml
   ✓ Formato: OpenAPI 3.0.3

4. Validando que todos los endpoints tienen schemas completos...
   ✓ 25/25 endpoints documentados
   ✓ Request schemas: 100%
   ✓ Response schemas: 100%
   ✓ Error responses: 100%

📊 Documentación OpenAPI COMPLETA
   Ver archivo: api-docs/openapi.yaml

🔄 Checkpoint 1: ¿La documentación es correcta?
   - Revisa el archivo api-docs/openapi.yaml
   - Verifica que todos los endpoints estén
   - Verifica request/response schemas

[CONTINUAR] [AJUSTAR] [ABORTAR]
```

**Output generado:**
```yaml
# api-docs/openapi.yaml
openapi: 3.0.0
info:
  title: Mi Aplicación MVC API
  version: 1.0.0

paths:
  /api/users:
    post:
      summary: Create User
      operationId: createUser
      tags: [Users]
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              required: [name, email, password]
              properties:
                name:
                  type: string
                  minLength: 2
                  maxLength: 100
                  example: "Juan Pérez"
                email:
                  type: string
                  format: email
                  example: "juan@example.com"
                password:
                  type: string
                  minLength: 8
                  example: "SecurePass123!"
      responses:
        '201':
          description: User created successfully
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/User'
        '400':
          description: Validation error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ValidationError'
        '409':
          description: Email already exists
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ConflictError'

components:
  schemas:
    User:
      type: object
      properties:
        id:
          type: integer
          example: 123
        name:
          type: string
          example: "Juan Pérez"
        email:
          type: string
          example: "juan@example.com"
        status:
          type: string
          enum: [pending, active, inactive]
          example: "pending"
        createdAt:
          type: string
          format: date-time
          example: "2024-01-15T10:30:00Z"
```

### FASE 2: Análisis de Arquitectura 🔍

Usa el sub-agent `architecture-analyzer`:

```typescript
🔍 FASE 2: Analizando arquitectura MVC...

Delegando a: architecture-analyzer agent

Acciones:
1. Escaneando estructura de directorios...
   ✓ src/controllers/ - 10 archivos
   ✓ src/models/ - 8 archivos
   ✓ src/services/ - 5 archivos

2. Analizando dependencias...
   ✓ UserController → UserModel, EmailService
   ✓ OrderController → OrderModel, UserModel, PaymentService
   ...

3. Detectando lógica de negocio mal ubicada...
   ⚠ UserController.createUser() - validación de email (debería estar en dominio)
   ⚠ OrderController.calculateTotal() - lógica de pricing (debería estar en dominio)
   ...

4. Generando reporte de análisis...
   ✓ Reporte generado en migration/analisis/architecture-report.md

📊 Análisis COMPLETO
   - 10 controladores
   - 8 modelos
   - 25 endpoints
   - 15 reglas de negocio identificadas

🔄 Checkpoint 2: Revisar reporte de análisis
   Ver: migration/analisis/architecture-report.md

[CONTINUAR] [REVISAR] [ABORTAR]
```

### FASE 3: Generación de Historias de Usuario 📝

Usa el sub-agent `hu-generator` con parte TÉCNICA y de NEGOCIO:

```typescript
📝 FASE 3: Generando Historias de Usuario con criterios técnicos y de negocio...

Delegando a: hu-generator agent

Acciones:
1. Leyendo documentación OpenAPI...
   ✓ 25 endpoints parseados

2. Leyendo análisis de arquitectura...
   ✓ 15 reglas de negocio identificadas

3. Generando Historias de Usuario...
   ✓ HU-001: Crear Usuario
   ✓ HU-002: Obtener Usuario
   ✓ HU-003: Actualizar Usuario
   ...

4. Agregando criterios técnicos a cada HU...
   ✓ Criterios de aceptación (Gherkin)
   ✓ Reglas de negocio
   ✓ Validaciones técnicas
   ✓ Criterios de performance
   ✓ Criterios de seguridad

📊 Historias de Usuario COMPLETAS
   - 25 HU generadas
   - 100% con criterios técnicos
   - 100% con criterios de negocio

🔄 Checkpoint 3: Revisar Historias de Usuario
   Ver: migration/historias-usuario/

[CONTINUAR] [AJUSTAR] [ABORTAR]
```

**Ejemplo de HU generada (con parte técnica Y negocio):**

```markdown
# HU-001: Crear Usuario

## Como administrador del sistema
Quiero crear nuevos usuarios en la plataforma
Para permitir que accedan a los servicios

## Criterios de Aceptación (Negocio)

### Escenario 1: Creación exitosa
**Dado** que soy un administrador autenticado
**Y** el email "nuevo@example.com" no existe en el sistema
**Cuando** envío datos de usuario válidos
**Entonces** el usuario se crea con status "pending"
**Y** recibo confirmación con el ID del usuario
**Y** se envía email de bienvenida

### Escenario 2: Email duplicado
**Dado** que el email ya existe en el sistema
**Cuando** intento crear usuario con ese email
**Entonces** recibo error 409 Conflict
**Y** NO se crea ningún registro

### Escenario 3: Datos inválidos
**Dado** que envío datos con formato incorrecto
**Cuando** intento crear el usuario
**Entonces** recibo error 400 Bad Request
**Y** recibo lista detallada de errores de validación

## Criterios Técnicos ✅

### CT-001: API Contract
- [x] Endpoint: POST /api/users
- [x] Request schema validado contra OpenAPI
- [x] Response schema validado contra OpenAPI
- [x] Status codes: 201, 400, 401, 409, 500
- [x] Headers: Authorization required
- [ ] **CHECK**: API contract debe ser IDÉNTICO antes/después

### CT-002: Request Validation
- [x] name: string, required, min 2, max 100
- [x] email: string, required, format email, unique
- [x] password: string, required, min 8, pattern: complejidad
- [x] role: string, optional, enum [admin, user, guest], default: user
- [ ] **CHECK**: Validaciones deben funcionar exactamente igual

### CT-003: Response Structure
- [x] Success (201): { id, name, email, role, status, createdAt }
- [x] Error (400): { error, details: [{ field, message }] }
- [x] Error (409): { error, details: [] }
- [x] Password NUNCA en response
- [ ] **CHECK**: Response structure idéntica antes/después

### CT-004: Business Rules
- [x] RN-001: Email único (case-insensitive)
- [x] RN-002: Password debe cumplir complejidad
- [x] RN-003: Estado inicial siempre "pending"
- [x] RN-004: Email normalizado a lowercase
- [ ] **CHECK**: Reglas de negocio funcionan igual

### CT-005: Side Effects
- [x] Insert en tabla users
- [x] Email de bienvenida (async, no bloquea)
- [x] Audit log entry
- [x] Event "user.created" publicado
- [ ] **CHECK**: Side effects ejecutados correctamente

### CT-006: Performance
- [x] Response time < 500ms (p95)
- [x] Database query optimizado (índices)
- [x] Email async (no bloquea response)
- [ ] **CHECK**: Performance igual o mejor

### CT-007: Security
- [x] Password hasheado con bcrypt (cost 12)
- [x] No password en logs
- [x] Rate limiting: 100 req/min
- [x] Autenticación requerida (Bearer token)
- [ ] **CHECK**: Seguridad mantenida

### CT-008: Error Handling
- [x] Validación errors → 400
- [x] Auth errors → 401
- [x] Duplicate email → 409
- [x] Database errors → 500
- [x] Error messages consistentes
- [ ] **CHECK**: Error handling idéntico

## Definición de Hecho (DoD)

### Desarrollo
- [ ] Capa de dominio implementada (User entity, Email VO, etc.)
- [ ] Capa de aplicación implementada (CreateUserUseCase)
- [ ] Capa de infraestructura implementada (Controller, Repository)
- [ ] Código revisado por par

### Testing
- [ ] Tests unitarios generados desde estos criterios
- [ ] Tests de integración pasando
- [ ] Tests de contrato API validados
- [ ] Cobertura >= 80%

### Validación Técnica
- [ ] ✅ CT-001: API contract idéntico
- [ ] ✅ CT-002: Validaciones funcionan igual
- [ ] ✅ CT-003: Response structure idéntica
- [ ] ✅ CT-004: Business rules iguales
- [ ] ✅ CT-005: Side effects correctos
- [ ] ✅ CT-006: Performance OK
- [ ] ✅ CT-007: Seguridad mantenida
- [ ] ✅ CT-008: Error handling igual

### Deployment
- [ ] Build exitoso
- [ ] Tests E2E pasando
- [ ] Performance test OK
- [ ] Security scan OK

## Prioridad
- Criticidad: ALTA (funcionalidad core)
- Complejidad: MEDIA
- Orden: 1 (comenzar con este)

## Notas Técnicas
- Usar bcrypt cost factor 12
- Email service: SendGrid/AWS SES
- Event bus: EventEmitter local / RabbitMQ en prod
```

### FASE 4: Mapeo y Validación de APIs 🗺️

Usa el sub-agent `api-mapper`:

```typescript
🗺️ FASE 4: Mapeando APIs contra documentación OpenAPI...

Delegando a: api-mapper agent

Acciones:
1. Leyendo OpenAPI spec (verdad absoluta)...
   ✓ 25 endpoints en spec

2. Detectando endpoints en código actual...
   ✓ 25 endpoints encontrados en código

3. Comparando spec vs implementación...
   ✓ POST /api/users - MATCH ✅
   ✓ GET /api/users/:id - MATCH ✅
   ⚠ PUT /api/users/:id - Response shape mismatch
   ...

4. Generando fixtures de prueba...
   ✓ api-contracts/users/create-user.fixtures.ts
   ✓ api-contracts/users/get-user.fixtures.ts
   ...

5. Generando tests de contrato...
   ✓ tests/contracts/users/create-user.contract.test.ts
   ...

📊 Mapeo de APIs COMPLETO
   - 25/25 endpoints mapeados
   - 24 MATCH ✅
   - 1 mismatch detectado (será arreglado)

🔄 Checkpoint 4: Revisar mapeo de APIs
   Ver: api-contracts/

⚠️  IMPORTANTE: Estos fixtures serán la PRUEBA de que las APIs no cambian

[CONTINUAR] [AJUSTAR] [ABORTAR]
```

### FASE 5: Migración por Capas 🔄

Usa el sub-agent `java-hex-architect` + `domain-extractor` TRES VECES (una por capa):

**IMPORTANTE:** Cada capa seguirá ESTRICTAMENTE la estructura y convenciones de `java-hex-architect`.

```typescript
🔄 FASE 5: Migrando a Arquitectura Hexagonal (Java 21 + Spring Boot 3.5.6)...

▶ CAPA 1: DOMINIO (Core Business Logic)

  Delegando a: domain-extractor agent (modo: domain)
  Arquitectura: java-hex-architect

  Estructura target:
  {context}/core/domain/
  ├── model/
  │   ├── entity/       # Book.java, Sale.java, Category.java, Client.java
  │   ├── vo/           # Email.java, Money.java, ISBN.java
  │   ├── enums/        # BookStatus.java, SaleStatus.java
  │   ├── exception/    # BookNotFoundException.java, InvalidISBNException.java
  │   └── constant/     # DomainConstants.java
  └── port/out/         # BookRepositoryPort.java, CategoryRepositoryPort.java

  Acciones:
  1. Extrayendo entidades del dominio...
     ✓ Book.java creado en domain/model/entity/
     ✓ Sale.java creado en domain/model/entity/
     ✓ Category.java creado en domain/model/entity/
     ✓ Client.java creado en domain/model/entity/

  2. Creando value objects...
     ✓ ISBN.java creado en domain/model/vo/
     ✓ Money.java creado en domain/model/vo/

  3. Extrayendo enums del dominio...
     ✓ BookStatus.java creado en domain/model/enums/

  4. Creando excepciones del dominio...
     ✓ BookNotFoundException.java en domain/model/exception/
     ✓ CategoryNotFoundException.java en domain/model/exception/

  5. Creando output ports (interfaces)...
     ✓ BookRepositoryPort.java en domain/port/out/
     ✓ CategoryRepositoryPort.java en domain/port/out/
     ✓ SaleRepositoryPort.java en domain/port/out/
     ✓ ClientRepositoryPort.java en domain/port/out/

  ✅ Capa de Dominio COMPLETA (SIN dependencias externas)

  🧪 Ejecutando tests de dominio...
     ✓ 45/45 tests pasando

  🔄 Checkpoint 5.1: Revisar capa de dominio
     Ver: src/main/java/com/mitocode/{context}/core/domain/

  [CONTINUAR] [REVISAR] [ABORTAR]

▶ CAPA 2: APLICACIÓN (Use Cases)

  Delegando a: domain-extractor agent (modo: application)
  Arquitectura: java-hex-architect

  Estructura target:
  {context}/core/application/
  ├── usecase/          # CreateBookUseCase.java, FindBookByIdUseCase.java
  ├── service/          # BookApplicationService.java
  ├── dto/              # BookDto.java, CreateBookCommand.java
  └── mapper/           # BookDtoMapper.java

  {context}/core/domain/port/in/
  └──                   # CreateBookPort.java, FindBookByIdPort.java

  Acciones:
  1. Creando input ports desde HU...
     ✓ HU-001 → CreateBookPort.java en domain/port/in/
     ✓ HU-002 → FindBookByIdPort.java en domain/port/in/
     ✓ HU-003 → UpdateBookPort.java en domain/port/in/
     ✓ HU-004 → DeleteBookPort.java en domain/port/in/
     ✓ HU-005 → GetBooksByCategoryPort.java en domain/port/in/

  2. Implementando use cases...
     ✓ CreateBookUseCase.java implementa CreateBookPort
     ✓ FindBookByIdUseCase.java implementa FindBookByIdPort
     ✓ UpdateBookUseCase.java implementa UpdateBookPort
     ✓ DeleteBookUseCase.java implementa DeleteBookPort
     ✓ GetBooksByCategoryUseCase.java implementa GetBooksByCategoryPort

  3. Creando DTOs de aplicación...
     ✓ BookDto.java en application/dto/
     ✓ CreateBookCommand.java en application/dto/
     ✓ UpdateBookCommand.java en application/dto/
     ✓ BookListDto.java en application/dto/

  4. Creando mappers de aplicación...
     ✓ BookDtoMapper.java en application/mapper/

  5. Validando contra criterios técnicos HU...
     ✓ HU-001 CT-001 ✅ API contract respetado
     ✓ HU-001 CT-002 ✅ Validaciones correctas
     ✓ HU-001 CT-004 ✅ Business rules implementadas

  ✅ Capa de Aplicación COMPLETA (Dependency Inversion respetada)

  🧪 Ejecutando tests de aplicación...
     ✓ 78/78 tests pasando

  🔄 Checkpoint 5.2: Revisar capa de aplicación
     Ver: src/main/java/com/mitocode/{context}/core/application/

  [CONTINUAR] [REVISAR] [ABORTAR]

▶ CAPA 3: INFRAESTRUCTURA (Adapters)

  Delegando a: domain-extractor agent (modo: infrastructure)
  Arquitectura: java-hex-architect

  Estructura target:
  {context}/infrastructure/
  ├── in/web/
  │   ├── controller/   # BookController.java
  │   ├── dto/          # CreateBookRequestDto.java, BookResponseDto.java
  │   ├── mapper/       # BookWebMapper.java
  │   └── exception/    # BookApiExceptionHandler.java
  ├── out/persistence/
  │   ├── entity/       # BookJpaEntity.java
  │   ├── repository/   # SpringDataBookRepository.java
  │   ├── adapter/      # BookRepositoryAdapter.java
  │   └── mapper/       # BookJpaMapper.java
  └── config/           # BookstoreConfig.java, JpaConfig.java

  Acciones:
  1. Creando controllers (HTTP adapters)...
     ✓ BookController.java en infrastructure/in/web/controller/
     ✓ CategoryController.java en infrastructure/in/web/controller/
     ✓ SaleController.java en infrastructure/in/web/controller/
     ✓ ClientController.java en infrastructure/in/web/controller/

  2. Creando DTOs web (Request/Response)...
     ✓ CreateBookRequestDto.java en infrastructure/in/web/dto/
     ✓ BookResponseDto.java en infrastructure/in/web/dto/
     ✓ UpdateBookRequestDto.java en infrastructure/in/web/dto/
     ✓ BookListResponseDto.java en infrastructure/in/web/dto/

  3. Creando mappers web...
     ✓ BookWebMapper.java en infrastructure/in/web/mapper/
     ✓ CategoryWebMapper.java en infrastructure/in/web/mapper/

  4. Validando contratos API contra OpenAPI spec...
     ✓ POST /api/books - REQUEST/RESPONSE IDÉNTICOS ✅
     ✓ GET /api/books/{id} - CONTRACT VALID ✅
     ✓ PUT /api/books/{id} - CONTRACT VALID ✅
     ✓ DELETE /api/books/{id} - CONTRACT VALID ✅
     ✓ GET /api/books/category/{name} - CONTRACT VALID ✅

  5. Implementando adapters de persistencia...
     ✓ BookJpaEntity.java en infrastructure/out/persistence/entity/
     ✓ SpringDataBookRepository.java en infrastructure/out/persistence/repository/
     ✓ BookRepositoryAdapter.java implementa BookRepositoryPort ✅
     ✓ BookJpaMapper.java en infrastructure/out/persistence/mapper/

  6. Configuración Spring...
     ✓ BookstoreConfig.java en infrastructure/config/
     ✓ JpaConfig.java en infrastructure/config/
     ✓ MapperConfig.java en infrastructure/config/

  7. Exception Handlers...
     ✓ BookApiExceptionHandler.java en infrastructure/in/web/exception/
     ✓ GlobalExceptionHandler.java en infrastructure/in/web/exception/

  ✅ Capa de Infraestructura COMPLETA (Adaptadores implementados)

  🧪 Ejecutando tests de infraestructura...
     ✓ 56/56 tests pasando

  🔄 Checkpoint 5.3: Revisar capa de infraestructura
     Ver: src/main/java/com/mitocode/{context}/infrastructure/

  [CONTINUAR] [REVISAR] [ABORTAR]

▶ FASE 5.5: VALIDACIÓN DE ARQUITECTURA HEXAGONAL ✅

  **CRÍTICO**: Valida que se respetaron TODAS las reglas de arquitectura hexagonal.

  Delegando a: java-hex-architect agent (modo: validation)

  📋 VALIDACIÓN 1: Estructura de Paquetes
     ✓ domain/ existe y contiene solo lógica de negocio
     ✓ domain/model/ contiene entidades, VOs, enums, excepciones
     ✓ domain/port/in/ contiene interfaces de casos de uso (input ports)
     ✓ domain/port/out/ contiene interfaces de repositorios (output ports)
     ✓ application/ existe y contiene casos de uso
     ✓ application/usecase/ implementa ports de domain/port/in/
     ✓ infrastructure/ existe y contiene adaptadores
     ✓ infrastructure/in/web/ contiene controllers, DTOs web, mappers web
     ✓ infrastructure/out/persistence/ contiene entities JPA, repos, adapters

  📋 VALIDACIÓN 2: Convenciones de Nomenclatura
     Book:
       ✓ Book.java (domain entity)
       ✓ BookRepositoryPort.java (output port)
       ✓ CreateBookUseCase.java (input port - interface en domain/port/in/)
       ✓ CreateBookUseCaseImpl.java (implementación en application/usecase/)
       ✓ BookController.java (web adapter)
       ✓ BookJpaEntity.java (persistence entity)
       ✓ SpringDataBookRepository.java (Spring Data repo)
       ✓ BookRepositoryAdapter.java (implementa BookRepositoryPort)
       ✓ BookJpaMapper.java (mapper persistence)
       ✓ BookWebMapper.java (mapper web)

     Category:
       ✓ Category.java, CategoryId.java, CategoryName.java
       ✓ CategoryRepository.java (output port)
       ✓ CreateCategoryUseCase, GetAllCategoriesUseCase, etc.
       ✓ CategoryHexagonalController.java
       ✓ CategoryJpaEntity.java
       ✓ JpaCategoryRepository.java, JpaCategoryRepositoryAdapter.java
       ✓ CategoryMapper.java

  📋 VALIDACIÓN 3: Dependencias entre Capas (REGLA DE ORO)

     Analizando imports en cada clase...

     Domain layer (DEBE ser PURO - SIN dependencias externas):
       ✓ Book.java - NO tiene imports de jakarta.persistence ✅
       ✓ Category.java - NO tiene imports de jakarta.persistence ✅
       ✓ BookRepositoryPort.java - Solo usa clases del dominio ✅
       ✓ CategoryRepository.java - Solo usa clases del dominio ✅
       ✗ VIOLACIÓN: Category.java tiene import de jakarta.* ❌
          → Archivo: src/main/java/com/mitocode/domain/category/Category.java:3
          → Import ilegal: import jakarta.validation.constraints.NotNull;
          → FIX REQUERIDO: Usar validación en capa de aplicación, NO en dominio

     Application layer (SOLO puede depender de Domain):
       ✓ CreateBookUseCase.java - Solo usa domain/* ✅
       ✓ CreateCategoryUseCase.java - Solo usa domain/category/* ✅
       ✓ GetAllCategoriesUseCase.java - Solo usa domain/category/* ✅

     Infrastructure layer (puede depender de Domain y Application):
       ✓ BookController.java - Usa application/* y domain/* ✅
       ✓ BookJpaEntity.java - Usa jakarta.persistence (CORRECTO) ✅
       ✓ BookRepositoryAdapter.java - Implementa BookRepositoryPort ✅
       ✓ CategoryHexagonalController.java - Usa application/category/* ✅
       ✓ CategoryJpaEntity.java - Usa jakarta.persistence ✅
       ✓ JpaCategoryRepositoryAdapter.java - Implementa CategoryRepository ✅

  📋 VALIDACIÓN 4: Dependency Inversion Principle
     ✓ Domain NO depende de Infrastructure ✅
     ✓ Application NO depende de Infrastructure ✅
     ✓ Infrastructure implementa interfaces de Domain ✅
     ✓ Controllers inyectan UseCases (interfaces), NO implementaciones ✅
     ✓ UseCases inyectan RepositoryPorts (interfaces), NO implementaciones ✅

  📋 VALIDACIÓN 5: Single Responsibility Principle
     ✓ Cada UseCase hace UNA sola cosa ✅
     ✓ Entities solo contienen lógica de negocio ✅
     ✓ Controllers solo delegan a UseCases ✅
     ✓ Mappers solo mapean entre capas ✅

  📋 VALIDACIÓN 6: Ausencia de Código Legacy
     ✓ NO existen clases MVC antiguas en uso ✅
     ⚠ Detectadas clases MVC antiguas pero deprecadas:
       - src/main/java/com/mitocode/controller/BookController.java (old)
       - src/main/java/com/mitocode/service/IBookService.java (old)
       - src/main/java/com/mitocode/service/impl/BookServiceImpl.java (old)
       ℹ️  Estas clases se eliminarán al final si todos los tests pasan

  📊 RESULTADO VALIDACIÓN HEXAGONAL:

     ✅ Estructura: CORRECTA
     ✅ Nomenclatura: CORRECTA
     ❌ Dependencias: 1 VIOLACIÓN DETECTADA
     ✅ Dependency Inversion: CORRECTA
     ✅ Single Responsibility: CORRECTA
     ⚠️  Código Legacy: DETECTADO (se eliminará)

  ⚠️  VALIDACIÓN FALLIDA: Se encontraron violaciones de arquitectura hexagonal.

  🔧 ACCIÓN REQUERIDA:
     1. Revisar y corregir las violaciones detectadas
     2. Ejecutar validación nuevamente

  [CORREGIR AUTOMÁTICAMENTE] [CORREGIR MANUALMENTE] [VER DETALLE] [ABORTAR]

  → Opción seleccionada: CORREGIR AUTOMÁTICAMENTE

  🔧 Corrigiendo violaciones...
     ✓ Removiendo import jakarta.validation.constraints.NotNull de Category.java
     ✓ Moviendo validación a CategoryRequestDto en infrastructure/in/web/dto/
     ✓ Validación ahora ocurre en capa de infraestructura (correcto)

  🔄 Re-ejecutando validación...
     ✅ TODAS las validaciones pasaron

📊 Migración de Capas COMPLETA CON VALIDACIÓN HEXAGONAL
   - Dominio: ✅ (Puro, sin dependencias, validado)
   - Aplicación: ✅ (Use cases implementados, validados)
   - Infraestructura: ✅ (Adaptadores conectados, validados)
   - Arquitectura Hexagonal: ✅ (100% conforme)

📋 Convenciones aplicadas y validadas:
   ✅ Paquetes: jakarta.*
   ✅ Java 21
   ✅ Spring Boot 3.5.6
   ✅ Nomenclatura: {Feature}Controller, {Aggregate}JpaEntity, etc.
   ✅ Sin comentarios innecesarios
   ✅ SRP y empaquetado hexagonal estricto
   ✅ Dependency Inversion respetada
   ✅ Sin violaciones de capas
```

### FASE 6: Generación y Ejecución de Tests 🧪

Usa el sub-agent `test-generator`:

```typescript
🧪 FASE 6: Generando tests desde criterios de aceptación...

Delegando a: test-generator agent

Acciones:
1. Leyendo Historias de Usuario...
   ✓ 25 HU parseadas

2. Generando tests desde criterios de aceptación...

   HU-001: Crear Usuario
   ✓ Escenario 1 → test "should create user successfully"
   ✓ Escenario 2 → test "should return 409 for duplicate email"
   ✓ Escenario 3 → test "should return 400 for invalid data"

   Criterios Técnicos:
   ✓ CT-001 → test "should maintain API contract"
   ✓ CT-002 → test "should validate request correctly"
   ✓ CT-003 → test "should return correct response structure"
   ✓ CT-004 → test "should enforce business rules"
   ✓ CT-005 → test "should execute side effects"
   ✓ CT-006 → test "should meet performance criteria"
   ✓ CT-007 → test "should maintain security"
   ✓ CT-008 → test "should handle errors correctly"

3. Generando tests de contrato API...
   ✓ tests/contracts/users/create-user.contract.test.ts
   ...

4. Ejecutando TODOS los tests...

   📊 Resultados:

   Unit Tests:
   ✅ 234/234 tests pasando
   ✅ Cobertura: 87% (antes: 78%)

   Integration Tests:
   ✅ 56/56 tests pasando

   Contract Tests:
   ✅ 25/25 tests pasando
   ✅ TODOS los contratos API validados

   E2E Tests:
   ✅ 18/18 tests pasando

✅ TODOS los tests PASANDO

🔄 Checkpoint 6: Revisar resultados de tests
   Ver: coverage/index.html

[CONTINUAR] [REVISAR] [ABORTAR]
```

### FASE 7: Validación Final Exhaustiva ✅

Usa el sub-agent `migration-validator`:

```typescript
✅ FASE 7: Validación final exhaustiva...

Delegando a: migration-validator agent

📋 VALIDANDO CONTRATOS DE API

  Comparando contra OpenAPI spec (verdad absoluta):

  POST /api/users:
    Request:
      ✅ Schema idéntico
      ✅ Required fields iguales
      ✅ Validations iguales
    Response 201:
      ✅ Schema idéntico
      ✅ No expone password ✅
    Response 400:
      ✅ Error structure igual
    Response 409:
      ✅ Error message igual
    Side effects:
      ✅ Email enviado
      ✅ Event publicado
    Performance:
      ✅ 245ms (antes: 287ms) - MEJORA 14.6%

  [... todos los demás endpoints ...]

  📊 Contratos API: 25/25 VALIDADOS ✅

📋 VALIDANDO CRITERIOS TÉCNICOS DE HU

  HU-001: Crear Usuario
    ✅ CT-001: API contract idéntico
    ✅ CT-002: Validaciones funcionan igual
    ✅ CT-003: Response structure idéntica
    ✅ CT-004: Business rules iguales
    ✅ CT-005: Side effects correctos
    ✅ CT-006: Performance OK (mejora 14.6%)
    ✅ CT-007: Seguridad mantenida
    ✅ CT-008: Error handling igual

    ✅ 8/8 criterios técnicos CUMPLIDOS

  [... todas las demás HU ...]

  📊 Criterios Técnicos: 200/200 CUMPLIDOS ✅

📋 VALIDANDO LÓGICA DE NEGOCIO

  Reglas de Negocio:
    ✅ RN-001: Email único (case-insensitive)
    ✅ RN-002: Password complejidad
    ✅ RN-003: Estado inicial "pending"
    ✅ RN-004: Email normalizado
    [... todas las reglas ...]

  📊 Reglas de Negocio: 45/45 VALIDADAS ✅

📋 VALIDANDO CALIDAD DE CÓDIGO

  ✅ Linting: 0 errores
  ✅ Type checking: 0 errores
  ✅ Complejidad ciclomática: 3.2 (antes: 7.8) - MEJORA
  ✅ Acoplamiento: Bajo (antes: Alto) - MEJORA
  ✅ Cobertura: 87% (antes: 78%) - MEJORA

📋 VALIDANDO BUILD

  ✅ Build de desarrollo: OK
  ✅ Build de producción: OK
  ✅ Bundle size: 2.3MB (antes: 2.8MB) - MEJORA 17.9%

📋 GENERANDO REPORTE FINAL

  ✓ Reporte HTML generado en: reports/migration-report.html
  ✓ Reporte MD generado en: migration/FINAL-REPORT.md

═══════════════════════════════════════════════════════════
🎉 MIGRACIÓN COMPLETADA EXITOSAMENTE 🎉
═══════════════════════════════════════════════════════════

📊 RESUMEN EJECUTIVO:

  Contratos API:
    ✅ 25/25 endpoints migrados
    ✅ 0 cambios en contratos
    ✅ 100% compatibilidad

  Historias de Usuario:
    ✅ 25/25 HU completadas
    ✅ 200/200 criterios técnicos cumplidos
    ✅ 100% Definición de Hecho

  Tests:
    ✅ 234 unit tests (100% pasando)
    ✅ 56 integration tests (100% pasando)
    ✅ 25 contract tests (100% pasando)
    ✅ 18 E2E tests (100% pasando)

  Calidad:
    ✅ Cobertura: 87% (+9%)
    ✅ Performance: +14.6% mejora
    ✅ Bundle size: -17.9%
    ✅ Complejidad: -57.7% mejora

  Arquitectura:
    ✅ Dominio: Clean & Testable
    ✅ Aplicación: Use Cases bien definidos
    ✅ Infraestructura: Desacoplada

═══════════════════════════════════════════════════════════
✅ LISTO PARA PRODUCCIÓN ✅
═══════════════════════════════════════════════════════════

📄 Ver reporte completo: reports/migration-report.html

🚀 Próximos pasos:
  1. Code review del equipo
  2. Deploy a staging
  3. Smoke tests en staging
  4. Deploy a producción
```

## Estructura de Archivos Generados

```
proyecto-migrado/
├── src/
│   ├── domain/
│   ├── application/
│   └── infrastructure/
│
├── tests/
│   ├── unit/
│   ├── integration/
│   ├── contracts/
│   └── e2e/
│
├── api-docs/
│   ├── openapi.yaml              # Spec OpenAPI generado con Scalar
│   └── scalar-ui/                # UI de Scalar
│
├── api-contracts/
│   ├── users/
│   │   ├── create-user.yaml
│   │   └── create-user.fixtures.ts
│   └── orders/
│
├── migration/
│   ├── analisis/
│   │   └── architecture-report.md
│   ├── historias-usuario/
│   │   ├── HU-users.md
│   │   └── HU-orders.md
│   └── FINAL-REPORT.md
│
├── reports/
│   └── migration-report.html
│
└── .backup/
    └── 2024-01-15-10-30-00/      # Backup automático
```

## Checkpoints de Validación

En cada checkpoint, el comando:
1. Muestra el resultado de la fase
2. Te da opciones: [CONTINUAR] [AJUSTAR] [ABORTAR]
3. Espera tu confirmación antes de continuar

Si detecta algo mal, lo reporta y te pregunta cómo proceder.

## Rollback Automático

Si algo falla y decides abortar:

```typescript
❌ Migración abortada en Fase X

🔄 Ejecutando rollback...
  ✓ Restaurando desde backup
  ✓ Limpiando archivos generados
  ✓ Restaurando git status

✅ Rollback completo
   Tu proyecto está exactamente como antes
```

## Ventajas de Este Comando Único

1. ✅ **Un solo comando** - No tienes que recordar secuencia
2. ✅ **Scalar integrado** - Documentación OpenAPI automática
3. ✅ **Validación continua** - Checkpoints en cada fase
4. ✅ **Criterios técnicos** - HU con parte técnica Y negocio
5. ✅ **Prueba de cumplimiento** - Tests validan TODOS los criterios
6. ✅ **Sin riesgo** - Backup + rollback automático
7. ✅ **Trazabilidad total** - Cada decisión documentada

## Cómo Funciona Internamente

```typescript
// .claude/commands/hexagonal/migrate.md ejecuta internamente:

async function executeFullMigration(options) {
  // FASE 0: Pre-validación
  await runPreMigrationHook();

  // FASE 1: OpenAPI YAML (sin servidor Scalar para mayor velocidad)
  await invokeAgent('scalar-generator', {
    action: 'generate-openapi-yaml-only',
    startServer: false  // NO levantar servidor para hacer el proceso más rápido
  });
  await checkpoint('Revisar documentación OpenAPI YAML');

  // FASE 2: Análisis
  await invokeAgent('architecture-analyzer', {
    source: options.projectPath
  });
  await checkpoint('Revisar análisis');

  // FASE 3: HU (con criterios técnicos)
  await invokeAgent('hu-generator', {
    includeBusinessCriteria: true,
    includeTechnicalCriteria: true,
    openapiSpec: 'api-docs/openapi.yaml'
  });
  await checkpoint('Revisar HU');

  // FASE 4: Mapeo APIs
  await invokeAgent('api-mapper', {
    openapiSpec: 'api-docs/openapi.yaml',
    generateFixtures: true,
    generateContractTests: true
  });
  await checkpoint('Revisar mapeo');

  // FASE 5: Migración por capas
  for (const layer of ['domain', 'application', 'infrastructure']) {
    await invokeAgent('domain-extractor', {
      layer,
      validateAgainstHU: true
    });
    await runTests(`tests/${layer}`);
    await checkpoint(`Revisar capa ${layer}`);
  }

  // FASE 6: Tests
  await invokeAgent('test-generator', {
    fromHU: true,
    generateFromCriteria: true
  });
  await runAllTests();
  await checkpoint('Revisar tests');

  // FASE 7: Validación final
  await invokeAgent('migration-validator', {
    validateContracts: true,
    validateHUCriteria: true,
    validateBusinessRules: true
  });

  // Post-validation
  await runPostMigrationHook();

  // Reporte final
  await generateFinalReport();
}
```
