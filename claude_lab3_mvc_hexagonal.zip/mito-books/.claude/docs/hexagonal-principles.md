# Principios de Arquitectura Hexagonal

**Versión**: 1.0.0
**Framework**: Java 21 + Spring Boot 3.5.6
**Fecha**: 2025-01-15

---

## 🎯 Objetivo

Este documento define las **reglas estrictas** de arquitectura hexagonal que DEBEN cumplirse en toda migración. Todos los agentes y comandos DEBEN validar contra este documento.

---

## 📐 Estructura de Capas

### Estructura Obligatoria

```
src/main/java/com/mitocode/{context}/
├── domain/                           # CAPA 1: Dominio (Núcleo de negocio)
│   ├── model/
│   │   ├── entity/                   # Entidades del dominio
│   │   ├── vo/                       # Value Objects
│   │   ├── enums/                    # Enumeraciones del dominio
│   │   ├── exception/                # Excepciones de dominio
│   │   ├── constant/                 # Constantes del dominio
│   │   └── dto/                      # DTOs del dominio (opcional)
│   ├── port/
│   │   ├── in/                       # Input Ports (interfaces de casos de uso)
│   │   └── out/                      # Output Ports (interfaces de repositorios)
│
├── application/                      # CAPA 2: Aplicación (Casos de uso)
│   ├── usecase/                      # Implementaciones de casos de uso
│   ├── dto/                          # DTOs de aplicación
│   ├── mapper/                       # Mappers de aplicación
│   └── service/                      # Servicios de Orquestamiento de use case en caso de ser necesario (opcional)
│
└── infrastructure/                   # CAPA 3: Infraestructura (Adaptadores)
    ├── in/
    │   └── rest/
    │       ├── controller/           # Controladores REST
    │       ├── api/                  # Interface con documentación en swagger para scalar
    │       ├── dto/                  # Request/Response DTOs
    │       ├── mapper/               # Mappers web
    │       ├── service/              # Carpeta de tipo facade para hacer mapper de dto controller a  command a usecase
    │       └── exception/            # Handlers de excepciones HTTP
    ├── out/
    │   └── persistence/
    │       ├── entity/               # Entidades JPA
    │       ├── repository/           # Spring Data Repositories
    │       ├── adapter/              # Adaptadores de repositorio
    │       └── mapper/               # Mappers JPA
    │   └── client/
    │           ├── internal/          # Client internos de la empresa
    │               ├── api/           # Especificación del api
    │               ├── adapter/       # Adaptadores implementación para integración del api
    ├               ├── dto/           # Request y response al API
    │               └── mapper/        # Mappers client
    │           ├── external/          # Client externos de la empresa
    │               ├── api/           # Especificación del api
    │               ├── adapter/       # Adaptadores implementación para integración del api
    ├               ├── dto/           # Request y response al API
    │               └── mapper/        # Mappers client
    └── config/                       # Configuración
└── shared/                   # CAPA 3: Infraestructura (Adaptadores)
    └── util/                         # Util reutilizables en varias parte del proyecto
    └── config/                       # Configuración Shared


```

---

## 🔒 REGLA DE ORO: Dependencias entre Capas

### ✅ PERMITIDO

```
Infrastructure → Application → Domain
Infrastructure → Domain
```

### ❌ PROHIBIDO

```
Domain → Application  ❌
Domain → Infrastructure  ❌
Application → Infrastructure  ❌
```

### Validación de Imports

**Domain Layer (PURO - SIN dependencias externas):**
```java
// ❌ PROHIBIDO en domain/
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import org.springframework.*;
import org.hibernate.*;
import lombok.Data;  // Permitido solo @Getter/@Builder, NO @Entity
import com.fasterxml.jackson.*;

// ✅ PERMITIDO en domain/
import java.util.*;
import java.time.*;
import java.math.*;
import com.mitocode.{context}.domain.*;  // Solo clases del mismo dominio
```

**Application Layer (Solo depende de Domain):**
```java
// ❌ PROHIBIDO en application/
import org.springframework.web.*;
import jakarta.servlet.*;
import jakarta.persistence.*;

// ✅ PERMITIDO en application/
import com.mitocode.{context}.domain.*;
import org.springframework.stereotype.Service;  // Solo para @Service
import org.springframework.transaction.annotation.Transactional;  // Solo para @Transactional
import java.util.*;
```

**Infrastructure Layer (Puede usar todo):**
```java
// ✅ TODO PERMITIDO en infrastructure/
import jakarta.persistence.*;
import org.springframework.*;
import com.mitocode.{context}.domain.*;
import com.mitocode.{context}.application.*;
```

---

## 📝 Convenciones de Nomenclatura

### Domain Layer

| Tipo | Nomenclatura | Ejemplo | Ubicación |
|------|-------------|---------|-----------|
| Entity | `{Aggregate}.java` | `Book.java`, `Category.java` | `domain/model/entity/` |
| Value Object | `{Concept}.java` | `CategoryId.java`, `ISBN.java`, `Money.java` | `domain/model/vo/` |
| Enum | `{Concept}.java` | `BookStatus.java`, `SaleStatus.java` | `domain/model/enums/` |
| Exception | `{Aggregate}Exception.java` | `BookNotFoundException.java` | `domain/model/exception/` |
| Output Port | `{Aggregate}RepositoryPort.java` | `BookRepositoryPort.java` | `domain/port/out/` |
| Input Port | `{Action}{Aggregate}UseCase.java` | `CreateBookUseCase.java` | `domain/port/in/` |

### Application Layer

| Tipo | Nomenclatura | Ejemplo | Ubicación |
|------|-------------|---------|-----------|
| UseCase Impl | `{Action}{Aggregate}UseCaseImpl.java` | `CreateBookUseCaseImpl.java` | `application/usecase/` |
| Command | `{Action}{Aggregate}Command.java` | `CreateBookCommand.java` | `application/dto/` |
| Result | `{Action}{Aggregate}Result.java` | `CreateBookResult.java` | `application/dto/` |
| Mapper | `{Aggregate}ApplicationMapper.java` | `BookApplicationMapper.java` | `application/mapper/` |

### Infrastructure Layer

| Tipo | Nomenclatura | Ejemplo | Ubicación |
|------|-------------|---------|-----------|
| Controller | `{Aggregate}Controller.java` | `BookController.java` | `infrastructure/in/web/controller/` |
| Request DTO | `{Action}{Aggregate}RequestDto.java` | `CreateBookRequestDto.java` | `infrastructure/in/web/dto/` |
| Response DTO | `{Action}{Aggregate}ResponseDto.java` | `CreateBookResponseDto.java` | `infrastructure/in/web/dto/` |
| Web Mapper | `{Aggregate}WebMapper.java` | `BookWebMapper.java` | `infrastructure/in/web/mapper/` |
| JPA Entity | `{Aggregate}JpaEntity.java` | `BookJpaEntity.java` | `infrastructure/out/persistence/entity/` |
| Spring Data Repo | `SpringData{Aggregate}Repository.java` | `SpringDataBookRepository.java` | `infrastructure/out/persistence/repository/` |
| Adapter | `{Aggregate}RepositoryAdapter.java` | `BookRepositoryAdapter.java` | `infrastructure/out/persistence/adapter/` |
| JPA Mapper | `{Aggregate}JpaMapper.java` | `BookJpaMapper.java` | `infrastructure/out/persistence/mapper/` |

---

## 🎯 Principios SOLID Aplicados

### 1. Single Responsibility Principle (SRP)

**✅ CORRECTO:**
```java
// UseCase hace UNA sola cosa
@Service
public class CreateBookUseCaseImpl implements CreateBookUseCase {
    public Book create(CreateBookCommand command) {
        // Solo crea libros
    }
}
```

**❌ INCORRECTO:**
```java
// UseCase hace MUCHAS cosas
@Service
public class BookService {
    public Book create() { }
    public Book update() { }
    public Book delete() { }
    public List<Book> findAll() { }
}
```

### 2. Dependency Inversion Principle (DIP)

**✅ CORRECTO:**
```java
// Controller depende de INTERFAZ
public class BookController {
    private final CreateBookUseCase createBookUseCase;  // Interfaz (port)

    public BookController(CreateBookUseCase createBookUseCase) {
        this.createBookUseCase = createBookUseCase;
    }
}
```

**❌ INCORRECTO:**
```java
// Controller depende de IMPLEMENTACIÓN
public class BookController {
    private final CreateBookUseCaseImpl createBookUseCase;  // Implementación concreta
}
```

### 3. Open/Closed Principle (OCP)

**✅ CORRECTO:**
```java
// Nueva funcionalidad = Nueva clase
public class CreateBookUseCase { }
public class UpdateBookUseCase { }
public class DeleteBookUseCase { }
```

**❌ INCORRECTO:**
```java
// Modificar clase existente para nueva funcionalidad
public class BookUseCase {
    public void create() { }
    public void update() { }  // Modificando clase existente
}
```

---

## 🔍 Validaciones Obligatorias

### Checkpoint 1: Estructura de Paquetes

**Comando de validación:**
```bash
# Debe existir:
domain/model/entity/
domain/model/vo/
domain/port/in/
domain/port/out/
application/usecase/
application/dto/
infrastructure/in/web/controller/
infrastructure/out/persistence/adapter/
```

**Criterio de éxito:** Todos los directorios existen.

### Checkpoint 2: Nomenclatura

**Validar:**
- Entidades de dominio NO terminan en `JpaEntity`
- Entidades JPA SÍ terminan en `JpaEntity`
- UseCases tienen interfaz en `domain/port/in/` e implementación en `application/usecase/`
- Adapters implementan interfaces de `domain/port/out/`

**Criterio de éxito:** 100% de clases cumplen convenciones.

### Checkpoint 3: Pureza del Dominio

**Comando de validación:**
```bash
# Buscar imports prohibidos en domain/
grep -r "import jakarta.persistence" domain/
grep -r "import org.springframework" domain/ (excepto lombok básico)
grep -r "import jakarta.validation" domain/
```

**Criterio de éxito:** 0 matches encontrados.

### Checkpoint 4: Dependency Inversion

**Validar:**
- Controllers inyectan interfaces (`CreateBookUseCase`), no implementaciones (`CreateBookUseCaseImpl`)
- UseCases inyectan interfaces (`BookRepositoryPort`), no implementaciones (`BookRepositoryAdapter`)

**Criterio de éxito:** 100% de inyecciones son interfaces.

### Checkpoint 5: Single Responsibility

**Validar:**
- Cada UseCase tiene UN solo método público
- Cada Controller endpoint delega a UN UseCase
- Cada Mapper hace UNA sola transformación

**Criterio de éxito:** Todos cumplen SRP.

---

## 📋 Checklist de Migración por Entidad

Para cada entidad (Book, Category, Client, Sale):

### Domain Layer
- [ ] `{Entity}.java` creada en `domain/model/entity/`
- [ ] Value Objects identificados y creados en `domain/model/vo/`
- [ ] Enums extraídos a `domain/model/enums/`
- [ ] Excepciones de dominio en `domain/model/exception/`
- [ ] `{Entity}RepositoryPort.java` creada en `domain/port/out/`
- [ ] Input ports creados en `domain/port/in/` (uno por caso de uso)
- [ ] ✅ **VALIDADO**: NO tiene imports de `jakarta.*`, `org.springframework.*`

### Application Layer
- [ ] UseCase implementations en `application/usecase/`
- [ ] Cada UseCase implementa su interfaz de `domain/port/in/`
- [ ] Commands/Results en `application/dto/`
- [ ] Mappers en `application/mapper/`
- [ ] ✅ **VALIDADO**: Solo usa clases de `domain/`

### Infrastructure Layer
- [ ] Controller en `infrastructure/in/web/controller/`
- [ ] Request/Response DTOs en `infrastructure/in/web/dto/`
- [ ] Web Mapper en `infrastructure/in/web/mapper/`
- [ ] `{Entity}JpaEntity.java` en `infrastructure/out/persistence/entity/`
- [ ] `SpringData{Entity}Repository.java` en `infrastructure/out/persistence/repository/`
- [ ] `{Entity}RepositoryAdapter.java` implementa `{Entity}RepositoryPort`
- [ ] JPA Mapper en `infrastructure/out/persistence/mapper/`
- [ ] ✅ **VALIDADO**: Puede usar cualquier framework

### Tests
- [ ] Tests unitarios de dominio (NO usan Spring)
- [ ] Tests unitarios de application (mockean ports)
- [ ] Tests de integración de infrastructure (usan Spring)
- [ ] Tests de contrato API

---

## 🚨 Errores Comunes y Soluciones

### Error 1: Anotaciones JPA en Dominio

**❌ INCORRECTO:**
```java
// domain/model/entity/Book.java
@Entity  // ❌ Anotación JPA en dominio
@Table(name = "books")
public class Book {
    @Id
    @GeneratedValue
    private Long id;
}
```

**✅ CORRECTO:**
```java
// domain/model/entity/Book.java
public class Book {  // ✅ POJO puro
    private Long id;
    private String title;

    // Constructor, getters, business logic
}

// infrastructure/out/persistence/entity/BookJpaEntity.java
@Entity
@Table(name = "books")
public class BookJpaEntity {  // ✅ Anotaciones JPA en infrastructure
    @Id
    @GeneratedValue
    private Long id;
}
```

### Error 2: Validaciones en Dominio

**❌ INCORRECTO:**
```java
// domain/model/entity/Category.java
import jakarta.validation.constraints.NotNull;

public class Category {
    @NotNull  // ❌ Validación de Jakarta en dominio
    private String name;
}
```

**✅ CORRECTO:**
```java
// domain/model/entity/Category.java
public class Category {  // ✅ Validación con lógica de negocio
    private String name;

    public Category(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Name cannot be blank");
        }
        this.name = name;
    }
}

// infrastructure/in/web/dto/CreateCategoryRequestDto.java
import jakarta.validation.constraints.NotNull;

public class CreateCategoryRequestDto {
    @NotNull  // ✅ Validación Jakarta en infrastructure
    private String name;
}
```

### Error 3: Inyección de Implementaciones

**❌ INCORRECTO:**
```java
public class BookController {
    private final CreateBookUseCaseImpl useCase;  // ❌ Implementación concreta
}
```

**✅ CORRECTO:**
```java
public class BookController {
    private final CreateBookUseCase useCase;  // ✅ Interfaz (port)
}
```

---

## 📊 Métricas de Calidad

### Cobertura de Tests
- Domain: >= 90%
- Application: >= 85%
- Infrastructure: >= 70%

### Acoplamiento
- Domain: 0 dependencias externas (solo JDK)
- Application: Solo depende de Domain
- Infrastructure: Puede depender de todo

### Complejidad Ciclomática
- Por método: <= 10
- Por clase: <= 50

---

## 🔗 Referencias

- **Hexagonal Architecture** (Alistair Cockburn)
- **Clean Architecture** (Robert C. Martin)
- **Domain-Driven Design** (Eric Evans)
- **Spring Boot 3.5.6 Documentation**
- **Java 21 Documentation**

---

**Última actualización**: 2025-01-15
**Mantenido por**: Equipo de Arquitectura
