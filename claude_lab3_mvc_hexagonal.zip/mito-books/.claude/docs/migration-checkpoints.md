# Checkpoints de Validación de Migración

**Versión**: 1.0.0
**Propósito**: Validar cada paso de la migración antes de continuar al siguiente

---

## 🎯 Filosofía de Checkpoints

Cada checkpoint DEBE cumplir **100% de sus criterios** antes de avanzar. Si falla:
1. Se muestra el error específico
2. Se intenta corrección automática (si está disponible)
3. Si la corrección automática falla, se solicita corrección manual
4. Se re-ejecuta el checkpoint hasta que pase

**NO se avanza** hasta que el checkpoint actual pase completamente.

---

## CHECKPOINT 0: Estado del Proyecto

**Propósito**: Detectar progreso existente y validar integridad del proyecto

### Criterios de Validación

#### 1. Detección de Progreso
```bash
# Verificar existencia de archivos de estado
[ -f .migration/state.json ] && echo "Estado encontrado" || echo "Primera ejecución"
```

**Criterio de éxito:**
- Si existe `.migration/state.json`: Leerlo y mostrar progreso
- Si no existe: Inicializar nuevo proceso de migración

#### 2. Validación de Proyecto Spring Boot
```bash
# Verificar pom.xml
[ -f pom.xml ] && grep -q "spring-boot-starter-parent" pom.xml
# Verificar versión
grep -q "<version>3.5.6</version>" pom.xml
```

**Criterio de éxito:**
- ✅ Existe `pom.xml`
- ✅ Contiene `spring-boot-starter-parent`
- ✅ Versión es `3.5.6`

#### 3. Validación de Estructura Base
```bash
# Debe existir estructura básica
test -d src/main/java/com/mitocode
test -d src/test/java/com/mitocode
```

**Criterio de éxito:**
- ✅ Existe `src/main/java/`
- ✅ Existe `src/test/java/`

#### 4. Backup Incremental
```bash
# Crear directorio de backup con timestamp
timestamp=$(date +%Y-%m-%d-%H-%M-%S)
mkdir -p .backup/$timestamp

# Copiar solo archivos que serán modificados
rsync -av --include='*.java' --exclude='*' src/ .backup/$timestamp/src/
```

**Criterio de éxito:**
- ✅ Backup creado en `.backup/YYYY-MM-DD-HH-mm-ss/`
- ✅ Solo archivos `.java` respaldados (incremental)

### Salida Esperada
```json
{
  "checkpoint": "CP0",
  "status": "PASSED",
  "timestamp": "2025-01-15T10:30:00Z",
  "details": {
    "previousProgress": {
      "phase1_openapi": "completed",
      "phase2_analysis": "completed",
      "phase5_migration": {
        "Category": "completed",
        "Book": "pending"
      }
    },
    "resumeFrom": "PHASE_5_BOOK",
    "backupLocation": ".backup/2025-01-15-10-30-00/"
  }
}
```

---

## CHECKPOINT 1: Documentación OpenAPI YAML

**Propósito**: Generar especificación OpenAPI completa

### Criterios de Validación

#### 1. Archivo OpenAPI Generado
```bash
[ -f api-docs/openapi.yaml ]
```

**Criterio de éxito:**
- ✅ Existe `api-docs/openapi.yaml`

#### 2. Validación de Sintaxis YAML
```bash
# Usar herramienta de validación YAML
yaml-lint api-docs/openapi.yaml
```

**Criterio de éxito:**
- ✅ YAML es sintácticamente válido

#### 3. Validación de Estructura OpenAPI
```bash
# Verificar campos requeridos
grep -q "openapi:" api-docs/openapi.yaml
grep -q "info:" api-docs/openapi.yaml
grep -q "paths:" api-docs/openapi.yaml
grep -q "components:" api-docs/openapi.yaml
```

**Criterio de éxito:**
- ✅ Contiene `openapi: 3.0.x`
- ✅ Contiene `info:` con title y version
- ✅ Contiene `paths:` con endpoints
- ✅ Contiene `components:` con schemas

#### 4. Cobertura de Endpoints
```bash
# Contar controllers en código
controllers=$(find src -name "*Controller.java" | wc -l)
# Contar paths en OpenAPI
endpoints=$(grep -c "^\s*/" api-docs/openapi.yaml)

# Deben ser proporcionales
```

**Criterio de éxito:**
- ✅ Todos los controllers tienen endpoints documentados
- ✅ Cada endpoint tiene request/response schemas
- ✅ Cada endpoint tiene status codes documentados

### Salida Esperada
```json
{
  "checkpoint": "CP1",
  "status": "PASSED",
  "timestamp": "2025-01-15T10:35:00Z",
  "details": {
    "file": "api-docs/openapi.yaml",
    "endpoints": 25,
    "schemas": 15,
    "coverage": "100%"
  }
}
```

### Si Falla
- **Error**: Endpoints sin documentar
- **Acción**: Mostrar lista de endpoints faltantes
- **Re-intento**: Regenerar OpenAPI YAML
- **Máximo intentos**: 3

---

## CHECKPOINT 2: Análisis de Arquitectura

**Propósito**: Analizar estructura MVC existente

### Criterios de Validación

#### 1. Reporte Generado
```bash
[ -f migration/analisis/architecture-report.md ]
```

**Criterio de éxito:**
- ✅ Existe `migration/analisis/architecture-report.md`

#### 2. Contenido Mínimo del Reporte
```bash
# Debe contener secciones clave
grep -q "## Controllers" migration/analisis/architecture-report.md
grep -q "## Models" migration/analisis/architecture-report.md
grep -q "## Services" migration/analisis/architecture-report.md
grep -q "## Dependencies" migration/analisis/architecture-report.md
```

**Criterio de éxito:**
- ✅ Lista de Controllers
- ✅ Lista de Models/Entities
- ✅ Lista de Services
- ✅ Grafo de dependencias
- ✅ Reglas de negocio identificadas

#### 3. Entidades Detectadas
```bash
# Debe detectar las 4 entidades principales
grep -q "Book" migration/analisis/architecture-report.md
grep -q "Category" migration/analisis/architecture-report.md
grep -q "Client" migration/analisis/architecture-report.md
grep -q "Sale" migration/analisis/architecture-report.md
```

**Criterio de éxito:**
- ✅ Detectadas: Book, Category, Client, Sale
- ✅ Detectadas relaciones entre entidades
- ✅ Detectadas dependencias circulares (si existen)

### Salida Esperada
```json
{
  "checkpoint": "CP2",
  "status": "PASSED",
  "timestamp": "2025-01-15T10:40:00Z",
  "details": {
    "report": "migration/analisis/architecture-report.md",
    "entities": ["Book", "Category", "Client", "Sale"],
    "controllers": 4,
    "services": 4,
    "businessRules": 12
  }
}
```

---

## CHECKPOINT 3: Historias de Usuario

**Propósito**: Generar HU con criterios técnicos y de negocio

### Criterios de Validación

#### 1. Archivos de HU Generados
```bash
[ -d migration/historias-usuario ]
ls migration/historias-usuario/*.md | wc -l
```

**Criterio de éxito:**
- ✅ Existe directorio `migration/historias-usuario/`
- ✅ Existe al menos 1 HU por entidad (mínimo 4 archivos)

#### 2. Estructura de Cada HU
```bash
# Para cada HU, verificar estructura
for hu in migration/historias-usuario/*.md; do
  grep -q "## Como" "$hu"
  grep -q "## Criterios de Aceptación (Negocio)" "$hu"
  grep -q "## Criterios Técnicos" "$hu"
  grep -q "## Definición de Hecho" "$hu"
done
```

**Criterio de éxito:**
- ✅ Cada HU tiene formato User Story
- ✅ Cada HU tiene criterios de negocio (Gherkin)
- ✅ Cada HU tiene criterios técnicos (CT-001, CT-002, etc.)
- ✅ Cada HU tiene Definition of Done

#### 3. Cobertura de Endpoints
```bash
# Cada endpoint debe tener su HU
endpoints_in_openapi=$(grep -c "^\s*/" api-docs/openapi.yaml)
hu_count=$(ls migration/historias-usuario/*.md | wc -l)

# Debe haber al menos 1 HU por endpoint principal
```

**Criterio de éxito:**
- ✅ Cada operación CRUD tiene su HU
- ✅ Cada HU referencia un endpoint de OpenAPI

### Salida Esperada
```json
{
  "checkpoint": "CP3",
  "status": "PASSED",
  "timestamp": "2025-01-15T10:45:00Z",
  "details": {
    "directory": "migration/historias-usuario/",
    "userStories": 16,
    "coverage": "100%",
    "entities": {
      "Book": 5,
      "Category": 5,
      "Client": 3,
      "Sale": 3
    }
  }
}
```

---

## CHECKPOINT 4: Mapeo de APIs

**Propósito**: Mapear endpoints actuales contra OpenAPI spec

### Criterios de Validación

#### 1. Directorio de Contratos
```bash
[ -d api-contracts ]
ls api-contracts/**/*.yaml | wc -l
```

**Criterio de éxito:**
- ✅ Existe `api-contracts/`
- ✅ Existe subdirectorio por entidad
- ✅ Cada endpoint tiene su contrato YAML

#### 2. Tests de Contrato Generados
```bash
find src/test -name "*ContractTest.java" | wc -l
```

**Criterio de éxito:**
- ✅ Existen tests de contrato
- ✅ Al menos 1 test por endpoint crítico

#### 3. Validación de Contratos
```bash
# Ejecutar tests de contrato
./mvnw test -Dtest=*ContractTest
```

**Criterio de éxito:**
- ✅ Todos los tests de contrato pasan
- ✅ 0 mismatches entre código y OpenAPI spec

### Salida Esperada
```json
{
  "checkpoint": "CP4",
  "status": "PASSED",
  "timestamp": "2025-01-15T10:50:00Z",
  "details": {
    "contracts": 25,
    "matches": 25,
    "mismatches": 0,
    "tests": "PASSED"
  }
}
```

---

## CHECKPOINT 5: Migración de Dominio

**Propósito**: Migrar capa de dominio (por entidad)

**Referencia**: `.claude/docs/hexagonal-principles.md`

### Criterios de Validación

#### 1. Estructura de Paquetes
```bash
# Para entidad Book
test -d src/main/java/com/mitocode/domain/book/model/entity
test -d src/main/java/com/mitocode/domain/book/port/in
test -d src/main/java/com/mitocode/domain/book/port/out
```

**Criterio de éxito:**
- ✅ Existe `domain/{entity}/model/entity/`
- ✅ Existe `domain/{entity}/port/in/`
- ✅ Existe `domain/{entity}/port/out/`

#### 2. Pureza del Dominio (CRÍTICO)
```bash
# Buscar imports prohibidos
grep -r "import jakarta.persistence" src/main/java/com/mitocode/domain/
grep -r "import org.springframework" src/main/java/com/mitocode/domain/ | grep -v "lombok"
grep -r "import jakarta.validation" src/main/java/com/mitocode/domain/
```

**Criterio de éxito:**
- ✅ 0 imports de `jakarta.persistence.*`
- ✅ 0 imports de `org.springframework.*` (excepto lombok básico)
- ✅ 0 imports de `jakarta.validation.*`
- ✅ 0 imports de `com.fasterxml.jackson.*`

#### 3. Nomenclatura de Clases
```bash
# Verificar que existan clases con nombres correctos
test -f src/main/java/com/mitocode/domain/book/model/entity/Book.java
test -f src/main/java/com/mitocode/domain/book/port/out/BookRepositoryPort.java
```

**Criterio de éxito:**
- ✅ Entity: `{Entity}.java` (no `{Entity}JpaEntity.java`)
- ✅ Repository Port: `{Entity}RepositoryPort.java`
- ✅ Value Objects (si existen): en `model/vo/`

#### 4. Tests de Dominio
```bash
# Ejecutar tests de dominio (NO deben usar Spring)
./mvnw test -Dtest=**domain**.*Test
```

**Criterio de éxito:**
- ✅ Tests de dominio NO usan `@SpringBootTest`
- ✅ Tests de dominio NO usan `@Autowired`
- ✅ Todos los tests pasan

### Salida Esperada
```json
{
  "checkpoint": "CP5_DOMAIN_BOOK",
  "status": "PASSED",
  "timestamp": "2025-01-15T11:00:00Z",
  "details": {
    "entity": "Book",
    "structure": "VALID",
    "purity": "VALID",
    "illegalImports": 0,
    "tests": "PASSED",
    "coverage": "92%"
  }
}
```

### Si Falla
- **Error**: Imports prohibidos detectados
- **Acción**: Mostrar lista de archivos con violaciones
- **Corrección Automática**: Remover imports y mover lógica a infrastructure
- **Re-intento**: Re-validar pureza del dominio

---

## CHECKPOINT 6: Migración de Aplicación

**Propósito**: Migrar capa de aplicación (por entidad)

**Referencia**: `.claude/docs/hexagonal-principles.md`

### Criterios de Validación

#### 1. Estructura de Paquetes
```bash
test -d src/main/java/com/mitocode/application/book/usecase
test -d src/main/java/com/mitocode/application/book/dto
test -d src/main/java/com/mitocode/application/book/mapper
```

**Criterio de éxito:**
- ✅ Existe `application/{entity}/usecase/`
- ✅ Existe `application/{entity}/dto/`
- ✅ Existe `application/{entity}/mapper/`

#### 2. UseCases Implementan Ports
```bash
# Verificar que UseCases implementen interfaces de domain/port/in/
grep -r "implements.*UseCase" src/main/java/com/mitocode/application/
```

**Criterio de éxito:**
- ✅ Cada UseCase implementa una interfaz de `domain/port/in/`
- ✅ Cada UseCase tiene UNA sola responsabilidad (1 método público)

#### 3. Dependencias Correctas
```bash
# Application solo puede importar domain
grep -r "import com.mitocode.infrastructure" src/main/java/com/mitocode/application/
```

**Criterio de éxito:**
- ✅ 0 imports de `infrastructure.*`
- ✅ Solo imports de `domain.*`
- ✅ Solo imports de JDK y Spring annotations básicas

#### 4. Tests de Aplicación
```bash
./mvnw test -Dtest=**application**.*Test
```

**Criterio de éxito:**
- ✅ Tests mockean repositoryPorts
- ✅ Tests NO usan base de datos real
- ✅ Todos los tests pasan

### Salida Esperada
```json
{
  "checkpoint": "CP6_APPLICATION_BOOK",
  "status": "PASSED",
  "timestamp": "2025-01-15T11:10:00Z",
  "details": {
    "entity": "Book",
    "useCases": 5,
    "dip": "VALID",
    "srp": "VALID",
    "tests": "PASSED",
    "coverage": "88%"
  }
}
```

---

## CHECKPOINT 7: Migración de Infraestructura

**Propósito**: Migrar capa de infraestructura (por entidad)

**Referencia**: `.claude/docs/hexagonal-principles.md`

### Criterios de Validación

#### 1. Estructura de Paquetes
```bash
test -d src/main/java/com/mitocode/infrastructure/book/in/web/controller
test -d src/main/java/com/mitocode/infrastructure/book/out/persistence/adapter
```

**Criterio de éxito:**
- ✅ Existe `infrastructure/{entity}/in/web/controller/`
- ✅ Existe `infrastructure/{entity}/in/web/dto/`
- ✅ Existe `infrastructure/{entity}/out/persistence/entity/`
- ✅ Existe `infrastructure/{entity}/out/persistence/adapter/`

#### 2. Adapters Implementan Ports
```bash
# Verificar que Adapters implementen interfaces de domain/port/out/
grep -r "implements.*RepositoryPort" src/main/java/com/mitocode/infrastructure/
```

**Criterio de éxito:**
- ✅ Cada Adapter implementa un RepositoryPort
- ✅ Adapters usan Spring Data Repositories internamente

#### 3. Controllers Inyectan UseCases (Interfaces)
```bash
# Verificar que Controllers NO inyecten implementaciones
grep -r "private final.*UseCaseImpl" src/main/java/com/mitocode/infrastructure/
```

**Criterio de éxito:**
- ✅ 0 inyecciones de `*UseCaseImpl`
- ✅ Solo inyecciones de interfaces (`*UseCase`)

#### 4. JPA Entities Separadas
```bash
# Verificar que JPA entities estén en infrastructure
test -f src/main/java/com/mitocode/infrastructure/book/out/persistence/entity/BookJpaEntity.java
```

**Criterio de éxito:**
- ✅ JPA Entity termina en `JpaEntity.java`
- ✅ JPA Entity está en `infrastructure/out/persistence/entity/`
- ✅ Existe mapper entre Domain Entity y JPA Entity

#### 5. Tests de Infraestructura
```bash
./mvnw test -Dtest=**infrastructure**.*Test
```

**Criterio de éxito:**
- ✅ Tests usan `@SpringBootTest` o `@DataJpaTest`
- ✅ Tests validan integración con BD
- ✅ Todos los tests pasan

### Salida Esperada
```json
{
  "checkpoint": "CP7_INFRASTRUCTURE_BOOK",
  "status": "PASSED",
  "timestamp": "2025-01-15T11:20:00Z",
  "details": {
    "entity": "Book",
    "controllers": 1,
    "adapters": 1,
    "dip": "VALID",
    "tests": "PASSED",
    "coverage": "75%"
  }
}
```

---

## CHECKPOINT 8: Validación Hexagonal

**Propósito**: Validar arquitectura hexagonal completa

**Referencia**: `.claude/docs/hexagonal-principles.md`

### Criterios de Validación

#### 1. Estructura Completa
```bash
# Verificar que las 3 capas existen para cada entidad
for entity in Book Category Client Sale; do
  test -d src/main/java/com/mitocode/domain/${entity,,}
  test -d src/main/java/com/mitocode/application/${entity,,}
  test -d src/main/java/com/mitocode/infrastructure/${entity,,}
done
```

**Criterio de éxito:**
- ✅ Todas las entidades tienen las 3 capas

#### 2. Regla de Oro: Dependencias
```bash
# Script de validación exhaustiva
python3 .claude/scripts/validate-dependencies.py
```

**Criterio de éxito:**
- ✅ Domain NO importa Application ni Infrastructure
- ✅ Application NO importa Infrastructure
- ✅ Infrastructure puede importar Domain y Application

#### 3. Convenciones de Nomenclatura
```bash
# Verificar nomenclatura según tabla de hexagonal-principles.md
python3 .claude/scripts/validate-naming.py
```

**Criterio de éxito:**
- ✅ 100% de clases cumplen convenciones

#### 4. Principios SOLID
```bash
# Verificar SRP, DIP, etc.
python3 .claude/scripts/validate-solid.py
```

**Criterio de éxito:**
- ✅ SRP: Cada clase tiene 1 responsabilidad
- ✅ DIP: Inyección de interfaces, no implementaciones
- ✅ OCP: Nuevas funcionalidades = nuevas clases

### Salida Esperada
```json
{
  "checkpoint": "CP8_HEXAGONAL_VALIDATION",
  "status": "PASSED",
  "timestamp": "2025-01-15T11:30:00Z",
  "details": {
    "structure": "VALID",
    "dependencies": "VALID",
    "naming": "VALID",
    "solid": "VALID",
    "violations": 0
  }
}
```

### Si Falla
- **Error**: Violaciones de dependencias detectadas
- **Acción**: Mostrar lista detallada de violaciones
- **Corrección Automática**: Intentar mover clases a la capa correcta
- **Re-intento**: Re-validar hasta que pase

---

## CHECKPOINT 9: Tests Completos

**Propósito**: Ejecutar todos los tests y validar cobertura

### Criterios de Validación

#### 1. Todos los Tests Pasan
```bash
./mvnw test
```

**Criterio de éxito:**
- ✅ 0 tests fallidos
- ✅ 0 tests ignorados

#### 2. Cobertura de Código
```bash
./mvnw jacoco:report
```

**Criterio de éxito:**
- ✅ Domain: >= 90%
- ✅ Application: >= 85%
- ✅ Infrastructure: >= 70%

#### 3. Tests de Contrato API
```bash
./mvnw test -Dtest=*ContractTest
```

**Criterio de éxito:**
- ✅ Todos los contratos API validados
- ✅ Request/Response structures idénticas

### Salida Esperada
```json
{
  "checkpoint": "CP9_TESTS",
  "status": "PASSED",
  "timestamp": "2025-01-15T11:40:00Z",
  "details": {
    "totalTests": 325,
    "passed": 325,
    "failed": 0,
    "coverage": {
      "domain": "92%",
      "application": "88%",
      "infrastructure": "76%"
    }
  }
}
```

---

## CHECKPOINT 10: Build Final

**Propósito**: Validar que el proyecto compila y ejecuta

### Criterios de Validación

#### 1. Build Exitoso
```bash
./mvnw clean install
```

**Criterio de éxito:**
- ✅ BUILD SUCCESS
- ✅ 0 errores de compilación
- ✅ 0 warnings críticos

#### 2. Aplicación Arranca
```bash
./mvnw spring-boot:run &
sleep 30
curl http://localhost:8080/actuator/health
```

**Criterio de éxito:**
- ✅ Aplicación arranca sin errores
- ✅ Health endpoint responde OK
- ✅ Todos los beans se crean correctamente

#### 3. Endpoints Funcionales
```bash
# Probar endpoints principales
curl -X POST http://localhost:8080/api/books -d '{"title":"Test"}'
curl http://localhost:8080/api/books/1
```

**Criterio de éxito:**
- ✅ Endpoints responden
- ✅ Formato de respuesta correcto
- ✅ Base de datos funciona

### Salida Esperada
```json
{
  "checkpoint": "CP10_BUILD",
  "status": "PASSED",
  "timestamp": "2025-01-15T11:50:00Z",
  "details": {
    "build": "SUCCESS",
    "startup": "OK",
    "health": "UP",
    "endpoints": "FUNCTIONAL"
  }
}
```

---

## 📊 Persistencia de Estado

Después de cada checkpoint exitoso, actualizar `.migration/state.json`:

```json
{
  "version": "1.0.0",
  "lastCheckpoint": "CP7_INFRASTRUCTURE_BOOK",
  "lastUpdate": "2025-01-15T11:20:00Z",
  "checkpoints": {
    "CP0": { "status": "PASSED", "timestamp": "2025-01-15T10:30:00Z" },
    "CP1": { "status": "PASSED", "timestamp": "2025-01-15T10:35:00Z" },
    "CP2": { "status": "PASSED", "timestamp": "2025-01-15T10:40:00Z" },
    "CP3": { "status": "PASSED", "timestamp": "2025-01-15T10:45:00Z" },
    "CP4": { "status": "PASSED", "timestamp": "2025-01-15T10:50:00Z" },
    "CP5_DOMAIN_BOOK": { "status": "PASSED", "timestamp": "2025-01-15T11:00:00Z" },
    "CP6_APPLICATION_BOOK": { "status": "PASSED", "timestamp": "2025-01-15T11:10:00Z" },
    "CP7_INFRASTRUCTURE_BOOK": { "status": "PASSED", "timestamp": "2025-01-15T11:20:00Z" },
    "CP8_HEXAGONAL_VALIDATION": { "status": "IN_PROGRESS" }
  },
  "entities": {
    "Book": { "domain": "PASSED", "application": "PASSED", "infrastructure": "PASSED" },
    "Category": { "domain": "PASSED", "application": "PASSED", "infrastructure": "PASSED" },
    "Client": { "domain": "PENDING", "application": "PENDING", "infrastructure": "PENDING" },
    "Sale": { "domain": "PENDING", "application": "PENDING", "infrastructure": "PENDING" }
  }
}
```

---

## 🔁 Lógica de Re-intento

Para cada checkpoint fallido:

```typescript
let attempts = 0;
const MAX_ATTEMPTS = 3;

while (attempts < MAX_ATTEMPTS) {
  const result = await runCheckpoint(checkpointId);

  if (result.status === "PASSED") {
    saveCheckpointState(checkpointId, result);
    return SUCCESS;
  }

  attempts++;

  if (result.autoFixAvailable) {
    await applyAutoFix(result.violations);
  } else {
    await requestManualFix(result.violations);
    await waitForUserConfirmation();
  }
}

// Si después de 3 intentos sigue fallando
return ABORT_MIGRATION;
```

---

**Última actualización**: 2025-01-15
**Mantenido por**: Equipo de Arquitectura