# Claude Toolkit Generator - Complete Guide

## 📚 Overview

The Claude Toolkit Generator is a meta-toolkit that helps you create professional Claude Code agents and commands following best practices and official conventions.

## 🎯 What It Does

- **Creates agents** with proper YAML front matter, structured workflows, and validation
- **Creates commands** with TodoWrite integration, phased workflows, and success criteria
- **Enforces best practices** from official Claude Code conventions
- **NO COMMENTS RULE**: All generated code examples are self-explanatory without comments

## 📦 Components

### 1. Agent: `claude-toolkit-generator`
**File**: `.claude/agents/claude-toolkit-generator.md`

Expert in creating Claude Code commands and agents. Contains:
- Agent creation templates and patterns
- Command creation templates and patterns
- Quality checklists for validation
- Reference to excellent existing agents/commands
- Critical requirements and best practices

### 2. Command: `/create-agent`
**File**: `.claude/commands/create-agent.md`

Interactive command that:
1. Gathers requirements from user
2. Analyzes similar agents for reference
3. Generates agent with all required sections
4. Validates structure and quality
5. Saves to `.claude/agents/{name}.md`
6. Updates INDEX.md
7. Provides usage report

### 3. Command: `/create-command`
**File**: `.claude/commands/create-command.md`

Interactive command that:
1. Gathers requirements from user
2. Analyzes similar commands for reference
3. Generates command with TodoWrite integration
4. Validates structure and quality
5. Saves to `.claude/commands/{name}.md`
6. Updates INDEX.md
7. Provides usage report

## 🚀 Quick Start

### Create a New Agent

```bash
/create-agent
```

Claude will ask for:
- Agent name (kebab-case)
- Description (one-line)
- Tools needed
- Primary objective
- Input files to analyze
- Output location
- Workflow phases

### Create a New Command

```bash
/create-command
```

Claude will ask for:
- Command name (without `/`)
- Description (one-line)
- Associated agent (if any)
- Primary task
- Workflow phases
- Output location
- Success criteria

## 📋 Agent Structure

### Required YAML Front Matter

```yaml
---
name: agent-name
description: One-line description
tools: [Read, Write, Edit, Grep, Glob, Bash]
model: claude-sonnet-4-5
---
```

### Required Sections (in order)

1. **Introduction**: `You are an expert {role}...`
2. **Mission** (🎯): Clear objective statement
3. **Process** (📋): Step-by-step workflow with substeps
4. **Quality Requirements** (📊): MUST/MUST NOT criteria
5. **Output Format** (📝): Success report template
6. **Commands Reference** (🔍): Bash commands
7. **Success Criteria** (🎯): Measurable completion criteria
8. **Important Notes** (⚠️): Critical rules and reminders

### Example Agent Template

```markdown
---
name: my-agent
description: Does something useful
tools: [Read, Write, Grep]
model: claude-sonnet-4-5
---

You are an expert in {domain}.

## 🎯 Mission

{What this agent accomplishes}

## 📋 Process

### Step 1: Discovery Phase

**1.1 Find Files:**
```bash
find src -name "*.java"
```

Extract {data} from each file.

**1.2 Analyze Content:**
For each file:
- {Action 1}
- {Action 2}

### Step 2: Generation Phase

{How to create output}

### Step 3: Validation

Before saving:
- ✅ {Check 1}
- ✅ {Check 2}

### Step 4: Output

**4.1 Save:**
Write to `{path}`

**4.2 Report:**
{What to tell user}

## 📊 Quality Requirements

### MUST Include:
- ✅ {Requirement}

### MUST NOT Include:
- ❌ {Anti-requirement}

## 📝 Output Format

### Success Report:
```markdown
✅ {Task} Complete!

📊 Statistics:
   - {Metric}: {value}

📁 Location: {path}
```

## 🔍 Commands Reference

```bash
find src -name "*.java"
grep "pattern" file
```

## 🎯 Success Criteria

ONLY successful if:
- ✅ {Measurable criterion 1}
- ✅ {Measurable criterion 2}

## ⚠️ Important Notes

1. **No comments**: Code must be self-explanatory
2. **{Critical rule}**: {Explanation}

---

**Begin execution now.**
```

## 📋 Command Structure

### Required Elements

1. **Title**: `# Command Name`
2. **Description**: One or two sentences
3. **Instructions**: `You are operating as {role}...`
4. **TodoWrite Checklist**: Numbered list of steps
5. **Phased Workflow**: Clear sections with bash commands
6. **Quality Requirements**: MUST/MUST NOT lists
7. **Success Criteria**: Checkboxes
8. **Ending**: `**Begin execution now.**`

### Example Command Template

```markdown
# My Command

{Description of what this command does}

## Instructions

You are a **{Role}**.

### Task Breakdown

Use the TodoWrite tool to create this checklist:

1. {Step 1}
2. {Step 2}
3. {Step 3}

### Discovery Phase

**Step 1: Find Files**
```bash
find src -name "*.java"
```

{What to do with results}

**Step 2: {Action}**
{Instructions}

### Analysis Phase

{Continue with phases}

### Output Phase

Save to: `{path}`

## Quality Requirements

### MUST:
- ✅ {Requirement}

### MUST NOT:
- ❌ {Anti-requirement}

## Success Criteria

Mark complete when:
- [ ] {Criterion 1}
- [ ] {Criterion 2}
- [ ] {Output saved}

---

**Begin execution now.** Use TodoWrite to track progress.
```

## 📊 Quality Standards

### MUST Include (Agents)

- ✅ Valid YAML front matter
- ✅ All 8 required sections
- ✅ Numbered steps with substeps (1.1, 1.2, etc.)
- ✅ Concrete bash commands (NO placeholders)
- ✅ Measurable success criteria
- ✅ Output format specification
- ✅ Emojis for section headers
- ✅ "Begin execution now" ending

### MUST Include (Commands)

- ✅ Clear title and description
- ✅ TodoWrite integration
- ✅ Phased workflow
- ✅ Concrete bash commands
- ✅ Quality requirements
- ✅ Success checkboxes
- ✅ "Begin execution now" ending

### MUST NOT Include (Both)

- ❌ Vague instructions
- ❌ Placeholder commands like `{command}`
- ❌ Missing output locations
- ❌ Undefined success criteria
- ❌ **CODE COMMENTS** (code must be self-explanatory)
- ❌ Instructional comments in snippets
- ❌ Sections out of order

## 🔍 Best Practices

### 1. Use Concrete Commands

**Good:**
```bash
find src/main/java -path "*/infrastructure/in/rest/controller/*.java"
grep -r "@RestController" src/main/java
```

**Bad:**
```bash
find {source} -name "{pattern}"
grep "{text}" {file}
```

### 2. Numbered Substeps

**Good:**
```markdown
### Step 1: Discovery

**1.1 Find Controllers:**
{Instructions}

**1.2 Extract Endpoints:**
{Instructions}
```

**Bad:**
```markdown
### Discovery

Find controllers and extract endpoints.
```

### 3. Measurable Success Criteria

**Good:**
```markdown
- ✅ All 15 endpoints documented (0 missed)
- ✅ File saved to .claude/tasks/output.yaml
- ✅ YAML syntax valid (no errors)
```

**Bad:**
```markdown
- ✅ All endpoints documented
- ✅ File saved
- ✅ Syntax is good
```

### 4. NO Comments Rule

**Good:**
```java
public class Book {
    private Long id;
    private String title;
    private BigDecimal price;
}
```

**Bad:**
```java
public class Book {
    private Long id;         // Primary key
    private String title;    // Book title
    private BigDecimal price; // Price in USD
}
```

### 5. Self-Explanatory Code

Code examples should be clear without comments:
- Use descriptive variable names
- Follow naming conventions
- Structure code logically
- Extract methods with clear names

## 📖 Examples

### Example: Create Documentation Generator

**User request:** "Create an agent to generate README files"

**Command:**
```
/create-agent
```

**Conversation:**
```
Agent name? readme-generator
Description? Generates comprehensive README.md from project structure
Tools? [Read, Write, Glob, Grep]
Primary objective? Analyze project and create README with sections
Input files? pom.xml, src/** structure, existing docs
Output? README.md in project root
Workflow phases?
  1. Discovery - Check existing README, analyze project
  2. Analysis - Extract metadata (name, version, dependencies)
  3. Structure - Determine sections (Overview, Setup, Usage, etc.)
  4. Generation - Create markdown content
  5. Validation - Check formatting, completeness
  6. Output - Save and report
```

**Generated agent** includes:
- YAML front matter with `readme-generator` name
- 🎯 Mission: "Generate comprehensive README.md..."
- 📋 Process with 6 steps (Discovery, Analysis, etc.)
- Concrete bash commands (`grep`, `find`, etc.)
- Quality requirements (sections required, format validation)
- Success criteria (README created, all sections present)
- No code comments

### Example: Create Build Command

**User request:** "Create a command to build and run tests"

**Command:**
```
/create-command
```

**Conversation:**
```
Command name? build-test
Description? Build project and run all tests with coverage
Associated agent? None (simple bash workflow)
Primary task? Execute Maven build with tests
Workflow phases?
  1. Discovery - Check Maven configuration
  2. Build - Run clean compile
  3. Test - Execute tests with coverage
  4. Report - Display results and coverage
Output? target/site/jacoco/index.html (coverage report)
Success criteria? Build succeeds, all tests pass, coverage >80%
```

**Generated command** includes:
- Title: `# Build Test`
- TodoWrite checklist (4 items)
- 4 phases with Maven commands
- Quality requirements (coverage threshold)
- Success checkboxes
- "Begin execution now"

## 🎓 Advanced Usage

### Creating Multi-Agent Workflows

When creating a command that orchestrates multiple agents:

1. **List agent sequence** in TodoWrite checklist
2. **Create phase per agent** with invocation pattern
3. **Add integration phase** to combine results
4. **Include validation** for each agent's output

Example:
```markdown
### Phase 1: Generate Code

Use Task tool with subagent_type="java-hex-architect"

Wait for completion, verify structure.

### Phase 2: Validate Architecture

Use Task tool with subagent_type="hu-reviewer"

Wait for validation report.

### Phase 3: Integration

Combine results, check compliance.
```

### Reusable Patterns

Store common patterns for reuse:

**Discovery Pattern:**
```bash
find . -maxdepth 3 -name "pom.xml"
grep "<version>" pom.xml | head -1
ls -la src/main/java
```

**Analysis Pattern:**
```bash
find src -path "*/pattern/*.java"
for file in $(result); do
  grep "@Annotation" $file
done
```

**Validation Pattern:**
```markdown
Before saving:
- ✅ {Entity} count matches ({expected} = {actual})
- ✅ Output format valid ({syntax} check passed)
- ✅ No errors detected (0 errors)
```

## 🔧 Customization

### Adding Custom Sections

For domain-specific agents, add sections after standard ones:

```markdown
## 📚 Domain-Specific Rules

### {Your Domain} Conventions:

| Pattern | Output |
|---------|--------|
| {A}     | {B}    |

### {Your Domain} Validation:

- ✅ {Custom check 1}
- ✅ {Custom check 2}
```

### Template Variations

Create templates for common agent types:

- **Generators**: Discovery → Analysis → Generation → Validation → Output
- **Validators**: Load References → Analyze Code → Check Criteria → Report
- **Migrators**: Read Source → Plan Migration → Transform → Validate → Save

## 📝 Maintenance

### Updating Agents/Commands

1. Read existing file
2. Use `/create-agent` or `/create-command` with same name
3. Review differences
4. Merge manually if needed

### Version Control

Best practices:
- Commit agents/commands to git
- Document major changes in commit messages
- Tag versions for releases
- Keep INDEX.md updated

## ✅ Success Checklist

After creating agents/commands, verify:

**For Agents:**
- [ ] YAML front matter valid
- [ ] All 8 sections present
- [ ] Concrete bash commands (no placeholders)
- [ ] Success criteria measurable
- [ ] No code comments
- [ ] "Begin execution now" ending
- [ ] Saved to `.claude/agents/{name}.md`
- [ ] INDEX.md updated

**For Commands:**
- [ ] Title and description clear
- [ ] TodoWrite integration
- [ ] Phased workflow
- [ ] Concrete bash commands
- [ ] Success checkboxes
- [ ] No code comments
- [ ] "Begin execution now" ending
- [ ] Saved to `.claude/commands/{name}.md`
- [ ] INDEX.md updated

## 🆘 Troubleshooting

### Agent not found

**Problem**: Task tool can't find agent
**Solution**: Check filename matches `name` in YAML front matter

### Command not recognized

**Problem**: `/command` not found
**Solution**: Restart Claude Code to reload commands

### Validation failures

**Problem**: Generated agent/command has issues
**Solution**: Review quality checklists, regenerate with corrections

### No comments rule violations

**Problem**: Generated code has comments
**Solution**: Emphasize "NO COMMENTS" when asking for generation

## 📚 References

**Official Docs**: `.claude/docs/INDEX.md`

**Example Agents**:
- `swagger-expert.md` - Documentation generator
- `hu-reviewer.md` - Validator with detailed reporting
- `java-hex-architect.md` - Code generator

**Example Commands**:
- `swagger.md` - Clear phased workflow
- `hexdev.md` - Multi-agent orchestration
- `create-agent.md` - This toolkit's command

---

**Created**: 2025-10-18
**Version**: 1.0
**Maintainer**: Claude Toolkit Generator