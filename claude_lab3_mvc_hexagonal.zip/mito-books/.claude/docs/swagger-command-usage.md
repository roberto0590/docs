# Swagger Command Usage Guide

## Overview

The `/swagger` command automatically generates comprehensive OpenAPI 3.0 documentation for your Spring Boot REST API by analyzing controllers, DTOs, and exception handlers following hexagonal architecture principles.

## Quick Start

```bash
/swagger
```

That's it! The command will:
1. Analyze your entire Spring Boot project structure
2. Extract all REST endpoints from controllers
3. Generate OpenAPI schemas from DTOs
4. Include validation constraints
5. Document error responses
6. Save to `.claude/tasks/03-swagger.yaml`

## What Gets Generated

### Endpoint Documentation
- All HTTP methods (GET, POST, PUT, PATCH, DELETE)
- Path parameters, query parameters, request bodies
- Response types and status codes
- Operation IDs and descriptions

### Schema Definitions
- Request DTOs with validation constraints
- Response DTOs with field types
- Generic response wrappers (`GenericResponse<T>`)
- Error response schemas (`CustomErrorResponse`)

### Validation Constraints
The command automatically converts Jakarta Bean Validation annotations to OpenAPI constraints:

| Java Annotation | OpenAPI Constraint |
|----------------|-------------------|
| `@NotNull` | `required: true` |
| `@NotBlank` | `minLength: 1` |
| `@Size(min=x, max=y)` | `minLength: x, maxLength: y` |
| `@Min(x)` | `minimum: x` |
| `@Max(x)` | `maximum: x` |
| `@Pattern(regexp)` | `pattern: "regexp"` |
| `@Email` | `format: email` |
| `@Positive` | `minimum: 1` |
| `@PositiveOrZero` | `minimum: 0` |

## Project Structure Requirements

The command expects your project to follow hexagonal architecture:

```
src/main/java/com/yourcompany/{context}/
├── infrastructure/
│   └── in/
│       └── rest/
│           ├── controller/      # REST endpoints analyzed
│           └── dto/             # Request/Response DTOs analyzed
└── domain/
    └── model/
        └── exception/           # Domain exceptions analyzed
```

## Generated File Structure

```yaml
openapi: 3.0.3
info:
  title: [Auto-detected from pom.xml or application.properties]
  version: [From pom.xml]
  description: [Generated based on discovered entities]

servers:
  - url: http://localhost:{port}{basePath}

tags:
  - name: [One per entity/controller]

paths:
  [All discovered endpoints]

components:
  schemas:
    [All DTOs and response wrappers]
  responses:
    [Standard error responses]
```

## Integration with Spring Boot

After generating the documentation, you have two options:

### Option 1: SpringDoc OpenAPI (Recommended)

Add dependency to `pom.xml`:
```xml
<dependency>
    <groupId>org.springdoc</groupId>
    <artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
    <version>2.3.0</version>
</dependency>
```

Add to `application.properties`:
```properties
springdoc.api-docs.path=/api-docs
springdoc.swagger-ui.path=/swagger-ui.html
springdoc.swagger-ui.operationsSorter=method
springdoc.swagger-ui.tagsSorter=alpha
```

Access:
- **Swagger UI**: http://localhost:8080/swagger-ui.html
- **OpenAPI JSON**: http://localhost:8080/api-docs
- **OpenAPI YAML**: http://localhost:8080/api-docs.yaml

SpringDoc will generate documentation from your code annotations, which you can compare with the generated file.

### Option 2: Static YAML File

Copy the generated file to serve it statically:
```bash
cp .claude/tasks/03-swagger.yaml src/main/resources/static/swagger.yaml
```

Configure SpringDoc to use it:
```properties
springdoc.api-docs.enabled=false
springdoc.swagger-ui.url=/swagger.yaml
```

## Customization

After generation, you can customize the YAML file:

1. **Add authentication schemes**:
```yaml
components:
  securitySchemes:
    bearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT

security:
  - bearerAuth: []
```

2. **Enhance descriptions**:
```yaml
paths:
  /api/books:
    get:
      description: |
        Returns paginated list of books with optional filtering.

        **Filters:**
        - By category
        - By author
        - By publication year
```

3. **Add more examples**:
```yaml
examples:
  example1:
    summary: Book in stock
    value:
      id: 1
      title: "Clean Code"
      stock: 10
  example2:
    summary: Out of stock book
    value:
      id: 2
      title: "Refactoring"
      stock: 0
```

## Example Output

When you run `/swagger`, you'll see:

```
📊 Swagger Documentation Summary:
   Controllers analyzed: 3
   - BookController (5 endpoints)
   - CategoryController (4 endpoints)
   - SaleController (6 endpoints)

   Endpoints documented: 15
   Schemas created: 24
   Tags defined: 3

✅ Documentation saved to: .claude/tasks/03-swagger.yaml

🔗 Integration Options:
   1. Add springdoc-openapi-starter-webmvc-ui dependency
   2. Configure in application.properties
   3. Access at http://localhost:8080/swagger-ui.html

📝 Next Steps:
   - Review generated documentation
   - Customize descriptions if needed
   - Add authentication schemes if applicable
   - Copy to src/main/resources/static/ if using static file approach
```

## Troubleshooting

### No endpoints found
- Ensure controllers are in `infrastructure/in/rest/controller/` package
- Check that controllers use `@RestController` or `@Controller` + `@ResponseBody`
- Verify `@RequestMapping` annotations are present

### Missing DTOs in schemas
- Ensure DTOs are in `infrastructure/in/rest/dto/` package
- DTOs should be POJOs or records
- Check that DTOs are used in controller method signatures

### Validation constraints not showing
- Ensure Jakarta Bean Validation annotations are present
- Check that annotations are on DTO fields, not just method parameters
- Verify `jakarta.validation.constraints.*` imports (not `javax.validation.*`)

### Error responses incorrect
- Check that you have a global exception handler
- Ensure it returns `GenericResponse<CustomErrorResponse>` structure
- Verify domain exceptions are in `domain/model/exception/` package

## Advanced Usage

### Updating existing swagger.yaml

If you already have a `swagger.yaml` file, the command will:
1. Detect it
2. Ask if you want to update or overwrite
3. Merge new endpoints while preserving customizations

### Filtering specific controllers

To generate documentation for specific controllers only:
```
Generate swagger documentation only for BookController and CategoryController
```

### Custom output location

To save to a different location:
```
Generate swagger documentation and save it to docs/api/openapi.yaml
```

## Best Practices

1. **Run after adding new endpoints**: Keep documentation in sync by running `/swagger` after implementing new controllers or modifying DTOs.

2. **Review before committing**: Always review the generated file before committing to version control.

3. **Customize thoughtfully**: Add business context to descriptions, but keep technical details accurate.

4. **Validate before deploying**: Use online validators like https://editor.swagger.io/ to check syntax.

5. **Version your API**: Update `info.version` when making breaking changes.

## Related Commands

- `/scalar-doc` - Generate Scalar documentation (alternative UI)
- `/hexdev` - Generate complete hexagonal architecture features with auto-docs

## Support

If the command doesn't work as expected:
1. Check that your project follows hexagonal architecture conventions
2. Review the output for specific error messages
3. Ensure Maven/Gradle build is successful
4. Verify Java and Spring Boot versions are compatible

## Technical Details

**Agent**: swagger-expert
**Tools used**: Read, Write, Grep, Glob, Bash
**Output**: `.claude/tasks/03-swagger.yaml`
**Format**: OpenAPI 3.0.3 YAML
**Compatible with**: Spring Boot 2.7.x - 3.x, Java 11+