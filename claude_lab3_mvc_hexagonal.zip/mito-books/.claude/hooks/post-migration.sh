#!/bin/bash
echo "🔍 Post-Migration Validation..."

# Run all tests
echo "🧪 Running unit tests..."
npm run test:unit || { echo "❌ Unit tests failed!"; exit 1; }

echo "🧪 Running integration tests..."
npm run test:integration || { echo "❌ Integration tests failed!"; exit 1; }

echo "🧪 Running contract tests..."
npm run test:contracts || { echo "❌ Contract tests failed!"; exit 1; }

# Lint
echo "🔍 Linting..."
npm run lint || { echo "❌ Lint errors!"; exit 1; }

# Type check
echo "🔍 Type checking..."
npm run type-check || { echo "❌ Type errors!"; exit 1; }

# Build
echo "🔨 Building..."
npm run build || { echo "❌ Build failed!"; exit 1; }

echo "✅ All validations passed!"
