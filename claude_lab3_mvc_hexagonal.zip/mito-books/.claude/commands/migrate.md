# Comando Maestro: Migrate (v2.0 - Modular)

**Versión**: 2.0.0
**Descripción**: Orquestador de migración MVC → Arquitectura Hexagonal

---

## 📖 Referencias Obligatorias

**TODOS los sub-comandos DEBEN consultar:**
1. **`.claude/docs/hexagonal-principles.md`** - Principios y reglas de arquitectura hexagonal
2. **`.claude/docs/migration-checkpoints.md`** - Checkpoints y criterios de éxito
3. **`CLAUDE.md`** - Estructura del proyecto actual

---

## 🎯 Flujo de Ejecución

```
/migrate
  ├─> /migrate-phase0-check          (CP0)
  ├─> /migrate-phase1-openapi        (CP1)
  ├─> /migrate-phase2-analysis       (CP2)
  ├─> /migrate-phase3-userstories    (CP3)
  ├─> /migrate-phase4-apimapping     (CP4)
  ├─> PARA CADA ENTIDAD:
  │     └─> /migrate-phase5-entity --entity {Name}
  │           ├─> CP5: Dominio
  │           ├─> CP6: Aplicación
  │           ├─> CP7: Infraestructura
  │           └─> CP8: Validación Hexagonal
  ├─> /migrate-phase9-tests          (CP9)
  └─> /migrate-phase10-build         (CP10)
```

---

## 📋 Lógica de Orquestación

### 1. Detectar Progreso

Leer `.migration/state.json`:
- Si existe: Mostrar progreso y preguntar si continuar
- Si no existe: Iniciar desde FASE 0

### 2. Ejecutar Fase con Reintentos (hasta 3)

Para cada checkpoint:
1. Ejecutar comando de fase
2. Si PASSED → Guardar estado y continuar
3. Si FAILED:
   - Intentar corrección automática (si disponible)
   - Si falla: Solicitar corrección manual
   - Re-ejecutar checkpoint
4. Después de 3 intentos fallidos → ABORT

### 3. Actualizar Estado

Después de cada checkpoint exitoso, actualizar `.migration/state.json` con:
- `lastCheckpoint`: Checkpoint completado
- `nextCommand`: Siguiente comando a ejecutar
- `entities.{Entity}.{layer}`: Estado por entidad/capa

---

## 📊 Archivo de Estado (`.migration/state.json`)

```json
{
  "version": "2.0.0",
  "lastCheckpoint": "CP7_INFRASTRUCTURE_BOOK",
  "lastUpdate": "2025-01-15T11:20:00Z",
  "nextCommand": "/migrate-phase5-entity --entity Category",
  "checkpoints": {
    "CP0": { "status": "PASSED", "timestamp": "..." },
    "CP1": { "status": "PASSED", "timestamp": "..." },
    ...
  },
  "entities": {
    "Book": {
      "domain": "PASSED",
      "application": "PASSED",
      "infrastructure": "PASSED",
      "hexagonalValidation": "PASSED"
    },
    "Category": { "domain": "PENDING", ... },
    ...
  },
  "config": {
    "basePackage": "com.mitocode",
    "backupDir": ".backup/2025-01-15-10-30-00/"
  }
}
```

---

## 🚨 Manejo de Errores

### Rollback Automático

Si se aborta:
1. Restaurar desde `.backup/{timestamp}/`
2. Eliminar archivos generados (`migration/`, `api-docs/`)
3. Eliminar `.migration/state.json`

---

## 📈 Progreso Visual

```
╔════════════════════════════════════════════════╗
║      MIGRACIÓN MVC → HEXAGONAL                 ║
╚════════════════════════════════════════════════╝

✅ CP0: Estado del proyecto
✅ CP1: OpenAPI YAML
✅ CP2: Análisis
✅ CP3: Historias de Usuario
✅ CP4: Mapeo APIs

🔄 MIGRANDO ENTIDADES:
  Book
    ✅ CP5: Dominio
    ✅ CP6: Aplicación
    ✅ CP7: Infraestructura
    ✅ CP8: Validación Hexagonal

  Category
    🔄 CP5: Dominio [EN PROGRESO]
    ⏸️  CP6: Aplicación [PENDIENTE]

Progress: 45% (9/20 checkpoints)
════════════════════════════════════════════════
```

---

## ✅ Ventajas Arquitectura Modular

1. **Contexto Reducido** - Cada sub-comando es pequeño
2. **Reutilizable** - Se puede ejecutar una fase sola
3. **Reintentos por Fase** - No por migración completa
4. **Depurable** - Fácil identificar dónde falló
5. **Progreso Persistente** - Continuar desde donde quedó
6. **Referencias Claras** - Todos consultan docs base

---

**Última actualización**: 2025-01-15