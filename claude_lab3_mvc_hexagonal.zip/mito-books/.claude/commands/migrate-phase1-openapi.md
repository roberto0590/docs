# Migrate Phase 1: Generate OpenAPI YAML

**Checkpoint**: CP1
**Referencia**: `.claude/docs/migration-checkpoints.md` (CP1), `.claude/docs/hexagonal-principles.md`

## Proceso

1. Escanear controllers (`@RestController`, `@RequestMapping`, etc.)
2. Extraer endpoints, request/response DTOs, annotations
3. Generar `api-docs/openapi.yaml` (OpenAPI 3.0.3)
4. Validar sintaxis YAML y estructura OpenAPI
5. Validar cobertura: todos los controllers documentados

## Salida

```json
{
  "checkpoint": "CP1",
  "status": "PASSED",
  "file": "api-docs/openapi.yaml",
  "endpoints": 25,
  "coverage": "100%",
  "nextCommand": "/migrate-phase2-analysis"
}
```

## Criterios de Éxito

✅ Existe `api-docs/openapi.yaml`
✅ Sintaxis YAML válida
✅ Todos los controllers documentados
✅ Cada endpoint tiene request/response schemas