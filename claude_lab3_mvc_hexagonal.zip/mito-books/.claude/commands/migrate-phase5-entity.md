# Migrate Phase 5: Migrate Entity to Hexagonal

**Checkpoint**: CP5 (Domain), CP6 (Application), CP7 (Infrastructure), CP8 (Validation)
**Referencia**: `.claude/docs/hexagonal-principles.md`, `.claude/docs/migration-checkpoints.md`

## Argumentos

- `--entity <name>`: Nombre de la entidad (ej: Book, Category)

## Proceso

### PASO 1: Migrar Capa de Dominio (CP5)

**Referencia**: `.claude/docs/hexagonal-principles.md` - Sección "Domain Layer"

1. Crear estructura:
   - `domain/{entity}/model/entity/`
   - `domain/{entity}/model/vo/`
   - `domain/{entity}/model/enums/`
   - `domain/{entity}/model/exception/`
   - `domain/{entity}/port/in/`
   - `domain/{entity}/port/out/`

2. Extraer entidad de dominio pura (sin `@Entity`, sin `jakarta.*`)
3. Identificar Value Objects (CategoryId, ISBN, etc.)
4. Extraer enums del dominio
5. Crear excepciones de dominio
6. Crear RepositoryPort (interfaz en `port/out/`)
7. Crear UseCases (interfaces en `port/in/`)

**VALIDACIÓN CP5:**
```bash
# Buscar imports prohibidos
grep -r "import jakarta.persistence" domain/{entity}/ && FAIL
grep -r "import org.springframework" domain/{entity}/ | grep -v lombok && FAIL
grep -r "import jakarta.validation" domain/{entity}/ && FAIL
```

### PASO 2: Migrar Capa de Aplicación (CP6)

**Referencia**: `.claude/docs/hexagonal-principles.md` - Sección "Application Layer"

1. Crear estructura:
   - `application/{entity}/usecase/`
   - `application/{entity}/dto/`
   - `application/{entity}/mapper/`

2. Implementar UseCases (implementan interfaces de `domain/port/in/`)
3. Crear Commands/Results
4. Crear Mappers de aplicación
5. Inyectar RepositoryPorts (interfaces, NO implementaciones)

**VALIDACIÓN CP6:**
```bash
# Verificar que NO importe infrastructure
grep -r "import.*infrastructure" application/{entity}/ && FAIL
# Verificar que UseCases implementen interfaces
grep -r "implements.*UseCase" application/{entity}/usecase/ || FAIL
```

### PASO 3: Migrar Capa de Infraestructura (CP7)

**Referencia**: `.claude/docs/hexagonal-principles.md` - Sección "Infrastructure Layer"

1. Crear estructura:
   - `infrastructure/{entity}/in/rest/controller/`
   - `infrastructure/{entity}/in/rest/api/` (interfaz OpenAPI)
   - `infrastructure/{entity}/in/rest/dto/`
   - `infrastructure/{entity}/in/rest/mapper/`
   - `infrastructure/{entity}/out/persistence/entity/`
   - `infrastructure/{entity}/out/persistence/repository/`
   - `infrastructure/{entity}/out/persistence/adapter/`
   - `infrastructure/{entity}/out/persistence/mapper/`

2. Crear Controller (inyecta UseCases como interfaces)
3. Crear Request/Response DTOs
4. Crear Web Mapper
5. Crear JPA Entity (con `@Entity`, `@Table`, etc.)
6. Crear Spring Data Repository
7. Crear Adapter (implementa RepositoryPort)
8. Crear JPA Mapper

**VALIDACIÓN CP7:**
```bash
# Verificar que Controller NO inyecte implementaciones
grep -r "private final.*UseCaseImpl" infrastructure/{entity}/in/rest/controller/ && FAIL
# Verificar que Adapter implemente Port
grep -r "implements.*RepositoryPort" infrastructure/{entity}/out/persistence/adapter/ || FAIL
```

### PASO 4: Validar Arquitectura Hexagonal (CP8)

**Referencia**: `.claude/docs/hexagonal-principles.md` - Sección "Validaciones Obligatorias"

```bash
# Ejecutar validación exhaustiva
python3 .claude/scripts/validate-hexagonal.py --entity {entity}
```

**VALIDACIONES:**
1. Estructura de Paquetes ✅
2. Convenciones de Nomenclatura ✅
3. Dependencias entre Capas ✅
4. Dependency Inversion Principle ✅
5. Single Responsibility Principle ✅
6. Ausencia de Código Legacy ✅

**Si falla:** Intentar corrección automática, re-ejecutar validación

---

## Salida

```json
{
  "checkpoints": {
    "CP5_DOMAIN_{ENTITY}": "PASSED",
    "CP6_APPLICATION_{ENTITY}": "PASSED",
    "CP7_INFRASTRUCTURE_{ENTITY}": "PASSED",
    "CP8_HEXAGONAL_VALIDATION_{ENTITY}": "PASSED"
  },
  "entity": "Book",
  "timestamp": "2025-01-15T11:30:00Z",
  "nextCommand": "/migrate-phase5-entity --entity Category"
}
```

---

## Criterios de Éxito Globales

✅ Todas las 3 capas creadas para la entidad
✅ 0 imports prohibidos en domain
✅ Application solo depende de domain
✅ Infrastructure implementa todos los ports
✅ Todos los tests pasan
✅ Validación hexagonal pasa 100%

---

## Reintentos

Si CP5, CP6, CP7 o CP8 falla:
1. Mostrar violaciones específicas
2. Intentar corrección automática (si disponible)
3. Si corrección automática falla, solicitar corrección manual
4. Re-ejecutar checkpoint hasta 3 intentos
5. Si después de 3 intentos falla: ABORT y mostrar error

---

## Actualización de Estado

```json
{
  "entities": {
    "{Entity}": {
      "domain": "PASSED",
      "application": "PASSED",
      "infrastructure": "PASSED",
      "hexagonalValidation": "PASSED"
    }
  }
}
```