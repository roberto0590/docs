# Migrate Phase 9: Execute All Tests

**Checkpoint**: CP9
**Referencia**: `.claude/docs/migration-checkpoints.md` (CP9)

## Proceso

1. Ejecutar todos los tests: `./mvnw test`
2. Generar reporte de cobertura: `./mvnw jacoco:report`
3. Validar cobertura mínima por capa
4. Ejecutar tests de contrato API
5. Generar reporte de tests

## Salida

```json
{
  "checkpoint": "CP9",
  "status": "PASSED",
  "totalTests": 325,
  "passed": 325,
  "failed": 0,
  "coverage": {
    "domain": "92%",
    "application": "88%",
    "infrastructure": "76%"
  },
  "nextCommand": "/migrate-phase10-build"
}
```

## Criterios de Éxito

✅ Todos los tests pasan (0 fallos)
✅ Domain: >= 90% cobertura
✅ Application: >= 85% cobertura
✅ Infrastructure: >= 70% cobertura
✅ Tests de contrato API pasan