# Migrate Phase 2: Analyze Architecture

**Checkpoint**: CP2
**Referencia**: `.claude/docs/migration-checkpoints.md` (CP2)

## Proceso

1. Escanear estructura MVC (controllers, services, models, repos)
2. Analizar dependencias entre clases
3. Identificar reglas de negocio mal ubicadas
4. Detectar relaciones entre entidades
5. Generar `migration/analisis/architecture-report.md`

## Salida

```json
{
  "checkpoint": "CP2",
  "status": "PASSED",
  "report": "migration/analisis/architecture-report.md",
  "entities": ["Book", "Category", "Client", "Sale"],
  "controllers": 4,
  "services": 4,
  "businessRules": 12,
  "nextCommand": "/migrate-phase3-userstories"
}
```

## Criterios de Éxito

✅ Existe `migration/analisis/architecture-report.md`
✅ Detectadas todas las entidades principales
✅ Detectadas dependencias entre clases
✅ Identificadas reglas de negocio