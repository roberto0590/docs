# Landing Variants

Generates a single HTML file with multiple design variants (Moderno, Minimalista, Colorido) accessible via tab navigation.

## Instructions

You are now operating as a **Landing Page Variants Generator** using the `landing-variants-generator` agent.

### Task Breakdown

Use the TodoWrite tool to create this checklist:

1. Gather project requirements (purpose, target audience)
2. Invoke landing-variants-generator agent
3. Verify HTML file created successfully
4. Validate file size and structure
5. Open file in browser for preview
6. Provide usage instructions to user

### Requirements Gathering Phase

**Step 1: Extract Project Context**

Ask the user (or infer from context):
- **Project Purpose**: What is the landing page promoting?
  - Examples: Product launch, Service offering, Event registration, Newsletter signup
- **Target Audience**: Who is the intended user?
  - Examples: Tech professionals, General consumers, Business executives, Students
- **Output Location**: Where to save the file?
  - Default: Project root (`landing-variants.html`)
  - Alternative: `.claude/tasks/landing-variants.html`

If user hasn't specified, use sensible defaults based on context.

### Execution Phase

**Step 2: Invoke the landing-variants-generator Agent**

Use the Task tool with:
- **subagent_type**: `landing-variants-generator`
- **description**: "Generate landing variants HTML"
- **prompt**:
```
Generate a single HTML file (landing-variants.html) with 3 design variants:

Project Purpose: {purpose from context or "Your Project"}
Target Audience: {audience from context or "General users"}

Requirements:
1. Tab navigation with 3 variants (Moderno, Minimalista, Colorido)
2. Each variant includes: Hero, Features (3 cards), Testimonials, Footer
3. Responsive design (mobile-first)
4. All CSS and JavaScript embedded (no external files)
5. Professional content based on purpose and audience
6. Smooth animations and transitions
7. CTA buttons with event listeners

Output location: {location}

Provide success report with file location, statistics, and usage instructions.
```

Wait for agent to complete generation.

### Validation Phase

**Step 3: Verify File Created**

```bash
# Check if file exists and get size
ls -lh landing-variants.html
```

Or:

```bash
ls -lh .claude/tasks/landing-variants.html
```

**Step 4: Validate File Size**

File should be:
- **Minimum**: 10 KB (too small = incomplete)
- **Maximum**: 150 KB (too large = bloated)
- **Ideal**: 30-80 KB

**Step 5: Count Lines of Code**

```bash
# Count total lines
wc -l landing-variants.html
```

Should have 500-800 lines for complete implementation.

### Output Phase

**Step 6: Provide Usage Instructions**

Display to user:

```markdown
✅ Landing Variants Generated Successfully!

📁 Location: {file-path}
📏 Size: {file-size} KB
📊 Lines: {line-count}

🎨 Design Variants Included:
   - ✨ Moderno (Gradients, Glassmorphism, Modern)
   - ⚡ Minimalista (Black/White/Accent, Serif, Clean)
   - 🎨 Colorido (Vibrant Colors, Bold, Dynamic)

📖 How to Use:
1. Abrir archivo en navegador:
   - Windows: `start {file-path}`
   - Mac: `open {file-path}`
   - Linux: `xdg-open {file-path}`

2. Navegar entre variantes usando los tabs superiores

3. Redimensionar ventana para probar responsive design

4. Personalizar contenido:
   - Buscar `#moderno` para variante moderna
   - Buscar `#minimalista` para variante minimalista
   - Buscar `#colorido` para variante colorida

✨ Next Steps:
   - Reemplazar textos placeholder con contenido real
   - Ajustar colores según brand guidelines
   - Configurar CTAs con URLs reales
   - Optimizar imágenes si agregas alguna
```

**Step 7: Optionally Open in Browser**

If user requested, open file:

```bash
# Windows
start landing-variants.html
```

```bash
# Mac
open landing-variants.html
```

```bash
# Linux
xdg-open landing-variants.html
```

## Quality Requirements

### MUST Deliver:
- ✅ Single HTML file with 3 complete variants
- ✅ Tab navigation system working
- ✅ Responsive design (mobile/tablet/desktop)
- ✅ Professional content (no Lorem ipsum)
- ✅ Embedded CSS and JavaScript (no external files)
- ✅ Smooth animations and transitions
- ✅ Success report with file location
- ✅ Usage instructions provided

### MUST NOT:
- ❌ Create multiple files (must be single file)
- ❌ Use external dependencies
- ❌ Generate incomplete variants
- ❌ Skip validation steps
- ❌ Leave placeholder content

## Success Criteria

Mark task complete when:
- [ ] Project requirements gathered (purpose, audience)
- [ ] landing-variants-generator agent invoked
- [ ] HTML file created at specified location
- [ ] File size validated (30-80 KB ideal)
- [ ] Line count validated (500-800 lines ideal)
- [ ] File structure confirmed (all variants present)
- [ ] Usage instructions provided to user
- [ ] User knows how to open and customize the file

---

**Begin execution now.** Use the TodoWrite tool to track your progress through each phase. Gather requirements, invoke the agent, validate output, and provide complete usage instructions.