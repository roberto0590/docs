---
description: Genera HU completa con criterios técnicos y ejecuta desarrollo hexagonal estricto con validación iterativa
---

# 🎯 /hexdev - Desarrollo Guiado por Arquitectura Hexagonal

Este comando genera una Historia de Usuario (HU) completa con criterios de aceptación de negocio Y técnicos, ejecuta el desarrollo siguiendo los principios de arquitectura hexagonal, y **valida iterativamente** que se cumplan todos los criterios hasta obtener aprobación.

## 🔄 Workflow Iterativo con Validación

```mermaid
graph TD
    A[Generar HU Completa] --> B[Leer hexagonal-principles.md]
    B --> C[Desarrollo Capa Domain]
    C --> D[Desarrollo Capa Application]
    D --> E[Desarrollo Capa Infrastructure]
    E --> F{Revisor: ¿Cumple HU?}
    F -->|❌ NO| G[Listar incumplimientos]
    G --> H[Re-desarrollar con java-hex-architect]
    H --> F
    F -->|✅ SÍ| I[Generar Tests desde HU]
    I --> J[Build & Validación Final]
    J --> K[✅ COMPLETO]
```

## 📋 Fases del Comando

### FASE 0: Preparación 📚

```bash
📚 Leyendo principios de arquitectura hexagonal...
   ✓ Cargando .claude/docs/hexagonal-principles.md
   ✓ Reglas de dependencias cargadas
   ✓ Convenciones de nomenclatura cargadas
   ✓ Validaciones obligatorias cargadas
```

### FASE 1: Generación de HU 📝

**Agente:** `hu-generator` (`.claude/agents/hu-generator.md`)

**Comando interno:**
```typescript
await invokeAgent('hu-generator', {
  task: 'generate-complete-hu',
  input: {
    description: userProvidedDescription,
    context: currentCodebase,
    referenceDoc: '.claude/docs/hexagonal-principles.md'
  },
  output: 'docs/hu/HU-XXX-[feature].md'
});
```

**Responsabilidad del agente:**
- Generar HU completa con criterios de negocio Y técnicos
- Incluir escenarios Gherkin (Dado/Cuando/Entonces)
- Incluir criterios técnicos (CT-001 a CT-008)
- Incluir checklist de componentes hexagonales
- Incluir Definición de Hecho (DoD)

**Output:**
```markdown
# HU-XXX: [Título]

## Como [rol]
Quiero [funcionalidad]
Para [beneficio]

## Criterios de Aceptación (Negocio)
[Escenarios en Gherkin]

## Criterios Técnicos (CT-001 a CT-008)
[Validaciones técnicas exhaustivas]

## Arquitectura Hexagonal
### Dominio
- [ ] Entidades: [lista]
- [ ] Value Objects: [lista]
- [ ] Ports: [lista]

### Aplicación
- [ ] UseCases: [lista]
- [ ] Commands/Results: [lista]

### Infraestructura
- [ ] Controllers: [lista]
- [ ] DTOs: [lista]
- [ ] Adapters: [lista]

## Definición de Hecho (DoD)
[Checklist de completitud]
```

**Checkpoint 1:** Usuario revisa y aprueba HU.

### FASE 2: Desarrollo Hexagonal 🏗️

**Agente:** `java-hex-architect` (`.claude/agents/java-hex-architect.md`)

**Comando interno:**
```typescript
// CAPA 1: DOMINIO
await invokeAgent('java-hex-architect', {
  task: 'implement-domain-layer',
  input: {
    hu: 'docs/hu/HU-XXX-[feature].md',
    principles: '.claude/docs/hexagonal-principles.md',
    context: currentContext
  },
  layer: 'domain',
  strictValidation: true
});

// CAPA 2: APLICACIÓN
await invokeAgent('java-hex-architect', {
  task: 'implement-application-layer',
  input: {
    hu: 'docs/hu/HU-XXX-[feature].md',
    principles: '.claude/docs/hexagonal-principles.md',
    domainClasses: generatedDomainClasses
  },
  layer: 'application',
  strictValidation: true
});

// CAPA 3: INFRAESTRUCTURA
await invokeAgent('java-hex-architect', {
  task: 'implement-infrastructure-layer',
  input: {
    hu: 'docs/hu/HU-XXX-[feature].md',
    principles: '.claude/docs/hexagonal-principles.md',
    applicationPorts: generatedPorts
  },
  layer: 'infrastructure',
  strictValidation: true
});
```

**Responsabilidad del agente:**
- Leer HU generada en FASE 1
- Leer `.claude/docs/hexagonal-principles.md` para reglas estrictas
- Implementar las 3 capas siguiendo nomenclatura y convenciones
- Auto-validar contra principios hexagonales durante desarrollo

**Output por capa:**

```bash
🏗️ Iniciando desarrollo hexagonal...

▶ CAPA 1: DOMINIO
  Agente: java-hex-architect (layer: domain)
  Referencia: .claude/docs/hexagonal-principles.md

  Creando:
    ✓ domain/model/entity/[Entity].java
    ✓ domain/model/vo/[VO].java
    ✓ domain/model/enums/[Enum].java
    ✓ domain/model/exception/[Exception].java
    ✓ domain/port/in/[UseCase].java
    ✓ domain/port/out/[RepositoryPort].java

  Validando:
    ✓ NO imports de jakarta.*
    ✓ NO imports de org.springframework.* (excepto lombok)
    ✓ Solo java.util.*, java.time.*, java.math.*

▶ CAPA 2: APLICACIÓN
  Agente: java-hex-architect (layer: application)
  Referencia: .claude/docs/hexagonal-principles.md

  Creando:
    ✓ application/usecase/[UseCaseImpl].java
    ✓ application/dto/[Command].java
    ✓ application/dto/[Result].java
    ✓ application/mapper/[Mapper].java

  Validando:
    ✓ Implementa interfaces de domain/port/in/
    ✓ Inyecta interfaces de domain/port/out/
    ✓ Solo depende de domain/

▶ CAPA 3: INFRAESTRUCTURA
  Agente: java-hex-architect (layer: infrastructure)
  Referencia: .claude/docs/hexagonal-principles.md

  Creando:
    ✓ infrastructure/in/rest/controller/[Controller].java
    ✓ infrastructure/in/rest/api/[Api].java (OpenAPI)
    ✓ infrastructure/in/rest/dto/[RequestDto].java
    ✓ infrastructure/in/rest/dto/[ResponseDto].java
    ✓ infrastructure/in/rest/mapper/[WebMapper].java
    ✓ infrastructure/in/rest/service/[FacadeService].java
    ✓ infrastructure/out/persistence/entity/[JpaEntity].java
    ✓ infrastructure/out/persistence/repository/[SpringDataRepository].java
    ✓ infrastructure/out/persistence/adapter/[RepositoryAdapter].java
    ✓ infrastructure/out/persistence/mapper/[JpaMapper].java

  Validando:
    ✓ Controllers inyectan UseCases (interfaces)
    ✓ Adapters implementan RepositoryPorts
    ✓ Nomenclatura: *JpaEntity, SpringData*Repository
```

### FASE 3: Revisión contra HU 🔍

**Agente:** `hu-reviewer` (`.claude/agents/hu-reviewer.md`)

**Comando interno:**
```typescript
const reviewResult = await invokeAgent('hu-reviewer', {
  task: 'validate-hu-compliance',
  input: {
    hu: 'docs/hu/HU-XXX-[feature].md',
    implementedCode: generatedCodePaths,
    principles: '.claude/docs/hexagonal-principles.md'
  },
  outputReport: 'docs/validation/HU-XXX-review-report.md',
  strictMode: true
});

if (reviewResult.approved) {
  continueToPhase4();
} else {
  retryDevelopment(reviewResult.violations);
}
```

**Responsabilidad del agente:**
- Leer HU completa
- Leer `.claude/docs/hexagonal-principles.md`
- Validar **100%** de criterios de aceptación
- Validar **100%** de criterios técnicos (CT-001 a CT-008)
- Validar **100%** de arquitectura hexagonal
- Validar **100%** de componentes listados en HU
- Generar reporte detallado de cumplimiento

```bash
🔍 REVISIÓN: Validando desarrollo contra HU-XXX...

Agente: hu-reviewer
HU: docs/hu/HU-XXX-[feature].md
Principios: .claude/docs/hexagonal-principles.md

📋 REVISIÓN 1: Criterios de Aceptación (Negocio)

  Escenario 1: [descripción]
    ✓ Implementado en: [UseCase].java:[línea]
    ✓ Test generado: [Test].java:[línea]

  Escenario 2: [descripción]
    ✓ Implementado en: [UseCase].java:[línea]
    ✓ Test generado: [Test].java:[línea]

📋 REVISIÓN 2: Criterios Técnicos

  CT-001: API Contract
    ✓ Endpoint implementado: POST /api/[resource]
    ✓ Request DTO validado
    ✓ Response DTO validado
    ✓ Status codes correctos

  CT-002: Request Validation
    ✓ Validaciones Jakarta en infrastructure/in/rest/dto/
    ✓ Validaciones de negocio en domain/model/entity/

  CT-003: Response Structure
    ✓ Response DTO cumple estructura de HU

  CT-004: Business Rules
    ✓ RN-001 implementada en: domain/model/entity/[Entity].java
    ✓ RN-002 implementada en: domain/model/entity/[Entity].java

  CT-005: Side Effects
    ✓ Persistencia implementada
    ✓ Eventos publicados (si aplica)

  CT-006: Performance
    ✓ Queries optimizadas
    ✓ Índices verificados

  CT-007: Security
    ✓ Autenticación verificada
    ✓ Autorización verificada

  CT-008: Error Handling
    ✓ Excepciones de dominio creadas
    ✓ Exception handler implementado

📋 REVISIÓN 3: Arquitectura Hexagonal (contra hexagonal-principles.md)

  ✓ Estructura de paquetes correcta
  ✓ Nomenclatura cumple convenciones
  ✓ Dependencias entre capas correctas
  ✓ Dependency Inversion respetada
  ✓ Single Responsibility respetada

📋 REVISIÓN 4: Componentes de HU

  Dominio:
    ✓ Entidades creadas: [lista]
    ✓ Value Objects creados: [lista]
    ✓ Ports creados: [lista]

  Aplicación:
    ✓ UseCases implementados: [lista]
    ✓ Commands/Results creados: [lista]

  Infraestructura:
    ✓ Controllers implementados: [lista]
    ✓ DTOs creados: [lista]
    ✓ Adapters implementados: [lista]
```

#### Resultado Posible 1: ✅ APROBADO

```bash
✅ REVISIÓN APROBADA

  Resumen:
  ✅ 100% Criterios de Aceptación cumplidos
  ✅ 100% Criterios Técnicos cumplidos
  ✅ 100% Arquitectura Hexagonal cumplida
  ✅ 100% Componentes de HU implementados

  ✅ El desarrollo cumple TODOS los requisitos de HU-XXX

➡️  Continuando a FASE 4: Generación de Tests...
```

#### Resultado Posible 2: ❌ RECHAZADO

```bash
❌ REVISIÓN RECHAZADA

  Incumplimientos detectados:

  ❌ CT-004: Business Rules
     - RN-001 NO implementada
     - Esperado: Validación de descuento en domain/model/entity/Sale.java
     - Encontrado: Validación en infrastructure/in/rest/controller/SaleController.java
     - Violación: Lógica de negocio en capa de infraestructura

  ❌ CT-007: Security
     - Falta validación de autorización en endpoint DELETE /api/books/{id}
     - Requerido en HU pero no implementado

  ❌ Arquitectura Hexagonal
     - domain/model/entity/Category.java tiene import de jakarta.validation.*
     - Violación de principio: Dominio debe ser PURO

  ❌ Componentes de HU
     - Falta crear: domain/model/vo/Discount.java
     - Listado en HU pero no implementado

📊 Resultado: 6/10 criterios cumplidos (60%)

🔧 ACCIÓN: Re-desarrollo requerido
```

### FASE 3.1: Re-desarrollo (si hay incumplimientos) 🔄

**Agente:** `java-hex-architect` (`.claude/agents/java-hex-architect.md`)

**Comando interno:**
```typescript
// Si hu-reviewer rechazó (approved = false)
await invokeAgent('java-hex-architect', {
  task: 'fix-compliance-issues',
  input: {
    hu: 'docs/hu/HU-XXX-[feature].md',
    violations: reviewResult.violations, // Del hu-reviewer
    principles: '.claude/docs/hexagonal-principles.md',
    currentCode: implementedCodePaths
  },
  mode: 'fix',
  strictValidation: true
});

// Después de correcciones, volver a FASE 3
await retryPhase3Review();
```

**Responsabilidad del agente:**
- Leer reporte de violaciones del `hu-reviewer`
- Corregir específicamente cada incumplimiento detectado
- Mantener arquitectura hexagonal estricta
- Re-generar código hasta cumplir 100%

```bash
🔄 Re-ejecutando desarrollo con correcciones...

Agente: java-hex-architect
Modo: fix-compliance
Input: Reporte de hu-reviewer con 6 incumplimientos

📋 Corrigiendo incumplimientos:

  1. Moviendo lógica de negocio de Controller a Domain
     ✓ Creando método applyDiscount() en domain/model/entity/Sale.java
     ✓ Removiendo lógica de SaleController.java
     ✓ Controller ahora solo delega a UseCase

  2. Agregando validación de autorización
     ✓ Creando interceptor de seguridad
     ✓ Validando permisos en DeleteBookUseCase

  3. Eliminando imports prohibidos de dominio
     ✓ Removiendo jakarta.validation.* de Category.java
     ✓ Moviendo validación a CategoryRequestDto.java

  4. Creando componentes faltantes
     ✓ Creando domain/model/vo/Discount.java
     ✓ Integrando en lógica de Sale.java

✅ Correcciones completadas

🔄 Re-ejecutando FASE 3: Revisión...
```

**El ciclo se repite hasta que el revisor apruebe.**

### FASE 4: Generación de Tests 🧪

**Agente:** `test-generator` (`.claude/agents/test-generator.md`)

**Comando interno:**
```typescript
// Solo se ejecuta si hu-reviewer aprobó
await invokeAgent('test-generator', {
  task: 'generate-tests-from-hu',
  input: {
    hu: 'docs/hu/HU-XXX-[feature].md',
    implementedCode: implementedCodePaths,
    testTypes: ['unit', 'integration', 'contract']
  },
  outputDir: 'src/test/java/',
  coverage: {
    minimum: 80,
    generateReport: true
  }
});
```

**Responsabilidad del agente:**
- Leer HU aprobada (cada escenario → test)
- Leer criterios técnicos (cada CT → test)
- Generar tests unitarios de dominio
- Generar tests unitarios de aplicación
- Generar tests de integración de infraestructura
- Generar tests de contrato API
- Ejecutar todos los tests y validar cobertura

```bash
🧪 Generando tests desde criterios de HU...

Agente: test-generator
Fuente: docs/hu/HU-XXX-[feature].md (APROBADA por hu-reviewer)

Generando tests unitarios de dominio:
  ✓ BookTest.java
  ✓ DiscountTest.java
  ✓ VolumeDiscountPolicyTest.java

Generando tests unitarios de aplicación:
  ✓ CreateBookUseCaseImplTest.java
  ✓ ApplyDiscountUseCaseImplTest.java

Generando tests de integración:
  ✓ BookControllerIntegrationTest.java
  ✓ BookRepositoryAdapterIntegrationTest.java

Generando tests de contrato API:
  ✓ BookApiContractTest.java

Ejecutando tests:
  ✅ 45 unit tests - PASANDO
  ✅ 12 integration tests - PASANDO
  ✅ 5 contract tests - PASANDO

  Cobertura: 87%
```

### FASE 5: Build & Validación Final 🏁

```bash
🏁 Validación final y build...

1. Ejecutando build:
   ./mvnw clean install
   ✅ Compilación exitosa
   ✅ Tests pasando (62/62)

2. Validación de arquitectura:
   ✅ hexagonal-principles.md: 100% cumplimiento
   ✅ Dependency Inversion: OK
   ✅ Single Responsibility: OK

3. Validación de HU:
   ✅ Todos los criterios cumplidos
   ✅ Todos los componentes implementados
   ✅ DoD completa

═══════════════════════════════════════════
✅ DESARROLLO HEXAGONAL COMPLETO Y APROBADO
═══════════════════════════════════════════

📊 Resumen:
  ✅ HU-XXX: 100% cumplida
  ✅ Arquitectura Hexagonal: Validada
  ✅ Tests: 62/62 pasando (87% cobertura)
  ✅ Build: Exitoso
  ✅ Iteraciones de revisión: 2
     - Iteración 1: 60% → Rechazado
     - Iteración 2: 100% → Aprobado

📁 Archivos generados:
  - docs/hu/HU-XXX-[feature].md
  - docs/validation/HU-XXX-review-report.md
  - src/main/java/.../domain/
  - src/main/java/.../application/
  - src/main/java/.../infrastructure/
  - src/test/java/.../

🚀 Listo para commit!
```

## 🚀 Uso del Comando

```bash
# Desarrollo completo de una nueva feature
/hexdev "crear sistema de gestión de autores para libros"

# Desarrollo de un cambio específico
/hexdev "agregar campo de descuento a libros con validación de porcentaje"

# Desarrollo de un nuevo endpoint
/hexdev "endpoint para buscar libros por rango de precio"
```

## ⚙️ Opciones Avanzadas

```bash
# Solo generar la HU (no ejecutar desarrollo)
/hexdev "nueva feature" --hu-only

# Desarrollo desde HU existente
/hexdev --hu-file docs/hu/HU-015.md

# Máximo de iteraciones de revisión (default: 5)
/hexdev "feature" --max-iterations 3

# Modo verbose (muestra todos los detalles del revisor)
/hexdev "feature" --verbose
```

## 📊 Ciclo de Revisión Iterativo

El comando garantiza calidad mediante:

1. **Generación de HU exhaustiva** con criterios técnicos
2. **Desarrollo guiado** por `hexagonal-principles.md`
3. **Revisión automática** por agente revisor independiente
4. **Re-desarrollo iterativo** hasta cumplir 100% de criterios
5. **Tests generados** desde criterios de HU
6. **Validación final** de arquitectura y build

**Máximo de iteraciones:** 5 (configurable)

**Criterio de aprobación:** 100% de criterios de HU cumplidos

## 🔒 Garantías

Al finalizar, este comando garantiza:

✅ **HU 100% cumplida** (validada por agente revisor independiente)
✅ **Arquitectura hexagonal estricta** (contra hexagonal-principles.md)
✅ **Tests completos** (generados desde criterios de HU)
✅ **Build exitoso** (compilación + tests pasando)
✅ **Código revisado** (ciclo iterativo hasta aprobación)

## 🎯 Agentes Utilizados

- **hu-generator** (`.claude/agents/hu-generator.md`): Genera HU completa con criterios técnicos y de negocio
- **java-hex-architect** (`.claude/agents/java-hex-architect.md`): Implementa arquitectura hexagonal estricta en las 3 capas
- **hu-reviewer** (`.claude/agents/hu-reviewer.md`): Valida cumplimiento 100% de HU y arquitectura hexagonal
- **test-generator** (`.claude/agents/test-generator.md`): Genera tests desde criterios de HU
- **migration-validator** (`.claude/agents/migration-validator.md`): Validación final de arquitectura

## 📚 Referencias

- **Principios de arquitectura:** `.claude/docs/hexagonal-principles.md` (leído automáticamente)
- **Convenciones del proyecto:** `CLAUDE.md`

---

**Ejecuta:** `/hexdev "[descripción del cambio]"`

El comando se encargará de:
1. Leer `hexagonal-principles.md`
2. Generar HU completa
3. Desarrollar con arquitectura hexagonal
4. **Revisar y re-desarrollar hasta aprobación**
5. Generar tests y validar build