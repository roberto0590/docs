package com.mitocode.controller;

import com.mitocode.api.SaleAPI;
import com.mitocode.dto.GenericResponse;
import com.mitocode.dto.SaleDTO;
import com.mitocode.model.Sale;
import com.mitocode.service.ISaleService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/sales")
@RequiredArgsConstructor
public class SaleController implements SaleAPI {

    private final ISaleService service;
    @Qualifier("saleMapper")
    private final ModelMapper modelMapper;

    @Override
    public ResponseEntity<GenericResponse<SaleDTO>> getAllSales() {
        List<SaleDTO> list = service.findAll().stream().map(this::convertToDto).toList();

        return ResponseEntity.ok(new GenericResponse<>(200, "success", list));
    }

    @Override
    public ResponseEntity<GenericResponse<SaleDTO>> getSaleById(@PathVariable("id") Integer id) {
        Sale obj = service.findById(id);

        return ResponseEntity.ok(new GenericResponse<>(200, "success", Arrays.asList(convertToDto(obj))));
    }

    @Override
    public ResponseEntity<Void> save(@Valid @RequestBody SaleDTO dto) {
        Sale obj = service.save(convertToEntity(dto));

        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdSale()).toUri();

        return ResponseEntity.created(location).build();
    }

    @Override
    public ResponseEntity<GenericResponse<SaleDTO>> update(@PathVariable("id") Integer id, @Valid @RequestBody SaleDTO dto) {
        //sale.setIdSale(id);
        Sale obj = service.update(id, convertToEntity(dto));

        return ResponseEntity.ok(new GenericResponse<>(200, "success", Arrays.asList(convertToDto(obj))));
    }

    @Override
    public ResponseEntity<Void> delete(@PathVariable("id") Integer id) {
        service.delete(id);

        return ResponseEntity.noContent().build();
    }


    private SaleDTO convertToDto(Sale obj) {
        return modelMapper.map(obj, SaleDTO.class);
    }

    private Sale convertToEntity(SaleDTO dto) {
        return modelMapper.map(dto, Sale.class);
    }

}
