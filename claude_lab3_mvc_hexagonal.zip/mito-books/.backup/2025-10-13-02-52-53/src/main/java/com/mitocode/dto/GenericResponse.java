package com.mitocode.dto;

import io.swagger.v3.oas.annotations.media.Schema;

import java.util.List;

@Schema(description = "Generic API response wrapper")
public record GenericResponse<T>(
        @Schema(description = "HTTP status code", example = "200")
        int status,

        @Schema(description = "Response message", example = "success")
        String message,

        @Schema(description = "Response data")
        List<T> data
) {
}
