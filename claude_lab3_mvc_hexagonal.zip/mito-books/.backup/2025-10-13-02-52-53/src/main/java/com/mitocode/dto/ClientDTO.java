package com.mitocode.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Client data transfer object")
public class ClientDTO {

    @Schema(description = "Client unique identifier", example = "1", accessMode = Schema.AccessMode.READ_ONLY)
    private Integer idClient;

    @NotNull
    //@NotEmpty
    //@NotBlank
    @Size(min = 3, max = 20)
    @Schema(description = "Client first name", example = "John", required = true, minLength = 3, maxLength = 20)
    private String firstName;

    @NotNull
    @Size(min = 3, max = 20)
    @Schema(description = "Client surname", example = "Doe", required = true, minLength = 3, maxLength = 20)
    private String surname;

    @NotNull
    @Schema(description = "Client birth date", example = "1990-01-15", required = true)
    private LocalDate birthDateClient;

    /*@Email
    @Pattern(regexp = "[0-9]+")
    @Max(value = 99)
    @Min(value = 1)*/
}
