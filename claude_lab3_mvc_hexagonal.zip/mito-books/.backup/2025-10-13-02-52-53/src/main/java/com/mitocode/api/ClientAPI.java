package com.mitocode.api;

import com.mitocode.dto.ClientDTO;
import com.mitocode.dto.GenericResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Client API Documentation Interface
 *
 * This interface defines all client management endpoints with comprehensive OpenAPI documentation.
 * Clients are customers who purchase books through the sales system.
 * It follows the Single Responsibility Principle by separating API documentation from controller logic.
 *
 * Endpoints:
 * - GET /clients - Retrieve all clients
 * - GET /clients/{id} - Retrieve a client by ID
 * - POST /clients - Create a new client
 * - PUT /clients/{id} - Update an existing client
 * - DELETE /clients/{id} - Delete a client
 *
 * Note: This controller uses a custom ModelMapper (clientMapper) that maps:
 * - firstName ↔ primaryName
 * - surname ↔ lastName
 */
@Tag(name = "Clients", description = "Client management endpoints for customer information. Clients are linked to sales transactions.")
public interface ClientAPI {

    @Operation(
            summary = "Get all clients",
            description = """
                    Retrieves a complete list of all clients in the bookstore system.

                    **Happy Path:**
                    - Returns 200 OK with a list of all clients wrapped in GenericResponse
                    - Empty list returned if no clients exist

                    **Use Cases:**
                    - Display customer list for management
                    - Get client information for sales processing
                    - Export customer data for reporting

                    **Note:**
                    - Uses custom clientMapper for field mapping
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Successfully retrieved list of clients",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Success Response",
                                    value = """
                                            {
                                              "status": 200,
                                              "message": "success",
                                              "data": [
                                                {
                                                  "idClient": 1,
                                                  "firstName": "John",
                                                  "surname": "Doe",
                                                  "birthDateClient": "1990-01-15"
                                                },
                                                {
                                                  "idClient": 2,
                                                  "firstName": "Jane",
                                                  "surname": "Smith",
                                                  "birthDateClient": "1985-06-20"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
    })
    @GetMapping
    ResponseEntity<GenericResponse<ClientDTO>> getAllClients();

    @Operation(
            summary = "Get client by ID",
            description = """
                    Retrieves a specific client by their unique identifier.

                    **Happy Path:**
                    - Returns 200 OK with the client data wrapped in GenericResponse

                    **Unhappy Path:**
                    - Returns 404 NOT_FOUND if client with given ID doesn't exist
                    - Throws ModelNotFoundException handled by GlobalErrorHandler

                    **Use Cases:**
                    - View customer profile details
                    - Verify client information before creating a sale
                    - Display client data in sales forms
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Successfully retrieved client",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Success Response",
                                    value = """
                                            {
                                              "status": 200,
                                              "message": "success",
                                              "data": [
                                                {
                                                  "idClient": 1,
                                                  "firstName": "John",
                                                  "surname": "Doe",
                                                  "birthDateClient": "1990-01-15"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Client not found",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Not Found Response",
                                    value = """
                                            {
                                              "status": 404,
                                              "message": "not-found",
                                              "data": [
                                                {
                                                  "datetime": "2025-10-12T10:30:00",
                                                  "message": "Client with ID 999 not found",
                                                  "path": "uri=/clients/999"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
    })
    @GetMapping("/{id}")
    ResponseEntity<GenericResponse<ClientDTO>> getClientById(
            @Parameter(description = "Client unique identifier", required = true, example = "1")
            @PathVariable("id") Integer id
    );

    @Operation(
            summary = "Create a new client",
            description = """
                    Creates a new client in the bookstore system.

                    **Happy Path:**
                    - Returns 201 CREATED with Location header pointing to the new resource
                    - Client is persisted to database
                    - Location: /clients/{newClientId}

                    **Unhappy Path:**
                    - Returns 400 BAD_REQUEST if validation fails
                    - Validation errors: missing required fields, invalid name length

                    **Use Cases:**
                    - Register new customers
                    - Add client information before creating sales
                    - Import customer data

                    **Validations:**
                    - firstName: required, min=3, max=20 characters
                    - surname: required, min=3, max=20 characters
                    - birthDateClient: required, date format

                    **Note:**
                    - Uses custom clientMapper for field mapping
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Client created successfully. Location header contains URI of created resource.",
                    headers = @io.swagger.v3.oas.annotations.headers.Header(
                            name = "Location",
                            description = "URI of the created client",
                            schema = @Schema(type = "string", example = "/clients/1")
                    )
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Invalid input data - validation failed",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Validation Error Response",
                                    value = """
                                            {
                                              "status": 400,
                                              "message": "bad-request",
                                              "data": [
                                                {
                                                  "datetime": "2025-10-12T10:30:00",
                                                  "message": "Validation failed: firstName size must be between 3 and 20",
                                                  "path": "uri=/clients"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
    })
    @PostMapping
    ResponseEntity<Void> save(
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Client data to create",
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ClientDTO.class),
                            examples = @ExampleObject(
                                    name = "Create Client Example",
                                    value = """
                                            {
                                              "firstName": "John",
                                              "surname": "Doe",
                                              "birthDateClient": "1990-01-15"
                                            }
                                            """
                            )
                    )
            )
            @Valid @RequestBody ClientDTO dto
    );

    @Operation(
            summary = "Update a client",
            description = """
                    Updates an existing client by their unique identifier.

                    **Happy Path:**
                    - Returns 200 OK with updated client data wrapped in GenericResponse
                    - Client is updated in database

                    **Unhappy Path:**
                    - Returns 404 NOT_FOUND if client with given ID doesn't exist
                    - Returns 400 BAD_REQUEST if validation fails
                    - Throws ModelNotFoundException handled by GlobalErrorHandler

                    **Use Cases:**
                    - Update customer contact information
                    - Correct client data entry errors
                    - Update client profile details

                    **Validations:**
                    - All fields validated same as create operation
                    - ID must exist in database

                    **Note:**
                    - Uses custom clientMapper for field mapping
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Client updated successfully",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Success Response",
                                    value = """
                                            {
                                              "status": 200,
                                              "message": "success",
                                              "data": [
                                                {
                                                  "idClient": 1,
                                                  "firstName": "John",
                                                  "surname": "Doe-Smith",
                                                  "birthDateClient": "1990-01-15"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Invalid input data - validation failed",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Validation Error Response",
                                    value = """
                                            {
                                              "status": 400,
                                              "message": "bad-request",
                                              "data": [
                                                {
                                                  "datetime": "2025-10-12T10:30:00",
                                                  "message": "Validation failed: firstName size must be between 3 and 20",
                                                  "path": "uri=/clients/1"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Client not found",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Not Found Response",
                                    value = """
                                            {
                                              "status": 404,
                                              "message": "not-found",
                                              "data": [
                                                {
                                                  "datetime": "2025-10-12T10:30:00",
                                                  "message": "Client with ID 999 not found",
                                                  "path": "uri=/clients/999"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
    })
    @PutMapping("/{id}")
    ResponseEntity<GenericResponse<ClientDTO>> update(
            @Parameter(description = "Client unique identifier", required = true, example = "1")
            @PathVariable("id") Integer id,
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Updated client data",
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = ClientDTO.class),
                            examples = @ExampleObject(
                                    name = "Update Client Example",
                                    value = """
                                            {
                                              "firstName": "John",
                                              "surname": "Doe-Smith",
                                              "birthDateClient": "1990-01-15"
                                            }
                                            """
                            )
                    )
            )
            @Valid @RequestBody ClientDTO dto
    );

    @Operation(
            summary = "Delete a client",
            description = """
                    Deletes a client by their unique identifier.

                    **Happy Path:**
                    - Returns 204 NO_CONTENT
                    - Client is permanently removed from database

                    **Unhappy Path:**
                    - Returns 404 NOT_FOUND if client with given ID doesn't exist
                    - Throws ModelNotFoundException handled by GlobalErrorHandler

                    **Warning:**
                    - This is a permanent operation
                    - Deleting a client may affect existing sales records
                    - Consider checking for sales dependencies before deletion
                    - Consider soft delete (status flag) for audit purposes and data integrity

                    **Use Cases:**
                    - Remove duplicate client entries
                    - Clean up test data
                    - Handle GDPR data deletion requests

                    **Best Practice:**
                    - Always check for associated sales before deleting
                    - Consider data retention policies
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "204",
                    description = "Client deleted successfully"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Client not found",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Not Found Response",
                                    value = """
                                            {
                                              "status": 404,
                                              "message": "not-found",
                                              "data": [
                                                {
                                                  "datetime": "2025-10-12T10:30:00",
                                                  "message": "Client with ID 999 not found",
                                                  "path": "uri=/clients/999"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
    })
    @DeleteMapping("/{id}")
    ResponseEntity<Void> delete(
            @Parameter(description = "Client unique identifier to delete", required = true, example = "1")
            @PathVariable("id") Integer id
    );
}
