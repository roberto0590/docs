package com.mitocode.dto;

import com.fasterxml.jackson.annotation.JsonBackReference;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Sale detail data transfer object")
public class SaleDetailDTO {

    //@NotNull
    @JsonBackReference
    @Schema(description = "Parent sale reference", hidden = true)
    private SaleDTO sale;

    @NotNull
    @Schema(description = "Book information", required = true)
    private BookDTO book;

    @NotNull
    @Schema(description = "Unit price", example = "25.99", required = true)
    private double unitPrice;

    @NotNull
    @Schema(description = "Quantity", example = "2", required = true)
    private short quantity;

    @NotNull
    @Schema(description = "Detail status", example = "true", required = true)
    private boolean status;
}
