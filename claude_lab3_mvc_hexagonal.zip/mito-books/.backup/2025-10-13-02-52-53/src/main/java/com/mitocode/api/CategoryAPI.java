package com.mitocode.api;

import com.mitocode.dto.CategoryDTO;
import com.mitocode.dto.GenericResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Category API Documentation Interface
 *
 * This interface defines all category management endpoints with comprehensive OpenAPI documentation.
 * Categories are used to organize books into different genres and types.
 * It follows the Single Responsibility Principle by separating API documentation from controller logic.
 *
 * Endpoints:
 * - GET /categories - Retrieve all categories
 * - GET /categories/{id} - Retrieve a category by ID
 * - POST /categories - Create a new category
 * - PUT /categories/{id} - Update an existing category
 * - DELETE /categories/{id} - Delete a category
 */
@Tag(name = "Categories", description = "Category management endpoints for organizing books. Categories help classify books into genres, topics, or types.")
public interface CategoryAPI {

    @Operation(
            summary = "Get all categories",
            description = """
                    Retrieves a complete list of all categories in the bookstore system.

                    **Happy Path:**
                    - Returns 200 OK with a list of all categories wrapped in GenericResponse
                    - Empty list returned if no categories exist

                    **Use Cases:**
                    - Display category dropdown in book management UI
                    - Show all available categories for filtering
                    - Get master list for category management
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Successfully retrieved list of categories",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Success Response",
                                    value = """
                                            {
                                              "status": 200,
                                              "message": "success",
                                              "data": [
                                                {
                                                  "idCategory": 1,
                                                  "categoryName": "Programming",
                                                  "status": true
                                                },
                                                {
                                                  "idCategory": 2,
                                                  "categoryName": "Fiction",
                                                  "status": true
                                                },
                                                {
                                                  "idCategory": 3,
                                                  "categoryName": "Science",
                                                  "status": false
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
    })
    @GetMapping
    ResponseEntity<GenericResponse<CategoryDTO>> getAllCategories();

    @Operation(
            summary = "Get category by ID",
            description = """
                    Retrieves a specific category by its unique identifier.

                    **Happy Path:**
                    - Returns 200 OK with the category data wrapped in GenericResponse

                    **Unhappy Path:**
                    - Returns 404 NOT_FOUND if category with given ID doesn't exist
                    - Throws ModelNotFoundException handled by GlobalErrorHandler

                    **Use Cases:**
                    - View detailed information about a specific category
                    - Verify category existence before assigning to books
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Successfully retrieved category",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Success Response",
                                    value = """
                                            {
                                              "status": 200,
                                              "message": "success",
                                              "data": [
                                                {
                                                  "idCategory": 1,
                                                  "categoryName": "Programming",
                                                  "status": true
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Category not found",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Not Found Response",
                                    value = """
                                            {
                                              "status": 404,
                                              "message": "not-found",
                                              "data": [
                                                {
                                                  "datetime": "2025-10-12T10:30:00",
                                                  "message": "Category with ID 999 not found",
                                                  "path": "uri=/categories/999"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
    })
    @GetMapping("/{id}")
    ResponseEntity<GenericResponse<CategoryDTO>> getCategoryById(
            @Parameter(description = "Category unique identifier", required = true, example = "1")
            @PathVariable("id") Integer id
    );

    @Operation(
            summary = "Create a new category",
            description = """
                    Creates a new category in the bookstore system.

                    **Happy Path:**
                    - Returns 201 CREATED with Location header pointing to the new resource
                    - Category is persisted to database
                    - Location: /categories/{newCategoryId}

                    **Unhappy Path:**
                    - Returns 400 BAD_REQUEST if validation fails
                    - Validation errors: missing required fields

                    **Use Cases:**
                    - Add new book categories/genres
                    - Expand categorization system

                    **Note:**
                    - Category names should be unique for better organization
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Category created successfully. Location header contains URI of created resource.",
                    headers = @io.swagger.v3.oas.annotations.headers.Header(
                            name = "Location",
                            description = "URI of the created category",
                            schema = @Schema(type = "string", example = "/categories/1")
                    )
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Invalid input data - validation failed",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Validation Error Response",
                                    value = """
                                            {
                                              "status": 400,
                                              "message": "bad-request",
                                              "data": [
                                                {
                                                  "datetime": "2025-10-12T10:30:00",
                                                  "message": "Validation failed for object='categoryDTO'. Error count: 1",
                                                  "path": "uri=/categories"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
    })
    @PostMapping
    ResponseEntity<Void> save(
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Category data to create",
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = CategoryDTO.class),
                            examples = @ExampleObject(
                                    name = "Create Category Example",
                                    value = """
                                            {
                                              "categoryName": "Programming",
                                              "status": true
                                            }
                                            """
                            )
                    )
            )
            @RequestBody CategoryDTO dto
    );

    @Operation(
            summary = "Update a category",
            description = """
                    Updates an existing category by its unique identifier.

                    **Happy Path:**
                    - Returns 200 OK with updated category data wrapped in GenericResponse
                    - Category is updated in database

                    **Unhappy Path:**
                    - Returns 404 NOT_FOUND if category with given ID doesn't exist
                    - Throws ModelNotFoundException handled by GlobalErrorHandler

                    **Use Cases:**
                    - Update category name for clarity
                    - Enable/disable categories
                    - Rename categories for better organization

                    **Note:**
                    - Updating a category doesn't affect existing book assignments
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Category updated successfully",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Success Response",
                                    value = """
                                            {
                                              "status": 200,
                                              "message": "success",
                                              "data": [
                                                {
                                                  "idCategory": 1,
                                                  "categoryName": "Software Development",
                                                  "status": true
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Category not found",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Not Found Response",
                                    value = """
                                            {
                                              "status": 404,
                                              "message": "not-found",
                                              "data": [
                                                {
                                                  "datetime": "2025-10-12T10:30:00",
                                                  "message": "Category with ID 999 not found",
                                                  "path": "uri=/categories/999"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
    })
    @PutMapping("/{id}")
    ResponseEntity<GenericResponse<CategoryDTO>> update(
            @Parameter(description = "Category unique identifier", required = true, example = "1")
            @PathVariable("id") Integer id,
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Updated category data",
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = CategoryDTO.class),
                            examples = @ExampleObject(
                                    name = "Update Category Example",
                                    value = """
                                            {
                                              "categoryName": "Software Development",
                                              "status": true
                                            }
                                            """
                            )
                    )
            )
            @RequestBody CategoryDTO dto
    );

    @Operation(
            summary = "Delete a category",
            description = """
                    Deletes a category by its unique identifier.

                    **Happy Path:**
                    - Returns 204 NO_CONTENT
                    - Category is permanently removed from database

                    **Unhappy Path:**
                    - Returns 404 NOT_FOUND if category with given ID doesn't exist
                    - Throws ModelNotFoundException handled by GlobalErrorHandler

                    **Warning:**
                    - This is a permanent operation
                    - Deleting a category may affect books assigned to it
                    - Consider checking for book dependencies before deletion
                    - Consider soft delete (status flag) for audit purposes

                    **Use Cases:**
                    - Remove unused categories
                    - Clean up duplicate or obsolete categories
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "204",
                    description = "Category deleted successfully"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Category not found",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Not Found Response",
                                    value = """
                                            {
                                              "status": 404,
                                              "message": "not-found",
                                              "data": [
                                                {
                                                  "datetime": "2025-10-12T10:30:00",
                                                  "message": "Category with ID 999 not found",
                                                  "path": "uri=/categories/999"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
    })
    @DeleteMapping("/{id}")
    ResponseEntity<Void> delete(
            @Parameter(description = "Category unique identifier to delete", required = true, example = "1")
            @PathVariable("id") Integer id
    );
}
