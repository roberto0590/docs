package com.mitocode.api;

import com.mitocode.dto.GenericResponse;
import com.mitocode.dto.SaleDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Sale API Documentation Interface
 *
 * This interface defines all sales transaction management endpoints with comprehensive OpenAPI documentation.
 * Sales represent complete purchase transactions including client information and multiple book items (sale details).
 * It follows the Single Responsibility Principle by separating API documentation from controller logic.
 *
 * Endpoints:
 * - GET /sales - Retrieve all sales
 * - GET /sales/{id} - Retrieve a sale by ID
 * - POST /sales - Create a new sale
 * - PUT /sales/{id} - Update an existing sale
 * - DELETE /sales/{id} - Delete a sale
 *
 * Note: This controller uses a custom ModelMapper (saleMapper) for nested mapping with Client fields.
 * Sales have a one-to-many relationship with SaleDetails (books purchased).
 */
@Tag(name = "Sales", description = "Sales transaction management endpoints. Handles complete purchase operations including client and book details.")
public interface SaleAPI {

    @Operation(
            summary = "Get all sales",
            description = """
                    Retrieves a complete list of all sales transactions in the bookstore system.

                    **Happy Path:**
                    - Returns 200 OK with a list of all sales wrapped in GenericResponse
                    - Each sale includes client information and list of sale details (books)
                    - Empty list returned if no sales exist

                    **Use Cases:**
                    - Display sales history for reporting
                    - Generate sales reports
                    - View all transactions for accounting
                    - Monitor business performance

                    **Note:**
                    - Uses custom saleMapper for nested object mapping
                    - Includes complete sale details with book information
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Successfully retrieved list of sales",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Success Response",
                                    value = """
                                            {
                                              "status": 200,
                                              "message": "success",
                                              "data": [
                                                {
                                                  "idSale": 1,
                                                  "client": {
                                                    "idClient": 1,
                                                    "firstName": "John",
                                                    "surname": "Doe",
                                                    "birthDateClient": "1990-01-15"
                                                  },
                                                  "momentSale": "2025-10-12T10:30:00",
                                                  "totalSale": 75.98,
                                                  "statusSale": true,
                                                  "details": [
                                                    {
                                                      "book": {
                                                        "idBook": 1,
                                                        "idCategory": 1,
                                                        "title": "Clean Code",
                                                        "isbn": "978-0132350884",
                                                        "photoUrl": "https://example.com/clean-code.jpg",
                                                        "status": true
                                                      },
                                                      "unitPrice": 49.99,
                                                      "quantity": 1,
                                                      "status": true
                                                    },
                                                    {
                                                      "book": {
                                                        "idBook": 2,
                                                        "idCategory": 2,
                                                        "title": "Design Patterns",
                                                        "isbn": "978-0201633610",
                                                        "photoUrl": "https://example.com/design-patterns.jpg",
                                                        "status": true
                                                      },
                                                      "unitPrice": 25.99,
                                                      "quantity": 1,
                                                      "status": true
                                                    }
                                                  ]
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
    })
    @GetMapping
    ResponseEntity<GenericResponse<SaleDTO>> getAllSales();

    @Operation(
            summary = "Get sale by ID",
            description = """
                    Retrieves a specific sale transaction by its unique identifier.

                    **Happy Path:**
                    - Returns 200 OK with the sale data wrapped in GenericResponse
                    - Includes complete client information
                    - Includes all sale details with book information

                    **Unhappy Path:**
                    - Returns 404 NOT_FOUND if sale with given ID doesn't exist
                    - Throws ModelNotFoundException handled by GlobalErrorHandler

                    **Use Cases:**
                    - View complete sale transaction details
                    - Display receipt/invoice information
                    - Verify sale data for customer service
                    - Review individual transactions
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Successfully retrieved sale",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Success Response",
                                    value = """
                                            {
                                              "status": 200,
                                              "message": "success",
                                              "data": [
                                                {
                                                  "idSale": 1,
                                                  "client": {
                                                    "idClient": 1,
                                                    "firstName": "John",
                                                    "surname": "Doe",
                                                    "birthDateClient": "1990-01-15"
                                                  },
                                                  "momentSale": "2025-10-12T10:30:00",
                                                  "totalSale": 75.98,
                                                  "statusSale": true,
                                                  "details": [
                                                    {
                                                      "book": {
                                                        "idBook": 1,
                                                        "idCategory": 1,
                                                        "title": "Clean Code",
                                                        "isbn": "978-0132350884",
                                                        "photoUrl": "https://example.com/clean-code.jpg",
                                                        "status": true
                                                      },
                                                      "unitPrice": 49.99,
                                                      "quantity": 1,
                                                      "status": true
                                                    }
                                                  ]
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Sale not found",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Not Found Response",
                                    value = """
                                            {
                                              "status": 404,
                                              "message": "not-found",
                                              "data": [
                                                {
                                                  "datetime": "2025-10-12T10:30:00",
                                                  "message": "Sale with ID 999 not found",
                                                  "path": "uri=/sales/999"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
    })
    @GetMapping("/{id}")
    ResponseEntity<GenericResponse<SaleDTO>> getSaleById(
            @Parameter(description = "Sale unique identifier", required = true, example = "1")
            @PathVariable("id") Integer id
    );

    @Operation(
            summary = "Create a new sale",
            description = """
                    Creates a new sale transaction in the bookstore system.

                    **Happy Path:**
                    - Returns 201 CREATED with Location header pointing to the new resource
                    - Sale and all sale details are persisted to database with cascade
                    - Location: /sales/{newSaleId}

                    **Unhappy Path:**
                    - Returns 400 BAD_REQUEST if validation fails
                    - Validation errors: missing required fields, invalid client, empty details list

                    **Use Cases:**
                    - Process new book purchases
                    - Create sales transactions at checkout
                    - Record customer purchases

                    **Business Rules:**
                    - Client must exist in the system
                    - At least one sale detail (book) is required
                    - Total sale amount should match sum of (unitPrice * quantity) for all details
                    - Books must exist and be available

                    **Validations:**
                    - client: required, must be valid ClientDTO
                    - momentSale: required, datetime format
                    - totalSale: required, positive number
                    - statusSale: required, boolean
                    - details: required, non-empty list of SaleDetailDTO

                    **Note:**
                    - Uses custom saleMapper for nested object mapping
                    - Sale details are saved with cascade operation
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Sale created successfully. Location header contains URI of created resource.",
                    headers = @io.swagger.v3.oas.annotations.headers.Header(
                            name = "Location",
                            description = "URI of the created sale",
                            schema = @Schema(type = "string", example = "/sales/1")
                    )
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Invalid input data - validation failed",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Validation Error Response",
                                    value = """
                                            {
                                              "status": 400,
                                              "message": "bad-request",
                                              "data": [
                                                {
                                                  "datetime": "2025-10-12T10:30:00",
                                                  "message": "Validation failed: client must not be null",
                                                  "path": "uri=/sales"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
    })
    @PostMapping
    ResponseEntity<Void> save(
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Sale transaction data to create including client and sale details",
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = SaleDTO.class),
                            examples = @ExampleObject(
                                    name = "Create Sale Example",
                                    value = """
                                            {
                                              "client": {
                                                "idClient": 1,
                                                "firstName": "John",
                                                "surname": "Doe",
                                                "birthDateClient": "1990-01-15"
                                              },
                                              "momentSale": "2025-10-12T10:30:00",
                                              "totalSale": 75.98,
                                              "statusSale": true,
                                              "details": [
                                                {
                                                  "book": {
                                                    "idBook": 1,
                                                    "idCategory": 1,
                                                    "title": "Clean Code",
                                                    "isbn": "978-0132350884",
                                                    "photoUrl": "https://example.com/clean-code.jpg",
                                                    "status": true
                                                  },
                                                  "unitPrice": 49.99,
                                                  "quantity": 1,
                                                  "status": true
                                                },
                                                {
                                                  "book": {
                                                    "idBook": 2,
                                                    "idCategory": 2,
                                                    "title": "Design Patterns",
                                                    "isbn": "978-0201633610",
                                                    "photoUrl": "https://example.com/design-patterns.jpg",
                                                    "status": true
                                                  },
                                                  "unitPrice": 25.99,
                                                  "quantity": 1,
                                                  "status": true
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
            @Valid @RequestBody SaleDTO dto
    );

    @Operation(
            summary = "Update a sale",
            description = """
                    Updates an existing sale transaction by its unique identifier.

                    **Happy Path:**
                    - Returns 200 OK with updated sale data wrapped in GenericResponse
                    - Sale and details are updated in database

                    **Unhappy Path:**
                    - Returns 404 NOT_FOUND if sale with given ID doesn't exist
                    - Returns 400 BAD_REQUEST if validation fails
                    - Throws ModelNotFoundException handled by GlobalErrorHandler

                    **Use Cases:**
                    - Correct sale information errors
                    - Update sale status
                    - Modify sale details (add/remove books)
                    - Adjust quantities or prices

                    **Business Rules:**
                    - Sale must exist in the system
                    - All validation rules from create apply
                    - Consider audit trail for financial transactions

                    **Validations:**
                    - All fields validated same as create operation
                    - ID must exist in database

                    **Warning:**
                    - Updating completed sales may affect accounting
                    - Consider implementing sale status workflow (draft, confirmed, completed)
                    - Consider immutability of completed sales

                    **Note:**
                    - Uses custom saleMapper for nested object mapping
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Sale updated successfully",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Success Response",
                                    value = """
                                            {
                                              "status": 200,
                                              "message": "success",
                                              "data": [
                                                {
                                                  "idSale": 1,
                                                  "client": {
                                                    "idClient": 1,
                                                    "firstName": "John",
                                                    "surname": "Doe",
                                                    "birthDateClient": "1990-01-15"
                                                  },
                                                  "momentSale": "2025-10-12T10:30:00",
                                                  "totalSale": 125.97,
                                                  "statusSale": true,
                                                  "details": [
                                                    {
                                                      "book": {
                                                        "idBook": 1,
                                                        "idCategory": 1,
                                                        "title": "Clean Code",
                                                        "isbn": "978-0132350884",
                                                        "photoUrl": "https://example.com/clean-code.jpg",
                                                        "status": true
                                                      },
                                                      "unitPrice": 49.99,
                                                      "quantity": 2,
                                                      "status": true
                                                    }
                                                  ]
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Invalid input data - validation failed",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Validation Error Response",
                                    value = """
                                            {
                                              "status": 400,
                                              "message": "bad-request",
                                              "data": [
                                                {
                                                  "datetime": "2025-10-12T10:30:00",
                                                  "message": "Validation failed: totalSale must be positive",
                                                  "path": "uri=/sales/1"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Sale not found",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Not Found Response",
                                    value = """
                                            {
                                              "status": 404,
                                              "message": "not-found",
                                              "data": [
                                                {
                                                  "datetime": "2025-10-12T10:30:00",
                                                  "message": "Sale with ID 999 not found",
                                                  "path": "uri=/sales/999"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
    })
    @PutMapping("/{id}")
    ResponseEntity<GenericResponse<SaleDTO>> update(
            @Parameter(description = "Sale unique identifier", required = true, example = "1")
            @PathVariable("id") Integer id,
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Updated sale transaction data",
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = SaleDTO.class),
                            examples = @ExampleObject(
                                    name = "Update Sale Example",
                                    value = """
                                            {
                                              "client": {
                                                "idClient": 1,
                                                "firstName": "John",
                                                "surname": "Doe",
                                                "birthDateClient": "1990-01-15"
                                              },
                                              "momentSale": "2025-10-12T10:30:00",
                                              "totalSale": 125.97,
                                              "statusSale": true,
                                              "details": [
                                                {
                                                  "book": {
                                                    "idBook": 1,
                                                    "idCategory": 1,
                                                    "title": "Clean Code",
                                                    "isbn": "978-0132350884",
                                                    "photoUrl": "https://example.com/clean-code.jpg",
                                                    "status": true
                                                  },
                                                  "unitPrice": 49.99,
                                                  "quantity": 2,
                                                  "status": true
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
            @Valid @RequestBody SaleDTO dto
    );

    @Operation(
            summary = "Delete a sale",
            description = """
                    Deletes a sale transaction by its unique identifier.

                    **Happy Path:**
                    - Returns 204 NO_CONTENT
                    - Sale and associated sale details are permanently removed from database

                    **Unhappy Path:**
                    - Returns 404 NOT_FOUND if sale with given ID doesn't exist
                    - Throws ModelNotFoundException handled by GlobalErrorHandler

                    **Warning:**
                    - This is a permanent operation
                    - Deletes sale and all associated sale details (cascade)
                    - Affects financial records and reporting
                    - Consider data retention and audit requirements

                    **Use Cases:**
                    - Remove cancelled transactions
                    - Clean up test data
                    - Handle refunds (consider creating refund records instead)

                    **Best Practice:**
                    - Avoid deleting completed sales for audit purposes
                    - Consider soft delete (statusSale flag) instead
                    - Implement proper authorization for delete operations
                    - Maintain transaction history for accounting compliance
                    - Consider creating a separate refund/cancellation mechanism

                    **Compliance Note:**
                    - Many jurisdictions require maintaining transaction records
                    - Check legal and accounting requirements before implementing delete
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "204",
                    description = "Sale deleted successfully"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Sale not found",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Not Found Response",
                                    value = """
                                            {
                                              "status": 404,
                                              "message": "not-found",
                                              "data": [
                                                {
                                                  "datetime": "2025-10-12T10:30:00",
                                                  "message": "Sale with ID 999 not found",
                                                  "path": "uri=/sales/999"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
    })
    @DeleteMapping("/{id}")
    ResponseEntity<Void> delete(
            @Parameter(description = "Sale unique identifier to delete", required = true, example = "1")
            @PathVariable("id") Integer id
    );
}
