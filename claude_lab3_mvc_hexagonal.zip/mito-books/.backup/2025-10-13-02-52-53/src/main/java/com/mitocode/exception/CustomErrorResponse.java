package com.mitocode.exception;

import io.swagger.v3.oas.annotations.media.Schema;

import java.time.LocalDateTime;

@Schema(description = "Error response object")
public record CustomErrorResponse(
        @Schema(description = "Error timestamp", example = "2025-10-12T10:30:00")
        LocalDateTime datetime,

        @Schema(description = "Error message", example = "Resource not found")
        String message,

        @Schema(description = "Request path", example = "/api/books/999")
        String path
) {
}
