package com.mitocode.repo;

import com.mitocode.model.Client;

public interface IClientRepo extends IGenericRepo<Client, Integer> {


}
