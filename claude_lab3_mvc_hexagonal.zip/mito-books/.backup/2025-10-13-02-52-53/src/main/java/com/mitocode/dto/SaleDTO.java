package com.mitocode.dto;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Sale transaction data transfer object")
public class SaleDTO {

    @Schema(description = "Sale unique identifier", example = "1", accessMode = Schema.AccessMode.READ_ONLY)
    private Integer idSale;

    @NotNull
    @Schema(description = "Client information", required = true)
    private ClientDTO client;

    @NotNull
    @Schema(description = "Sale timestamp", example = "2025-10-12T10:30:00", required = true)
    private LocalDateTime momentSale;

    @NotNull
    @Schema(description = "Total sale amount", example = "150.50", required = true)
    private double totalSale;

    @NotNull
    @Schema(description = "Sale status", example = "true", required = true)
    private boolean statusSale;

    @JsonManagedReference
    @NotNull
    @Schema(description = "List of sale details", required = true)
    private List<SaleDetailDTO> details;
}
