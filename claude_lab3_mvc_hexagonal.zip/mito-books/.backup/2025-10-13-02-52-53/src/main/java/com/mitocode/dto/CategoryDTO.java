package com.mitocode.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Category data transfer object")
public class CategoryDTO {

    @Schema(description = "Category unique identifier", example = "1", accessMode = Schema.AccessMode.READ_ONLY)
    private Integer idCategory;

    @Schema(description = "Category name", example = "Fiction", required = true)
    private String categoryName;

    @Schema(description = "Category status", example = "true", required = true)
    private boolean status;
}
