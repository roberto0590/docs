package com.mitocode.api;

import com.mitocode.dto.BookDTO;
import com.mitocode.dto.GenericResponse;
import com.mitocode.exception.CustomErrorResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Book API Documentation Interface
 *
 * This interface defines all book management endpoints with comprehensive OpenAPI documentation.
 * It follows the Single Responsibility Principle by separating API documentation from controller logic.
 *
 * Endpoints:
 * - GET /books - Retrieve all books
 * - GET /books/{id} - Retrieve a book by ID
 * - POST /books - Create a new book
 * - PUT /books/{id} - Update an existing book
 * - DELETE /books/{id} - Delete a book
 * - GET /books/byCategory - Get books by category name
 */
@Tag(name = "Books", description = "Book management endpoints for the bookstore system. Handles CRUD operations for books including search by category.")
public interface BookAPI {

    @Operation(
            summary = "Get all books",
            description = """
                    Retrieves a complete list of all books in the bookstore system.

                    **Happy Path:**
                    - Returns 200 OK with a list of all books wrapped in GenericResponse
                    - Empty list returned if no books exist

                    **Use Cases:**
                    - Display all available books in the bookstore
                    - Get inventory list for management
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Successfully retrieved list of books",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Success Response",
                                    value = """
                                            {
                                              "status": 200,
                                              "message": "success",
                                              "data": [
                                                {
                                                  "idBook": 1,
                                                  "idCategory": 1,
                                                  "title": "Clean Code",
                                                  "isbn": "978-0132350884",
                                                  "photoUrl": "https://example.com/clean-code.jpg",
                                                  "status": true
                                                },
                                                {
                                                  "idBook": 2,
                                                  "idCategory": 2,
                                                  "title": "Design Patterns",
                                                  "isbn": "978-0201633610",
                                                  "photoUrl": "https://example.com/design-patterns.jpg",
                                                  "status": true
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
    })
    @GetMapping
    ResponseEntity<GenericResponse<BookDTO>> getAllBooks();

    @Operation(
            summary = "Get book by ID",
            description = """
                    Retrieves a specific book by its unique identifier.

                    **Happy Path:**
                    - Returns 200 OK with the book data wrapped in GenericResponse

                    **Unhappy Path:**
                    - Returns 404 NOT_FOUND if book with given ID doesn't exist
                    - Throws ModelNotFoundException handled by GlobalErrorHandler

                    **Use Cases:**
                    - View detailed information about a specific book
                    - Verify book existence before operations
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Successfully retrieved book",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Success Response",
                                    value = """
                                            {
                                              "status": 200,
                                              "message": "success",
                                              "data": [
                                                {
                                                  "idBook": 1,
                                                  "idCategory": 1,
                                                  "title": "Clean Code",
                                                  "isbn": "978-0132350884",
                                                  "photoUrl": "https://example.com/clean-code.jpg",
                                                  "status": true
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Book not found",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Not Found Response",
                                    value = """
                                            {
                                              "status": 404,
                                              "message": "not-found",
                                              "data": [
                                                {
                                                  "datetime": "2025-10-12T10:30:00",
                                                  "message": "Book with ID 999 not found",
                                                  "path": "uri=/books/999"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
    })
    @GetMapping("/{id}")
    ResponseEntity<GenericResponse<BookDTO>> getBookById(
            @Parameter(description = "Book unique identifier", required = true, example = "1")
            @PathVariable("id") Integer id
    );

    @Operation(
            summary = "Create a new book",
            description = """
                    Creates a new book in the bookstore system.

                    **Happy Path:**
                    - Returns 201 CREATED with Location header pointing to the new resource
                    - Book is persisted to database with the provided ID
                    - Location: /books/{idBook}

                    **Unhappy Path:**
                    - Returns 400 BAD_REQUEST if validation fails
                    - Returns 500 if ID already exists (duplicate key)
                    - Validation errors: missing required fields, invalid ISBN format, category ID out of range

                    **Use Cases:**
                    - Add new books to inventory with specific IDs
                    - Populate bookstore catalog
                    - Import books from external systems maintaining IDs

                    **Important:**
                    - The idBook must be manually assigned (not auto-generated)
                    - Ensure the ID is unique before creating

                    **Validations:**
                    - idBook: required (manually assigned, must be unique)
                    - title: required
                    - isbn: required, unique
                    - idCategory: required, min=1, max=100
                    - photoUrl: required
                    - status: required
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "201",
                    description = "Book created successfully. Location header contains URI of created resource.",
                    headers = @io.swagger.v3.oas.annotations.headers.Header(
                            name = "Location",
                            description = "URI of the created book",
                            schema = @Schema(type = "string", example = "/books/1")
                    )
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Invalid input data - validation failed",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Validation Error Response",
                                    value = """
                                            {
                                              "status": 400,
                                              "message": "bad-request",
                                              "data": [
                                                {
                                                  "datetime": "2025-10-12T10:30:00",
                                                  "message": "Validation failed for object='bookDTO'. Error count: 1",
                                                  "path": "uri=/books"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
    })
    @PostMapping
    ResponseEntity<Void> save(
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Book data to create",
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = BookDTO.class),
                            examples = @ExampleObject(
                                    name = "Create Book Example",
                                    value = """
                                            {
                                              "idBook": 1,
                                              "idCategory": 1,
                                              "title": "Clean Code",
                                              "isbn": "978-0132350884",
                                              "photoUrl": "https://example.com/clean-code.jpg",
                                              "status": true
                                            }
                                            """
                            )
                    )
            )
            @Valid @RequestBody BookDTO dto
    );

    @Operation(
            summary = "Update a book",
            description = """
                    Updates an existing book by its unique identifier.

                    **Happy Path:**
                    - Returns 200 OK with updated book data wrapped in GenericResponse
                    - Book is updated in database

                    **Unhappy Path:**
                    - Returns 404 NOT_FOUND if book with given ID doesn't exist
                    - Returns 400 BAD_REQUEST if validation fails
                    - Throws ModelNotFoundException handled by GlobalErrorHandler

                    **Use Cases:**
                    - Update book information (title, price, photo, etc.)
                    - Change book status (enable/disable)
                    - Update category assignment

                    **Validations:**
                    - All fields validated same as create operation
                    - ID must exist in database
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Book updated successfully",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Success Response",
                                    value = """
                                            {
                                              "status": 200,
                                              "message": "success",
                                              "data": [
                                                {
                                                  "idBook": 1,
                                                  "idCategory": 1,
                                                  "title": "Clean Code - Updated",
                                                  "isbn": "978-0132350884",
                                                  "photoUrl": "https://example.com/clean-code-new.jpg",
                                                  "status": true
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Invalid input data - validation failed",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Validation Error Response",
                                    value = """
                                            {
                                              "status": 400,
                                              "message": "bad-request",
                                              "data": [
                                                {
                                                  "datetime": "2025-10-12T10:30:00",
                                                  "message": "Validation failed for object='bookDTO'. Error count: 1",
                                                  "path": "uri=/books/1"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Book not found",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Not Found Response",
                                    value = """
                                            {
                                              "status": 404,
                                              "message": "not-found",
                                              "data": [
                                                {
                                                  "datetime": "2025-10-12T10:30:00",
                                                  "message": "Book with ID 999 not found",
                                                  "path": "uri=/books/999"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
    })
    @PutMapping("/{id}")
    ResponseEntity<GenericResponse<BookDTO>> update(
            @Parameter(description = "Book unique identifier", required = true, example = "1")
            @PathVariable("id") Integer id,
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Updated book data",
                    required = true,
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = BookDTO.class),
                            examples = @ExampleObject(
                                    name = "Update Book Example",
                                    value = """
                                            {
                                              "idBook": 1,
                                              "idCategory": 1,
                                              "title": "Clean Code - Updated",
                                              "isbn": "978-0132350884",
                                              "photoUrl": "https://example.com/clean-code-new.jpg",
                                              "status": true
                                            }
                                            """
                            )
                    )
            )
            @Valid @RequestBody BookDTO dto
    );

    @Operation(
            summary = "Delete a book",
            description = """
                    Deletes a book by its unique identifier.

                    **Happy Path:**
                    - Returns 204 NO_CONTENT
                    - Book is permanently removed from database

                    **Unhappy Path:**
                    - Returns 404 NOT_FOUND if book with given ID doesn't exist
                    - Throws ModelNotFoundException handled by GlobalErrorHandler

                    **Use Cases:**
                    - Remove discontinued books from inventory
                    - Clean up test data

                    **Warning:**
                    - This is a permanent operation
                    - Consider soft delete (status flag) for audit purposes
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "204",
                    description = "Book deleted successfully"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Book not found",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Not Found Response",
                                    value = """
                                            {
                                              "status": 404,
                                              "message": "not-found",
                                              "data": [
                                                {
                                                  "datetime": "2025-10-12T10:30:00",
                                                  "message": "Book with ID 999 not found",
                                                  "path": "uri=/books/999"
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
    })
    @DeleteMapping("/{id}")
    ResponseEntity<Void> delete(
            @Parameter(description = "Book unique identifier to delete", required = true, example = "1")
            @PathVariable("id") Integer id
    );

    @Operation(
            summary = "Get books by category",
            description = """
                    Retrieves books filtered by category name using partial matching.

                    **Happy Path:**
                    - Returns 200 OK with list of books matching the category filter
                    - Uses LIKE query for partial matching
                    - Empty list if no matches found

                    **Use Cases:**
                    - Filter books by category on the UI
                    - Search for books in specific genres
                    - Display category-specific catalogs

                    **Search Behavior:**
                    - Case-insensitive partial match
                    - Example: "fiction" matches "Science Fiction", "Historical Fiction"
                    """
    )
    @ApiResponses(value = {
            @ApiResponse(
                    responseCode = "200",
                    description = "Successfully retrieved books by category",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = GenericResponse.class),
                            examples = @ExampleObject(
                                    name = "Success Response",
                                    value = """
                                            {
                                              "status": 200,
                                              "message": "success",
                                              "data": [
                                                {
                                                  "idBook": 1,
                                                  "idCategory": 1,
                                                  "title": "Clean Code",
                                                  "isbn": "978-0132350884",
                                                  "photoUrl": "https://example.com/clean-code.jpg",
                                                  "status": true
                                                }
                                              ]
                                            }
                                            """
                            )
                    )
            )
    })
    @GetMapping("/byCategory")
    ResponseEntity<GenericResponse<BookDTO>> getBooksByCategory(
            @Parameter(
                    description = "Category name filter (partial match supported)",
                    required = true,
                    example = "Programming"
            )
            @RequestParam("category") String category
    );
}
