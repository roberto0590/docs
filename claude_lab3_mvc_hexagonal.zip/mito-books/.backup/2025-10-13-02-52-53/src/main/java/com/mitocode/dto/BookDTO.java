package com.mitocode.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Book data transfer object")
public class BookDTO {

    @NotNull
    @Schema(description = "Book unique identifier", example = "1", required = true)
    private Integer idBook;

    @NotNull
    @Min(value = 1)
    @Max(value = 100)
    @Schema(description = "Category ID", example = "1", required = true)
    private Integer idCategory;

    @NotNull
    @Schema(description = "Book title", example = "Clean Code", required = true)
    private String title;

    @NotNull
    @Schema(description = "ISBN number", example = "978-0132350884", required = true)
    private String isbn;

    @NotNull
    @Schema(description = "Photo URL", example = "https://example.com/book.jpg", required = true)
    private String photoUrl;

    @NotNull
    @Schema(description = "Book status", example = "true", required = true)
    private boolean status;
}
