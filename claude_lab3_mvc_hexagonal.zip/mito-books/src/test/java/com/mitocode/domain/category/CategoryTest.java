package com.mitocode.domain.category;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Nested;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Category domain aggregate.
 * These tests verify domain business logic and invariants.
 */
@DisplayName("Category Domain Tests")
class CategoryTest {

    @Nested
    @DisplayName("Category Creation")
    class CategoryCreation {

        @Test
        @DisplayName("Should create category with valid name")
        void shouldCreateCategoryWithValidName() {
            CategoryName name = CategoryName.of("Fiction");
            Category category = Category.create(name);

            assertNotNull(category);
            assertEquals("Fiction", category.getName().value());
            assertTrue(category.isActive());
            assertFalse(category.hasId());
        }

        @Test
        @DisplayName("Should create category with default active status")
        void shouldCreateCategoryWithDefaultActiveStatus() {
            CategoryName name = CategoryName.of("Science");
            Category category = Category.create(name);

            assertTrue(category.isActive());
        }

        @Test
        @DisplayName("Should reconstitute category with all fields")
        void shouldReconstituteCategoryWithAllFields() {
            CategoryId id = CategoryId.of(1);
            CategoryName name = CategoryName.of("Programming");
            Category category = Category.reconstitute(id, name, true);

            assertNotNull(category);
            assertEquals(1, category.getId().value());
            assertEquals("Programming", category.getName().value());
            assertTrue(category.isActive());
            assertTrue(category.hasId());
        }
    }

    @Nested
    @DisplayName("Category Name Changes")
    class CategoryNameChanges {

        @Test
        @DisplayName("Should change name of active category")
        void shouldChangeNameOfActiveCategory() {
            Category category = Category.create(CategoryName.of("Fiction"));
            category.changeName(CategoryName.of("Science Fiction"));

            assertEquals("Science Fiction", category.getName().value());
        }

        @Test
        @DisplayName("Should throw exception when changing name of inactive category")
        void shouldThrowExceptionWhenChangingNameOfInactiveCategory() {
            Category category = Category.create(CategoryName.of("Fiction"));
            category.deactivate();

            IllegalStateException exception = assertThrows(
                IllegalStateException.class,
                () -> category.changeName(CategoryName.of("New Name"))
            );

            assertEquals("Cannot change name of inactive category", exception.getMessage());
        }

        @Test
        @DisplayName("Should throw exception when changing name to null")
        void shouldThrowExceptionWhenChangingNameToNull() {
            Category category = Category.create(CategoryName.of("Fiction"));

            assertThrows(NullPointerException.class, () -> category.changeName(null));
        }
    }

    @Nested
    @DisplayName("Category Status Changes")
    class CategoryStatusChanges {

        @Test
        @DisplayName("Should activate category")
        void shouldActivateCategory() {
            Category category = Category.create(CategoryName.of("Fiction"));
            category.deactivate();
            category.activate();

            assertTrue(category.isActive());
        }

        @Test
        @DisplayName("Should deactivate category")
        void shouldDeactivateCategory() {
            Category category = Category.create(CategoryName.of("Fiction"));
            category.deactivate();

            assertFalse(category.isActive());
        }
    }

    @Nested
    @DisplayName("Category ID Management")
    class CategoryIdManagement {

        @Test
        @DisplayName("Should set ID on new category")
        void shouldSetIdOnNewCategory() {
            Category category = Category.create(CategoryName.of("Fiction"));
            CategoryId id = CategoryId.of(1);

            category.setId(id);

            assertEquals(1, category.getId().value());
            assertTrue(category.hasId());
        }

        @Test
        @DisplayName("Should throw exception when changing existing ID")
        void shouldThrowExceptionWhenChangingExistingId() {
            CategoryId id1 = CategoryId.of(1);
            Category category = Category.reconstitute(id1, CategoryName.of("Fiction"), true);

            CategoryId id2 = CategoryId.of(2);

            IllegalStateException exception = assertThrows(
                IllegalStateException.class,
                () -> category.setId(id2)
            );

            assertEquals("Cannot change existing category ID", exception.getMessage());
        }
    }

    @Nested
    @DisplayName("Category Equality")
    class CategoryEquality {

        @Test
        @DisplayName("Should be equal when IDs are equal")
        void shouldBeEqualWhenIdsAreEqual() {
            CategoryId id = CategoryId.of(1);
            Category category1 = Category.reconstitute(id, CategoryName.of("Fiction"), true);
            Category category2 = Category.reconstitute(id, CategoryName.of("Science"), false);

            assertEquals(category1, category2);
        }

        @Test
        @DisplayName("Should have same hash code when IDs are equal")
        void shouldHaveSameHashCodeWhenIdsAreEqual() {
            CategoryId id = CategoryId.of(1);
            Category category1 = Category.reconstitute(id, CategoryName.of("Fiction"), true);
            Category category2 = Category.reconstitute(id, CategoryName.of("Science"), false);

            assertEquals(category1.hashCode(), category2.hashCode());
        }
    }
}
