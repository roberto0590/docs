package com.mitocode.domain.category;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for CategoryName value object.
 */
@DisplayName("CategoryName Value Object Tests")
class CategoryNameTest {

    @Test
    @DisplayName("Should create CategoryName with valid name")
    void shouldCreateCategoryNameWithValidName() {
        CategoryName name = CategoryName.of("Fiction");

        assertNotNull(name);
        assertEquals("Fiction", name.value());
    }

    @Test
    @DisplayName("Should trim whitespace when creating CategoryName")
    void shouldTrimWhitespaceWhenCreatingCategoryName() {
        CategoryName name = CategoryName.of("  Fiction  ");

        assertEquals("Fiction", name.value());
    }

    @Test
    @DisplayName("Should throw exception when creating CategoryName with null")
    void shouldThrowExceptionWhenCreatingCategoryNameWithNull() {
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> CategoryName.of(null)
        );

        assertEquals("Category name cannot be null or empty", exception.getMessage());
    }

    @Test
    @DisplayName("Should throw exception when creating CategoryName with empty string")
    void shouldThrowExceptionWhenCreatingCategoryNameWithEmptyString() {
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> CategoryName.of("")
        );

        assertEquals("Category name cannot be null or empty", exception.getMessage());
    }

    @Test
    @DisplayName("Should throw exception when creating CategoryName with blank string")
    void shouldThrowExceptionWhenCreatingCategoryNameWithBlankString() {
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> CategoryName.of("   ")
        );

        assertEquals("Category name cannot be null or empty", exception.getMessage());
    }

    @Test
    @DisplayName("Should throw exception when name exceeds max length")
    void shouldThrowExceptionWhenNameExceedsMaxLength() {
        String longName = "A".repeat(21);

        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> CategoryName.of(longName)
        );

        assertEquals("Category name cannot exceed 20 characters", exception.getMessage());
    }

    @Test
    @DisplayName("Should accept name with exactly max length")
    void shouldAcceptNameWithExactlyMaxLength() {
        String maxLengthName = "A".repeat(20);

        CategoryName name = CategoryName.of(maxLengthName);

        assertEquals(20, name.value().length());
    }

    @Test
    @DisplayName("Should be equal when values are equal")
    void shouldBeEqualWhenValuesAreEqual() {
        CategoryName name1 = CategoryName.of("Fiction");
        CategoryName name2 = CategoryName.of("Fiction");

        assertEquals(name1, name2);
    }
}
