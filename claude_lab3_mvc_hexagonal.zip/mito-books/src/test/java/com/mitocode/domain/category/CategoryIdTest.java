package com.mitocode.domain.category;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for CategoryId value object.
 */
@DisplayName("CategoryId Value Object Tests")
class CategoryIdTest {

    @Test
    @DisplayName("Should create CategoryId with valid positive integer")
    void shouldCreateCategoryIdWithValidPositiveInteger() {
        CategoryId id = CategoryId.of(1);

        assertNotNull(id);
        assertEquals(1, id.value());
    }

    @Test
    @DisplayName("Should throw exception when creating CategoryId with null")
    void shouldThrowExceptionWhenCreatingCategoryIdWithNull() {
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> CategoryId.of(null)
        );

        assertEquals("Category ID cannot be null", exception.getMessage());
    }

    @Test
    @DisplayName("Should throw exception when creating CategoryId with zero")
    void shouldThrowExceptionWhenCreatingCategoryIdWithZero() {
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> CategoryId.of(0)
        );

        assertEquals("Category ID must be positive", exception.getMessage());
    }

    @Test
    @DisplayName("Should throw exception when creating CategoryId with negative number")
    void shouldThrowExceptionWhenCreatingCategoryIdWithNegativeNumber() {
        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> CategoryId.of(-1)
        );

        assertEquals("Category ID must be positive", exception.getMessage());
    }

    @Test
    @DisplayName("Should be equal when values are equal")
    void shouldBeEqualWhenValuesAreEqual() {
        CategoryId id1 = CategoryId.of(1);
        CategoryId id2 = CategoryId.of(1);

        assertEquals(id1, id2);
    }

    @Test
    @DisplayName("Should have same hash code when values are equal")
    void shouldHaveSameHashCodeWhenValuesAreEqual() {
        CategoryId id1 = CategoryId.of(1);
        CategoryId id2 = CategoryId.of(1);

        assertEquals(id1.hashCode(), id2.hashCode());
    }
}
