package com.mitocode.infrastructure.category.adapter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mitocode.dto.CategoryDTO;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Contract tests for CategoryHexagonalController.
 * Verifies 100% API compatibility with OpenAPI specification.
 */
@SpringBootTest
@AutoConfigureMockMvc
@Transactional
@DisplayName("Category Controller Contract Tests")
class CategoryHexagonalControllerContractTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    private static final String BASE_PATH = "/categories/hexagonal";

    @Test
    @DisplayName("GET /categories/hexagonal should return 200 with GenericResponse format")
    void getAllCategories_shouldMatchOpenAPIContract() throws Exception {
        mockMvc.perform(get(BASE_PATH))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value(200))
            .andExpect(jsonPath("$.message").value("success"))
            .andExpect(jsonPath("$.data").isArray());
    }

    @Test
    @DisplayName("POST /categories/hexagonal should return 201 with Location header")
    void createCategory_shouldMatchOpenAPIContract() throws Exception {
        CategoryDTO dto = new CategoryDTO();
        dto.setCategoryName("Programming");
        dto.setStatus(true);

        String requestBody = objectMapper.writeValueAsString(dto);

        mockMvc.perform(post(BASE_PATH)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBody))
            .andExpect(status().isCreated())
            .andExpect(header().exists("Location"))
            .andExpect(header().string("Location", containsString(BASE_PATH)));
    }

    @Test
    @DisplayName("POST /categories/hexagonal with invalid data should return 400")
    void createCategory_withInvalidData_shouldReturn400() throws Exception {
        CategoryDTO dto = new CategoryDTO();
        dto.setCategoryName(""); // Invalid: empty name
        dto.setStatus(true);

        String requestBody = objectMapper.writeValueAsString(dto);

        mockMvc.perform(post(BASE_PATH)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBody))
            .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("GET /categories/hexagonal/{id} should return 200 with GenericResponse format")
    void getCategoryById_shouldMatchOpenAPIContract() throws Exception {
        // First create a category
        CategoryDTO createDto = new CategoryDTO();
        createDto.setCategoryName("Fiction");
        createDto.setStatus(true);

        String createRequestBody = objectMapper.writeValueAsString(createDto);
        String locationHeader = mockMvc.perform(post(BASE_PATH)
                .contentType(MediaType.APPLICATION_JSON)
                .content(createRequestBody))
            .andExpect(status().isCreated())
            .andReturn()
            .getResponse()
            .getHeader("Location");

        // Extract ID from location header
        String[] parts = locationHeader.split("/");
        String id = parts[parts.length - 1];

        // Test GET by ID
        mockMvc.perform(get(BASE_PATH + "/" + id))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.status").value(200))
            .andExpect(jsonPath("$.message").value("success"))
            .andExpect(jsonPath("$.data").isArray())
            .andExpect(jsonPath("$.data[0].idCategory").value(Integer.parseInt(id)))
            .andExpect(jsonPath("$.data[0].categoryName").value("Fiction"))
            .andExpect(jsonPath("$.data[0].status").value(true));
    }

    @Test
    @DisplayName("GET /categories/hexagonal/{id} with non-existent ID should return 404")
    void getCategoryById_withNonExistentId_shouldReturn404() throws Exception {
        mockMvc.perform(get(BASE_PATH + "/99999"))
            .andExpect(status().isNotFound())
            .andExpect(jsonPath("$.status").value(404))
            .andExpect(jsonPath("$.message").value("not-found"));
    }

    @Test
    @DisplayName("PUT /categories/hexagonal/{id} should return 200 with updated data")
    void updateCategory_shouldMatchOpenAPIContract() throws Exception {
        // First create a category
        CategoryDTO createDto = new CategoryDTO();
        createDto.setCategoryName("Science");
        createDto.setStatus(true);

        String createRequestBody = objectMapper.writeValueAsString(createDto);
        String locationHeader = mockMvc.perform(post(BASE_PATH)
                .contentType(MediaType.APPLICATION_JSON)
                .content(createRequestBody))
            .andExpect(status().isCreated())
            .andReturn()
            .getResponse()
            .getHeader("Location");

        String[] parts = locationHeader.split("/");
        String id = parts[parts.length - 1];

        // Update the category
        CategoryDTO updateDto = new CategoryDTO();
        updateDto.setCategoryName("Computer Science");
        updateDto.setStatus(true);

        String updateRequestBody = objectMapper.writeValueAsString(updateDto);

        mockMvc.perform(put(BASE_PATH + "/" + id)
                .contentType(MediaType.APPLICATION_JSON)
                .content(updateRequestBody))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status").value(200))
            .andExpect(jsonPath("$.message").value("success"))
            .andExpect(jsonPath("$.data[0].categoryName").value("Computer Science"));
    }

    @Test
    @DisplayName("PUT /categories/hexagonal/{id} with non-existent ID should return 404")
    void updateCategory_withNonExistentId_shouldReturn404() throws Exception {
        CategoryDTO updateDto = new CategoryDTO();
        updateDto.setCategoryName("New Name");
        updateDto.setStatus(true);

        String requestBody = objectMapper.writeValueAsString(updateDto);

        mockMvc.perform(put(BASE_PATH + "/99999")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBody))
            .andExpect(status().isNotFound())
            .andExpect(jsonPath("$.status").value(404))
            .andExpect(jsonPath("$.message").value("not-found"));
    }

    @Test
    @DisplayName("DELETE /categories/hexagonal/{id} should return 204")
    void deleteCategory_shouldMatchOpenAPIContract() throws Exception {
        // First create a category
        CategoryDTO createDto = new CategoryDTO();
        createDto.setCategoryName("Temporary");
        createDto.setStatus(true);

        String createRequestBody = objectMapper.writeValueAsString(createDto);
        String locationHeader = mockMvc.perform(post(BASE_PATH)
                .contentType(MediaType.APPLICATION_JSON)
                .content(createRequestBody))
            .andExpect(status().isCreated())
            .andReturn()
            .getResponse()
            .getHeader("Location");

        String[] parts = locationHeader.split("/");
        String id = parts[parts.length - 1];

        // Delete the category
        mockMvc.perform(delete(BASE_PATH + "/" + id))
            .andExpect(status().isNoContent());

        // Verify it's deleted
        mockMvc.perform(get(BASE_PATH + "/" + id))
            .andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("DELETE /categories/hexagonal/{id} with non-existent ID should return 404")
    void deleteCategory_withNonExistentId_shouldReturn404() throws Exception {
        mockMvc.perform(delete(BASE_PATH + "/99999"))
            .andExpect(status().isNotFound())
            .andExpect(jsonPath("$.status").value(404))
            .andExpect(jsonPath("$.message").value("not-found"));
    }

    @Test
    @DisplayName("Response should contain all required CategoryDTO fields")
    void response_shouldContainAllRequiredFields() throws Exception {
        CategoryDTO dto = new CategoryDTO();
        dto.setCategoryName("Biography");
        dto.setStatus(true);

        String requestBody = objectMapper.writeValueAsString(dto);
        String locationHeader = mockMvc.perform(post(BASE_PATH)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBody))
            .andExpect(status().isCreated())
            .andReturn()
            .getResponse()
            .getHeader("Location");

        String[] parts = locationHeader.split("/");
        String id = parts[parts.length - 1];

        mockMvc.perform(get(BASE_PATH + "/" + id))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.data[0].idCategory").exists())
            .andExpect(jsonPath("$.data[0].categoryName").exists())
            .andExpect(jsonPath("$.data[0].status").exists());
    }
}
