package com.mitocode.category.domain.port.in;

import com.mitocode.category.domain.model.entity.Category;

import java.util.List;
import java.util.Optional;

/**
 * Input Port (Use Case Interface) for finding categories.
 * Defines the contract for category retrieval operations.
 */
public interface FindCategoryUseCase {

    /**
     * Finds a category by its ID.
     *
     * @param id the category identifier
     * @return an Optional containing the category if found
     */
    Optional<Category> findById(Integer id);

    /**
     * Retrieves all categories.
     *
     * @return a list of all categories
     */
    List<Category> findAll();
}
