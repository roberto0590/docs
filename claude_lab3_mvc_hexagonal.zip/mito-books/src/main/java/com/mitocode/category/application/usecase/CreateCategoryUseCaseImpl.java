package com.mitocode.category.application.usecase;

import com.mitocode.category.domain.model.entity.Category;
import com.mitocode.category.domain.model.vo.CategoryName;
import com.mitocode.category.domain.port.in.CreateCategoryUseCase;
import com.mitocode.category.domain.port.out.CategoryRepositoryPort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Implementation of CreateCategoryUseCase.
 * Handles the business logic for creating a new category.
 */
@Service
@Transactional
public class CreateCategoryUseCaseImpl implements CreateCategoryUseCase {

    private final CategoryRepositoryPort categoryRepository;

    public CreateCategoryUseCaseImpl(CategoryRepositoryPort categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    @Override
    public Category create(CreateCategoryCommand command) {
        // Create domain value object
        CategoryName name = CategoryName.of(command.name());

        // Create domain entity
        Category category = Category.create(name);

        // Apply status if inactive
        if (!command.active()) {
            category.deactivate();
        }

        // Persist through repository port
        return categoryRepository.save(category);
    }
}
