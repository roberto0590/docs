package com.mitocode.category.domain.model.exception;

/**
 * Domain exception thrown when a category is not found.
 * Represents a business rule violation in the domain layer.
 */
public class CategoryNotFoundException extends RuntimeException {

    public CategoryNotFoundException(Integer id) {
        super("Category not found with id: " + id);
    }

    public CategoryNotFoundException(String message) {
        super(message);
    }
}
