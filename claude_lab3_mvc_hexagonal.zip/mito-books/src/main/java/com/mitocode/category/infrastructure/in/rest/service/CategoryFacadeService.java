package com.mitocode.category.infrastructure.in.rest.service;

import com.mitocode.category.domain.model.entity.Category;
import com.mitocode.category.domain.port.in.CreateCategoryUseCase;
import com.mitocode.category.domain.port.in.DeleteCategoryUseCase;
import com.mitocode.category.domain.port.in.FindCategoryUseCase;
import com.mitocode.category.domain.port.in.UpdateCategoryUseCase;
import com.mitocode.category.infrastructure.in.rest.dto.CategoryResponseDto;
import com.mitocode.category.infrastructure.in.rest.dto.CreateCategoryRequestDto;
import com.mitocode.category.infrastructure.in.rest.dto.UpdateCategoryRequestDto;
import com.mitocode.category.infrastructure.in.rest.mapper.CategoryWebMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Facade Service for Category operations.
 * Acts as an orchestration layer between the REST controller and use cases.
 * Responsibilities:
 * - Maps DTOs to Commands
 * - Invokes use cases
 * - Maps domain entities back to Response DTOs
 *
 * This facade simplifies the controller by encapsulating the mapping logic.
 */
@Service
public class CategoryFacadeService {

    private final CreateCategoryUseCase createCategoryUseCase;
    private final FindCategoryUseCase findCategoryUseCase;
    private final UpdateCategoryUseCase updateCategoryUseCase;
    private final DeleteCategoryUseCase deleteCategoryUseCase;
    private final CategoryWebMapper mapper;

    public CategoryFacadeService(
        CreateCategoryUseCase createCategoryUseCase,
        FindCategoryUseCase findCategoryUseCase,
        UpdateCategoryUseCase updateCategoryUseCase,
        DeleteCategoryUseCase deleteCategoryUseCase,
        CategoryWebMapper mapper
    ) {
        this.createCategoryUseCase = createCategoryUseCase;
        this.findCategoryUseCase = findCategoryUseCase;
        this.updateCategoryUseCase = updateCategoryUseCase;
        this.deleteCategoryUseCase = deleteCategoryUseCase;
        this.mapper = mapper;
    }

    /**
     * Creates a new category.
     *
     * @param requestDto the create category request DTO
     * @return the created category as response DTO
     */
    public CategoryResponseDto createCategory(CreateCategoryRequestDto requestDto) {
        // Map DTO to Command
        CreateCategoryUseCase.CreateCategoryCommand command = mapper.toCreateCommand(requestDto);

        // Execute use case
        Category category = createCategoryUseCase.create(command);

        // Map domain entity to Response DTO
        return mapper.toResponseDto(category);
    }

    /**
     * Finds a category by its ID.
     *
     * @param id the category identifier
     * @return an Optional containing the category response DTO if found
     */
    public Optional<CategoryResponseDto> findCategoryById(Integer id) {
        // Execute use case
        Optional<Category> category = findCategoryUseCase.findById(id);

        // Map domain entity to Response DTO
        return category.map(mapper::toResponseDto);
    }

    /**
     * Retrieves all categories.
     *
     * @return a list of category response DTOs
     */
    public List<CategoryResponseDto> findAllCategories() {
        // Execute use case
        List<Category> categories = findCategoryUseCase.findAll();

        // Map domain entities to Response DTOs
        return categories.stream()
            .map(mapper::toResponseDto)
            .toList();
    }

    /**
     * Updates an existing category.
     *
     * @param id the category identifier
     * @param requestDto the update category request DTO
     * @return the updated category as response DTO
     */
    public CategoryResponseDto updateCategory(Integer id, UpdateCategoryRequestDto requestDto) {
        // Map DTO to Command
        UpdateCategoryUseCase.UpdateCategoryCommand command = mapper.toUpdateCommand(id, requestDto);

        // Execute use case
        Category category = updateCategoryUseCase.update(command);

        // Map domain entity to Response DTO
        return mapper.toResponseDto(category);
    }

    /**
     * Deletes a category by its ID.
     *
     * @param id the category identifier
     */
    public void deleteCategory(Integer id) {
        // Execute use case
        deleteCategoryUseCase.deleteById(id);
    }
}
