package com.mitocode.category.infrastructure.in.rest.controller;

import com.mitocode.category.domain.model.exception.CategoryNotFoundException;
import com.mitocode.category.infrastructure.in.rest.api.CategoryAPI;
import com.mitocode.category.infrastructure.in.rest.dto.CategoryResponseDto;
import com.mitocode.category.infrastructure.in.rest.dto.CreateCategoryRequestDto;
import com.mitocode.category.infrastructure.in.rest.dto.UpdateCategoryRequestDto;
import com.mitocode.category.infrastructure.in.rest.service.CategoryFacadeService;
import com.mitocode.dto.GenericResponse;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

/**
 * REST Controller for Category operations.
 * Implements hexagonal architecture principles:
 * - Implements CategoryAPI interface (contract-first approach)
 * - Delegates to CategoryFacadeService (facade pattern)
 * - Minimal logic, focuses on HTTP concerns
 *
 * Flow: Request → Controller → Facade → Use Case → Domain
 */
@RestController
public class CategoryController implements CategoryAPI {

    private final CategoryFacadeService facadeService;

    public CategoryController(CategoryFacadeService facadeService) {
        this.facadeService = facadeService;
    }

    @Override
    public ResponseEntity<Void> createCategory(@Valid CreateCategoryRequestDto request) {
        CategoryResponseDto response = facadeService.createCategory(request);

        // Build Location header
        URI location = ServletUriComponentsBuilder
            .fromCurrentRequest()
            .path("/{id}")
            .buildAndExpand(response.idCategory())
            .toUri();

        return ResponseEntity.created(location).build();
    }

    @Override
    public ResponseEntity<GenericResponse<CategoryResponseDto>> getCategoryById(Integer id) {
        CategoryResponseDto response = facadeService.findCategoryById(id)
            .orElseThrow(() -> new CategoryNotFoundException(id));

        return ResponseEntity.ok(
            new GenericResponse<>(200, "success", List.of(response))
        );
    }

    @Override
    public ResponseEntity<GenericResponse<CategoryResponseDto>> getAllCategories() {
        List<CategoryResponseDto> response = facadeService.findAllCategories();

        return ResponseEntity.ok(
            new GenericResponse<>(200, "success", response)
        );
    }

    @Override
    public ResponseEntity<GenericResponse<CategoryResponseDto>> updateCategory(
        Integer id,
        @Valid UpdateCategoryRequestDto request
    ) {
        CategoryResponseDto response = facadeService.updateCategory(id, request);

        return ResponseEntity.ok(
            new GenericResponse<>(200, "success", List.of(response))
        );
    }

    @Override
    public ResponseEntity<Void> deleteCategory(Integer id) {
        facadeService.deleteCategory(id);
        return ResponseEntity.noContent().build();
    }
}
