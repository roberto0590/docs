package com.mitocode.category.application.usecase;

import com.mitocode.category.domain.model.exception.CategoryNotFoundException;
import com.mitocode.category.domain.model.vo.CategoryId;
import com.mitocode.category.domain.port.in.DeleteCategoryUseCase;
import com.mitocode.category.domain.port.out.CategoryRepositoryPort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Implementation of DeleteCategoryUseCase.
 * Handles the business logic for deleting a category.
 */
@Service
@Transactional
public class DeleteCategoryUseCaseImpl implements DeleteCategoryUseCase {

    private final CategoryRepositoryPort categoryRepository;

    public DeleteCategoryUseCaseImpl(CategoryRepositoryPort categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    @Override
    public void deleteById(Integer id) {
        CategoryId categoryId = CategoryId.of(id);

        // Verify category exists before deletion
        if (!categoryRepository.existsById(categoryId)) {
            throw new CategoryNotFoundException(id);
        }

        categoryRepository.deleteById(categoryId);
    }
}
