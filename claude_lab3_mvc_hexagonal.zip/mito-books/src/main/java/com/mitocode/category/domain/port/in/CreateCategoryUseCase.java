package com.mitocode.category.domain.port.in;

import com.mitocode.category.domain.model.entity.Category;

/**
 * Input Port (Use Case Interface) for creating a new category.
 * Defines the contract for the create category use case.
 */
public interface CreateCategoryUseCase {

    /**
     * Creates a new category.
     *
     * @param command the create category command
     * @return the created category
     */
    Category create(CreateCategoryCommand command);

    /**
     * Command for creating a category.
     */
    record CreateCategoryCommand(String name, boolean active) {}
}
