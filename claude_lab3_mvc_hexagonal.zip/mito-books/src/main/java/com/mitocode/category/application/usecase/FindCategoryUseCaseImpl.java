package com.mitocode.category.application.usecase;

import com.mitocode.category.domain.model.entity.Category;
import com.mitocode.category.domain.model.vo.CategoryId;
import com.mitocode.category.domain.port.in.FindCategoryUseCase;
import com.mitocode.category.domain.port.out.CategoryRepositoryPort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Implementation of FindCategoryUseCase.
 * Handles the business logic for retrieving categories.
 */
@Service
@Transactional(readOnly = true)
public class FindCategoryUseCaseImpl implements FindCategoryUseCase {

    private final CategoryRepositoryPort categoryRepository;

    public FindCategoryUseCaseImpl(CategoryRepositoryPort categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    @Override
    public Optional<Category> findById(Integer id) {
        CategoryId categoryId = CategoryId.of(id);
        return categoryRepository.findById(categoryId);
    }

    @Override
    public List<Category> findAll() {
        return categoryRepository.findAll();
    }
}
