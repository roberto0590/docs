package com.mitocode.category.infrastructure.in.rest.dto;

/**
 * Response DTO for category operations.
 * Represents the external API format for category data.
 */
public record CategoryResponseDto(
    Integer idCategory,
    String categoryName,
    boolean status
) {}
