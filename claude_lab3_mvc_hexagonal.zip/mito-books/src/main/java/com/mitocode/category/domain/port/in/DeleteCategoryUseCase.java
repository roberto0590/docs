package com.mitocode.category.domain.port.in;

/**
 * Input Port (Use Case Interface) for deleting a category.
 * Defines the contract for the delete category use case.
 */
public interface DeleteCategoryUseCase {

    /**
     * Deletes a category by its ID.
     *
     * @param id the category identifier
     */
    void deleteById(Integer id);
}
