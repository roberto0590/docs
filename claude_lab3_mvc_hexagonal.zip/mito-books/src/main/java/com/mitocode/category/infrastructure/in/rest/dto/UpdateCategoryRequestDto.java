package com.mitocode.category.infrastructure.in.rest.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * Request DTO for updating a category.
 * Uses Jakarta Bean Validation for input validation.
 */
public record UpdateCategoryRequestDto(
    @NotBlank(message = "Category name is required")
    @Size(max = 20, message = "Category name cannot exceed 20 characters")
    String categoryName,

    boolean status
) {}
