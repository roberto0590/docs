package com.mitocode.category.domain.model.vo;

/**
 * Value Object representing a Category identifier.
 * Ensures ID validity through encapsulation.
 */
public record CategoryId(Integer value) {

    public CategoryId {
        if (value == null) {
            throw new IllegalArgumentException("Category ID cannot be null");
        }
        if (value <= 0) {
            throw new IllegalArgumentException("Category ID must be positive");
        }
    }

    /**
     * Factory method for creating a CategoryId.
     *
     * @param value the integer value for the category ID
     * @return a new CategoryId instance
     * @throws IllegalArgumentException if value is null or non-positive
     */
    public static CategoryId of(Integer value) {
        return new CategoryId(value);
    }
}
