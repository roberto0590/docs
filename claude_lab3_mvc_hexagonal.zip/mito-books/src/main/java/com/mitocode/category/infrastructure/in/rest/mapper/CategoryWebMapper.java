package com.mitocode.category.infrastructure.in.rest.mapper;

import com.mitocode.category.domain.model.entity.Category;
import com.mitocode.category.domain.port.in.CreateCategoryUseCase;
import com.mitocode.category.domain.port.in.UpdateCategoryUseCase;
import com.mitocode.category.infrastructure.in.rest.dto.CategoryResponseDto;
import com.mitocode.category.infrastructure.in.rest.dto.CreateCategoryRequestDto;
import com.mitocode.category.infrastructure.in.rest.dto.UpdateCategoryRequestDto;
import org.springframework.stereotype.Component;

/**
 * Mapper between Web DTOs and Domain Commands/Entities.
 * Converts REST layer objects to/from domain layer objects.
 */
@Component
public class CategoryWebMapper {

    /**
     * Converts CreateCategoryRequestDto to CreateCategoryCommand.
     *
     * @param dto the request DTO
     * @return the domain command
     */
    public CreateCategoryUseCase.CreateCategoryCommand toCreateCommand(CreateCategoryRequestDto dto) {
        return new CreateCategoryUseCase.CreateCategoryCommand(
            dto.categoryName(),
            dto.status()
        );
    }

    /**
     * Converts UpdateCategoryRequestDto to UpdateCategoryCommand.
     *
     * @param id the category identifier
     * @param dto the request DTO
     * @return the domain command
     */
    public UpdateCategoryUseCase.UpdateCategoryCommand toUpdateCommand(Integer id, UpdateCategoryRequestDto dto) {
        return new UpdateCategoryUseCase.UpdateCategoryCommand(
            id,
            dto.categoryName(),
            dto.status()
        );
    }

    /**
     * Converts domain Category entity to CategoryResponseDto.
     *
     * @param category the domain entity
     * @return the response DTO
     */
    public CategoryResponseDto toResponseDto(Category category) {
        return new CategoryResponseDto(
            category.getId().value(),
            category.getName().value(),
            category.isActive()
        );
    }
}
