package com.mitocode.category.domain.model.entity;

import com.mitocode.category.domain.model.vo.CategoryId;
import com.mitocode.category.domain.model.vo.CategoryName;

import java.util.Objects;

/**
 * Category Aggregate Root.
 * Represents a book category in the domain with business behavior.
 * Enforces invariants and encapsulates business logic.
 */
public class Category {

    private CategoryId id;
    private CategoryName name;
    private boolean active;

    /**
     * Private constructor to enforce factory methods for object creation.
     *
     * @param id the category identifier (can be null for new categories)
     * @param name the category name (required)
     * @param active the active status
     */
    private Category(CategoryId id, CategoryName name, boolean active) {
        this.id = id;
        this.name = Objects.requireNonNull(name, "Category name is required");
        this.active = active;
    }

    /**
     * Factory method for creating a new Category (without ID).
     * Used when creating a new category before persistence.
     *
     * @param name the category name
     * @return a new Category instance with active status true
     */
    public static Category create(CategoryName name) {
        return new Category(null, name, true);
    }

    /**
     * Factory method for reconstituting a Category from persistence.
     * Used when loading an existing category from the database.
     *
     * @param id the category identifier
     * @param name the category name
     * @param active the active status
     * @return a Category instance with all fields populated
     */
    public static Category reconstitute(CategoryId id, CategoryName name, boolean active) {
        return new Category(
            Objects.requireNonNull(id, "ID is required for reconstitution"),
            name,
            active
        );
    }

    /**
     * Changes the category name.
     * Business rule: Cannot change name of an inactive category.
     *
     * @param newName the new category name
     * @throws IllegalStateException if category is inactive
     * @throws NullPointerException if newName is null
     */
    public void changeName(CategoryName newName) {
        if (!this.active) {
            throw new IllegalStateException("Cannot change name of inactive category");
        }
        this.name = Objects.requireNonNull(newName, "New name cannot be null");
    }

    /**
     * Activates the category.
     */
    public void activate() {
        this.active = true;
    }

    /**
     * Deactivates the category.
     */
    public void deactivate() {
        this.active = false;
    }

    /**
     * Sets the category ID (used after persistence).
     *
     * @param id the category identifier
     */
    public void setId(CategoryId id) {
        if (this.id != null) {
            throw new IllegalStateException("Cannot change existing category ID");
        }
        this.id = Objects.requireNonNull(id, "ID cannot be null");
    }

    // Getters only - no setters to maintain encapsulation

    public CategoryId getId() {
        return id;
    }

    public CategoryName getName() {
        return name;
    }

    public boolean isActive() {
        return active;
    }

    public boolean hasId() {
        return id != null;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Category category = (Category) o;
        return Objects.equals(id, category.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Category{" +
                "id=" + id +
                ", name=" + name +
                ", active=" + active +
                '}';
    }
}