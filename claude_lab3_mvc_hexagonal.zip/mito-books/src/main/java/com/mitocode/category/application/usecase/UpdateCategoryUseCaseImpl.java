package com.mitocode.category.application.usecase;

import com.mitocode.category.domain.model.entity.Category;
import com.mitocode.category.domain.model.exception.CategoryNotFoundException;
import com.mitocode.category.domain.model.vo.CategoryId;
import com.mitocode.category.domain.model.vo.CategoryName;
import com.mitocode.category.domain.port.in.UpdateCategoryUseCase;
import com.mitocode.category.domain.port.out.CategoryRepositoryPort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Implementation of UpdateCategoryUseCase.
 * Handles the business logic for updating an existing category.
 */
@Service
@Transactional
public class UpdateCategoryUseCaseImpl implements UpdateCategoryUseCase {

    private final CategoryRepositoryPort categoryRepository;

    public UpdateCategoryUseCaseImpl(CategoryRepositoryPort categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    @Override
    public Category update(UpdateCategoryCommand command) {
        CategoryId categoryId = CategoryId.of(command.id());

        // Retrieve existing category
        Category category = categoryRepository.findById(categoryId)
            .orElseThrow(() -> new CategoryNotFoundException(command.id()));

        // Update name through domain method
        CategoryName newName = CategoryName.of(command.name());

        // Handle status change before name change (activate if needed)
        if (command.active() && !category.isActive()) {
            category.activate();
        }

        // Change name (will throw exception if inactive)
        category.changeName(newName);

        // Deactivate if requested
        if (!command.active() && category.isActive()) {
            category.deactivate();
        }

        // Persist changes
        return categoryRepository.update(category);
    }
}
