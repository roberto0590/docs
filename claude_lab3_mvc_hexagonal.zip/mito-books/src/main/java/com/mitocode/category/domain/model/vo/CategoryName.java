package com.mitocode.category.domain.model.vo;

/**
 * Value Object representing a Category name.
 * Enforces business rules: non-null, non-empty, max 20 characters.
 */
public record CategoryName(String value) {

    private static final int MAX_LENGTH = 20;

    public CategoryName {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Category name cannot be null or empty");
        }

        String trimmed = value.trim();
        if (trimmed.length() > MAX_LENGTH) {
            throw new IllegalArgumentException(
                String.format("Category name cannot exceed %d characters", MAX_LENGTH)
            );
        }

        // Normalize the value by trimming whitespace
        value = trimmed;
    }

    /**
     * Factory method for creating a CategoryName.
     *
     * @param value the string value for the category name
     * @return a new CategoryName instance
     * @throws IllegalArgumentException if value is null, empty, or exceeds max length
     */
    public static CategoryName of(String value) {
        return new CategoryName(value);
    }
}
