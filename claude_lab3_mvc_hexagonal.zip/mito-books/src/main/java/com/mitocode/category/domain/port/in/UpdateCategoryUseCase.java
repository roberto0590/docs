package com.mitocode.category.domain.port.in;

import com.mitocode.category.domain.model.entity.Category;

/**
 * Input Port (Use Case Interface) for updating an existing category.
 * Defines the contract for the update category use case.
 */
public interface UpdateCategoryUseCase {

    /**
     * Updates an existing category.
     *
     * @param command the update category command
     * @return the updated category
     */
    Category update(UpdateCategoryCommand command);

    /**
     * Command for updating a category.
     */
    record UpdateCategoryCommand(Integer id, String name, boolean active) {}
}
