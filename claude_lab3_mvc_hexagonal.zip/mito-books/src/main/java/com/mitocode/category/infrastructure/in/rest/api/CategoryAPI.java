package com.mitocode.category.infrastructure.in.rest.api;

import com.mitocode.category.infrastructure.in.rest.dto.CategoryResponseDto;
import com.mitocode.category.infrastructure.in.rest.dto.CreateCategoryRequestDto;
import com.mitocode.category.infrastructure.in.rest.dto.UpdateCategoryRequestDto;
import com.mitocode.dto.GenericResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * API Interface for Category operations.
 * Defines the REST contract with OpenAPI documentation for Scalar.
 * This interface decouples the API contract from the implementation.
 */
@Tag(name = "Categories", description = "API for managing book categories")
@RequestMapping("/api/categories")
public interface CategoryAPI {

    @Operation(
        summary = "Create a new category",
        description = "Creates a new category with the provided information"
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "201",
            description = "Category created successfully",
            content = @Content(schema = @Schema(implementation = Void.class))
        ),
        @ApiResponse(
            responseCode = "400",
            description = "Invalid input data"
        ),
        @ApiResponse(
            responseCode = "500",
            description = "Internal server error"
        )
    })
    @PostMapping
    ResponseEntity<Void> createCategory(
        @Valid @RequestBody CreateCategoryRequestDto request
    );

    @Operation(
        summary = "Get category by ID",
        description = "Retrieves a category by its unique identifier"
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Category found",
            content = @Content(schema = @Schema(implementation = GenericResponse.class))
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Category not found"
        ),
        @ApiResponse(
            responseCode = "500",
            description = "Internal server error"
        )
    })
    @GetMapping("/{id}")
    ResponseEntity<GenericResponse<CategoryResponseDto>> getCategoryById(
        @Parameter(description = "Category ID", required = true)
        @PathVariable Integer id
    );

    @Operation(
        summary = "Get all categories",
        description = "Retrieves a list of all categories"
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Categories retrieved successfully",
            content = @Content(schema = @Schema(implementation = GenericResponse.class))
        ),
        @ApiResponse(
            responseCode = "500",
            description = "Internal server error"
        )
    })
    @GetMapping
    ResponseEntity<GenericResponse<CategoryResponseDto>> getAllCategories();

    @Operation(
        summary = "Update an existing category",
        description = "Updates a category with the provided information"
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Category updated successfully",
            content = @Content(schema = @Schema(implementation = GenericResponse.class))
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Category not found"
        ),
        @ApiResponse(
            responseCode = "400",
            description = "Invalid input data"
        ),
        @ApiResponse(
            responseCode = "500",
            description = "Internal server error"
        )
    })
    @PutMapping("/{id}")
    ResponseEntity<GenericResponse<CategoryResponseDto>> updateCategory(
        @Parameter(description = "Category ID", required = true)
        @PathVariable Integer id,
        @Valid @RequestBody UpdateCategoryRequestDto request
    );

    @Operation(
        summary = "Delete a category",
        description = "Deletes a category by its unique identifier"
    )
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "204",
            description = "Category deleted successfully"
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Category not found"
        ),
        @ApiResponse(
            responseCode = "500",
            description = "Internal server error"
        )
    })
    @DeleteMapping("/{id}")
    ResponseEntity<Void> deleteCategory(
        @Parameter(description = "Category ID", required = true)
        @PathVariable Integer id
    );
}
