package com.mitocode.api;

import com.mitocode.dto.CategoryDTO;
import com.mitocode.dto.GenericResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Categories", description = "Category management APIs")
public interface CategoryAPI {

    @Operation(summary = "Get all categories")
    @GetMapping
    ResponseEntity<GenericResponse<CategoryDTO>> getAllCategories();

    @Operation(summary = "Get category by ID")
    @GetMapping("/{id}")
    ResponseEntity<GenericResponse<CategoryDTO>> getCategoryById(@PathVariable("id") Integer id);

    @Operation(summary = "Create a new category")
    @PostMapping
    ResponseEntity<Void> save(@Valid @RequestBody CategoryDTO dto);

    @Operation(summary = "Update a category")
    @PutMapping("/{id}")
    ResponseEntity<GenericResponse<CategoryDTO>> update(@PathVariable("id") Integer id, @Valid @RequestBody CategoryDTO dto);

    @Operation(summary = "Delete a category")
    @DeleteMapping("/{id}")
    ResponseEntity<Void> delete(@PathVariable("id") Integer id);
}
