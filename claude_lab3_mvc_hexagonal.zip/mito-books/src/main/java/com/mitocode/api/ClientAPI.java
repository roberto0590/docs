package com.mitocode.api;

import com.mitocode.dto.ClientDTO;
import com.mitocode.dto.GenericResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Clients", description = "Client management APIs")
public interface ClientAPI {

    @Operation(summary = "Get all clients")
    @GetMapping
    ResponseEntity<GenericResponse<ClientDTO>> getAllClients();

    @Operation(summary = "Get client by ID")
    @GetMapping("/{id}")
    ResponseEntity<GenericResponse<ClientDTO>> getClientById(@PathVariable("id") Integer id);

    @Operation(summary = "Create a new client")
    @PostMapping
    ResponseEntity<Void> save(@Valid @RequestBody ClientDTO dto);

    @Operation(summary = "Update a client")
    @PutMapping("/{id}")
    ResponseEntity<GenericResponse<ClientDTO>> update(@PathVariable("id") Integer id, @Valid @RequestBody ClientDTO dto);

    @Operation(summary = "Delete a client")
    @DeleteMapping("/{id}")
    ResponseEntity<Void> delete(@PathVariable("id") Integer id);
}
