package com.mitocode.api;

import com.mitocode.dto.BookDTO;
import com.mitocode.dto.GenericResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Books", description = "Book management APIs")
public interface BookAPI {

    @Operation(summary = "Get all books")
    @GetMapping
    ResponseEntity<GenericResponse<BookDTO>> getAllBooks();

    @Operation(summary = "Get book by ID")
    @GetMapping("/{id}")
    ResponseEntity<GenericResponse<BookDTO>> getBookById(@PathVariable("id") Integer id);

    @Operation(summary = "Create a new book")
    @PostMapping
    ResponseEntity<Void> save(@Valid @RequestBody BookDTO dto);

    @Operation(summary = "Update a book")
    @PutMapping("/{id}")
    ResponseEntity<GenericResponse<BookDTO>> update(@PathVariable("id") Integer id, @Valid @RequestBody BookDTO dto);

    @Operation(summary = "Delete a book")
    @DeleteMapping("/{id}")
    ResponseEntity<Void> delete(@PathVariable("id") Integer id);

    @Operation(summary = "Get books by category")
    @GetMapping("/category")
    ResponseEntity<GenericResponse<BookDTO>> getBooksByCategory(@RequestParam("category") String category);
}
