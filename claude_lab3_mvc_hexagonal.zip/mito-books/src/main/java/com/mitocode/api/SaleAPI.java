package com.mitocode.api;

import com.mitocode.dto.GenericResponse;
import com.mitocode.dto.SaleDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Sales", description = "Sale management APIs")
public interface SaleAPI {

    @Operation(summary = "Get all sales")
    @GetMapping
    ResponseEntity<GenericResponse<SaleDTO>> getAllSales();

    @Operation(summary = "Get sale by ID")
    @GetMapping("/{id}")
    ResponseEntity<GenericResponse<SaleDTO>> getSaleById(@PathVariable("id") Integer id);

    @Operation(summary = "Create a new sale")
    @PostMapping
    ResponseEntity<Void> save(@Valid @RequestBody SaleDTO dto);

    @Operation(summary = "Update a sale")
    @PutMapping("/{id}")
    ResponseEntity<GenericResponse<SaleDTO>> update(@PathVariable("id") Integer id, @Valid @RequestBody SaleDTO dto);

    @Operation(summary = "Delete a sale")
    @DeleteMapping("/{id}")
    ResponseEntity<Void> delete(@PathVariable("id") Integer id);
}
