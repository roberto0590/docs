# Blueprint de Migraci�n a Arquitectura Hexagonal
## M�dulo: Categories (Ejemplo Completo y Replicable)

**Proyecto**: MitoBooks
**Fecha**: 2025-10-13
**Objetivo**: Migrar de MVC tradicional a Hexagonal manteniendo 100% compatibilidad API
**M�dulo Ejemplo**: Categories (el m�s simple, sin dependencias)

---

## �ndice

1. [Estructura de Directorios](#estructura)
2. [CAPA 1: Dominio](#capa-dominio)
3. [CAPA 2: Aplicaci�n](#capa-aplicacion)
4. [CAPA 3: Infraestructura](#capa-infraestructura)
5. [Tests](#tests)
6. [Validaci�n](#validacion)
7. [Replicar a Otros M�dulos](#replicar)

---

<a name="estructura"></a>
## 1. Estructura de Directorios

### Comando para crear estructura

```bash
mkdir -p src/main/java/com/mitocode/domain/category
mkdir -p src/main/java/com/mitocode/application/category/{dto,usecase,port}
mkdir -p src/main/java/com/mitocode/infrastructure/category/{adapter,mapper,entity}
```

### Estructura resultante

```
src/main/java/com/mitocode/
   domain/
      category/
          Category.java           # Aggregate Root (dominio puro)
          CategoryId.java         # Value Object para ID
          CategoryName.java       # Value Object para nombre
          CategoryRepository.java # Puerto (interface)

   application/
      category/
          dto/
             CreateCategoryRequest.java
             UpdateCategoryRequest.java
             CategoryResponse.java
          usecase/
             CreateCategoryUseCase.java
             GetAllCategoriesUseCase.java
             GetCategoryByIdUseCase.java
             UpdateCategoryUseCase.java
             DeleteCategoryUseCase.java
          port/
              CategoryApplicationService.java (opcional)

   infrastructure/
       category/
           adapter/
              CategoryController.java      # Adapter HTTP (REST)
              JpaCategoryRepositoryAdapter.java # Adapter DB (JPA)
           mapper/
              CategoryMapper.java
           entity/
               CategoryJpaEntity.java       # Entity de JPA
```

---

<a name="capa-dominio"></a>
## 2. CAPA 1: Dominio (Domain Layer)

### Principios de esta capa:
-  **Sin dependencias externas** (ni Spring, ni JPA, ni nada)
-  **L�gica de negocio pura**
-  **F�cilmente testeable** (unit tests sin mocks)
-  **Entities + Value Objects + Ports**

---

### 2.1. CategoryId.java (Value Object)

**Path**: `src/main/java/com/mitocode/domain/category/CategoryId.java`

```java
package com.mitocode.domain.category;

import java.util.Objects;

/**
 * Value Object representing a Category's unique identifier.
 * Immutable and validates business rules for IDs.
 */
public record CategoryId(Integer value) {

    public CategoryId {
        if (value == null) {
            throw new IllegalArgumentException("Category ID cannot be null");
        }
        if (value <= 0) {
            throw new IllegalArgumentException("Category ID must be positive");
        }
    }

    public static CategoryId of(Integer value) {
        return new CategoryId(value);
    }

    public static CategoryId from(String value) {
        try {
            return new CategoryId(Integer.parseInt(value));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid Category ID format: " + value);
        }
    }
}
```

**Reglas de negocio**:
-  ID no puede ser null
-  ID debe ser positivo
-  Inmutable (record)

---

### 2.2. CategoryName.java (Value Object)

**Path**: `src/main/java/com/mitocode/domain/category/CategoryName.java`

```java
package com.mitocode.domain.category;

import java.util.Objects;

/**
 * Value Object representing a Category's name.
 * Enforces business rules: not null, max 20 characters, trimmed.
 */
public record CategoryName(String value) {

    private static final int MAX_LENGTH = 20;

    public CategoryName {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Category name cannot be null or empty");
        }

        String trimmed = value.trim();
        if (trimmed.length() > MAX_LENGTH) {
            throw new IllegalArgumentException(
                "Category name cannot exceed " + MAX_LENGTH + " characters"
            );
        }

        // Normalizar: trimmed
        value = trimmed;
    }

    public static CategoryName of(String value) {
        return new CategoryName(value);
    }
}
```

**Reglas de negocio**:
-  Nombre no puede ser null/empty
-  M�ximo 20 caracteres
-  Se normaliza (trim)

---

### 2.3. Category.java (Aggregate Root)

**Path**: `src/main/java/com/mitocode/domain/category/Category.java`

```java
package com.mitocode.domain.category;

import java.util.Objects;

/**
 * Category Aggregate Root.
 * Representa una categor�a de libros con todas sus reglas de negocio.
 */
public class Category {

    private CategoryId id;
    private CategoryName name;
    private boolean active;

    // Constructor privado para forzar uso de factory methods
    private Category(CategoryId id, CategoryName name, boolean active) {
        this.id = id;
        this.name = Objects.requireNonNull(name, "Category name is required");
        this.active = active;
    }

    // Factory method: Crear nueva categor�a (sin ID a�n)
    public static Category create(CategoryName name) {
        return new Category(null, name, true);
    }

    // Factory method: Reconstruir desde persistencia
    public static Category reconstitute(CategoryId id, CategoryName name, boolean active) {
        return new Category(id, name, active);
    }

    // M�todos de dominio

    public void changeName(CategoryName newName) {
        if (!this.active) {
            throw new IllegalStateException("Cannot change name of inactive category");
        }
        this.name = Objects.requireNonNull(newName, "New name cannot be null");
    }

    public void activate() {
        this.active = true;
    }

    public void deactivate() {
        this.active = false;
    }

    public boolean isActive() {
        return active;
    }

    public boolean hasId() {
        return id != null;
    }

    // Getters (sin setters - inmutabilidad controlada)

    public CategoryId getId() {
        return id;
    }

    public CategoryName getName() {
        return name;
    }

    // Para uso interno del repository al persistir
    void assignId(CategoryId id) {
        if (this.id != null) {
            throw new IllegalStateException("Category already has an ID");
        }
        this.id = Objects.requireNonNull(id, "ID cannot be null");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Category category)) return false;
        return Objects.equals(id, category.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Category{" +
                "id=" + id +
                ", name=" + name +
                ", active=" + active +
                '}';
    }
}
```

**Caracter�sticas clave**:
-  Sin anotaciones de infraestructura (ni @Entity, ni Spring)
-  Factory methods para creaci�n controlada
-  M�todos de dominio con reglas de negocio
-  Inmutabilidad controlada (sin setters p�blicos)
-  Validaciones en cada operaci�n

---

### 2.4. CategoryRepository.java (Port - Interface)

**Path**: `src/main/java/com/mitocode/domain/category/CategoryRepository.java`

```java
package com.mitocode.domain.category;

import java.util.List;
import java.util.Optional;

/**
 * Port (interface) for Category persistence.
 * Define el contrato que la infraestructura debe implementar.
 * NO tiene dependencias de frameworks (ni JPA, ni Spring).
 */
public interface CategoryRepository {

    /**
     * Persiste una nueva categor�a y retorna la categor�a con su ID asignado.
     */
    Category save(Category category);

    /**
     * Actualiza una categor�a existente.
     */
    Category update(Category category);

    /**
     * Busca una categor�a por su ID.
     * @return Optional vac�o si no existe
     */
    Optional<Category> findById(CategoryId id);

    /**
     * Obtiene todas las categor�as.
     */
    List<Category> findAll();

    /**
     * Elimina una categor�a por su ID.
     */
    void deleteById(CategoryId id);

    /**
     * Verifica si existe una categor�a con el ID dado.
     */
    boolean existsById(CategoryId id);
}
```

**Caracter�sticas del puerto**:
-  Interface pura (contrato)
-  Usa tipos de dominio (CategoryId, Category)
-  Sin anotaciones de Spring/JPA
-  La infraestructura implementar� este contrato

---

<a name="capa-aplicacion"></a>
## 3. CAPA 2: Aplicaci�n (Application Layer)

### Principios:
-  **Orquesta** use cases
-  **No contiene l�gica de negocio** (esa est� en dominio)
-  **Traduce** entre DTOs y dominio
-  **Transaccionalidad** (@Transactional aqu�)

---

### 3.1. DTOs

#### CreateCategoryRequest.java

**Path**: `src/main/java/com/mitocode/application/category/dto/CreateCategoryRequest.java`

```java
package com.mitocode.application.category.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * Request DTO for creating a category.
 * Validaciones de entrada HTTP, no reglas de dominio.
 */
public record CreateCategoryRequest(

    @NotBlank(message = "Category name is required")
    @Size(max = 20, message = "Category name cannot exceed 20 characters")
    String categoryName,

    boolean status
) {
}
```

#### UpdateCategoryRequest.java

**Path**: `src/main/java/com/mitocode/application/category/dto/UpdateCategoryRequest.java`

```java
package com.mitocode.application.category.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record UpdateCategoryRequest(

    @NotBlank(message = "Category name is required")
    @Size(max = 20, message = "Category name cannot exceed 20 characters")
    String categoryName,

    boolean status
) {
}
```

#### CategoryResponse.java

**Path**: `src/main/java/com/mitocode/application/category/dto/CategoryResponse.java`

```java
package com.mitocode.application.category.dto;

/**
 * Response DTO for category data.
 * Matches the API contract (OpenAPI spec).
 */
public record CategoryResponse(
    Integer idCategory,
    String categoryName,
    boolean status
) {

    public static CategoryResponse from(
        com.mitocode.domain.category.Category category
    ) {
        return new CategoryResponse(
            category.getId().value(),
            category.getName().value(),
            category.isActive()
        );
    }
}
```

---

### 3.2. Use Cases

#### CreateCategoryUseCase.java

**Path**: `src/main/java/com/mitocode/application/category/usecase/CreateCategoryUseCase.java`

```java
package com.mitocode.application.category.usecase;

import com.mitocode.application.category.dto.CreateCategoryRequest;
import com.mitocode.application.category.dto.CategoryResponse;
import com.mitocode.domain.category.Category;
import com.mitocode.domain.category.CategoryName;
import com.mitocode.domain.category.CategoryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Use Case: Create a new category.
 * Orchestrates domain logic and persistence.
 */
@Service
@Transactional
public class CreateCategoryUseCase {

    private final CategoryRepository categoryRepository;

    public CreateCategoryUseCase(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    public CategoryResponse execute(CreateCategoryRequest request) {
        // 1. Crear Value Object desde request
        CategoryName name = CategoryName.of(request.categoryName());

        // 2. Crear entidad de dominio
        Category category = Category.create(name);

        // 3. Aplicar estado si es false (por defecto es true)
        if (!request.status()) {
            category.deactivate();
        }

        // 4. Persistir
        Category savedCategory = categoryRepository.save(category);

        // 5. Convertir a response DTO
        return CategoryResponse.from(savedCategory);
    }
}
```

#### GetAllCategoriesUseCase.java

**Path**: `src/main/java/com/mitocode/application/category/usecase/GetAllCategoriesUseCase.java`

```java
package com.mitocode.application.category.usecase;

import com.mitocode.application.category.dto.CategoryResponse;
import com.mitocode.domain.category.CategoryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(readOnly = true)
public class GetAllCategoriesUseCase {

    private final CategoryRepository categoryRepository;

    public GetAllCategoriesUseCase(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    public List<CategoryResponse> execute() {
        return categoryRepository.findAll()
            .stream()
            .map(CategoryResponse::from)
            .toList();
    }
}
```

#### GetCategoryByIdUseCase.java

**Path**: `src/main/java/com/mitocode/application/category/usecase/GetCategoryByIdUseCase.java`

```java
package com.mitocode.application.category.usecase;

import com.mitocode.application.category.dto.CategoryResponse;
import com.mitocode.domain.category.Category;
import com.mitocode.domain.category.CategoryId;
import com.mitocode.domain.category.CategoryRepository;
import com.mitocode.exception.ModelNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true)
public class GetCategoryByIdUseCase {

    private final CategoryRepository categoryRepository;

    public GetCategoryByIdUseCase(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    public CategoryResponse execute(Integer id) {
        CategoryId categoryId = CategoryId.of(id);

        Category category = categoryRepository.findById(categoryId)
            .orElseThrow(() -> new ModelNotFoundException(
                "Category with ID " + id + " not found"
            ));

        return CategoryResponse.from(category);
    }
}
```

#### UpdateCategoryUseCase.java

**Path**: `src/main/java/com/mitocode/application/category/usecase/UpdateCategoryUseCase.java`

```java
package com.mitocode.application.category.usecase;

import com.mitocode.application.category.dto.UpdateCategoryRequest;
import com.mitocode.application.category.dto.CategoryResponse;
import com.mitocode.domain.category.Category;
import com.mitocode.domain.category.CategoryId;
import com.mitocode.domain.category.CategoryName;
import com.mitocode.domain.category.CategoryRepository;
import com.mitocode.exception.ModelNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class UpdateCategoryUseCase {

    private final CategoryRepository categoryRepository;

    public UpdateCategoryUseCase(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    public CategoryResponse execute(Integer id, UpdateCategoryRequest request) {
        // 1. Buscar categor�a existente
        CategoryId categoryId = CategoryId.of(id);
        Category category = categoryRepository.findById(categoryId)
            .orElseThrow(() -> new ModelNotFoundException(
                "Category with ID " + id + " not found"
            ));

        // 2. Aplicar cambios usando m�todos de dominio
        CategoryName newName = CategoryName.of(request.categoryName());
        category.changeName(newName);

        if (request.status()) {
            category.activate();
        } else {
            category.deactivate();
        }

        // 3. Persistir cambios
        Category updatedCategory = categoryRepository.update(category);

        // 4. Retornar response
        return CategoryResponse.from(updatedCategory);
    }
}
```

#### DeleteCategoryUseCase.java

**Path**: `src/main/java/com/mitocode/application/category/usecase/DeleteCategoryUseCase.java`

```java
package com.mitocode.application.category.usecase;

import com.mitocode.domain.category.CategoryId;
import com.mitocode.domain.category.CategoryRepository;
import com.mitocode.exception.ModelNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class DeleteCategoryUseCase {

    private final CategoryRepository categoryRepository;

    public DeleteCategoryUseCase(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    public void execute(Integer id) {
        CategoryId categoryId = CategoryId.of(id);

        // Validar que existe antes de borrar
        if (!categoryRepository.existsById(categoryId)) {
            throw new ModelNotFoundException(
                "Category with ID " + id + " not found"
            );
        }

        categoryRepository.deleteById(categoryId);
    }
}
```

---

<a name="capa-infraestructura"></a>
## 4. CAPA 3: Infraestructura (Infrastructure Layer)

### Principios:
-  **Implementa los puertos** (interfaces) del dominio
-  **Depende del dominio**, nunca al rev�s
-  **Frameworks aqu�** (Spring, JPA, etc.)
-  **Adapters** para cada tecnolog�a

---

### 4.1. CategoryJpaEntity.java

**Path**: `src/main/java/com/mitocode/infrastructure/category/entity/CategoryJpaEntity.java`

```java
package com.mitocode.infrastructure.category.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * JPA Entity for Category persistence.
 * SOLO para mapeo ORM, NO es el modelo de dominio.
 */
@Entity
@Table(name = "category")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CategoryJpaEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idCategory;

    @Column(nullable = false, length = 20)
    private String name;

    @Column(nullable = false)
    private boolean status;
}
```

---

### 4.2. CategoryMapper.java

**Path**: `src/main/java/com/mitocode/infrastructure/category/mapper/CategoryMapper.java`

```java
package com.mitocode.infrastructure.category.mapper;

import com.mitocode.domain.category.Category;
import com.mitocode.domain.category.CategoryId;
import com.mitocode.domain.category.CategoryName;
import com.mitocode.infrastructure.category.entity.CategoryJpaEntity;
import org.springframework.stereotype.Component;

/**
 * Mapper between Domain model and JPA entity.
 * A�sla el dominio de la infraestructura.
 */
@Component
public class CategoryMapper {

    /**
     * Convierte de entidad de dominio a entidad JPA.
     */
    public CategoryJpaEntity toJpaEntity(Category category) {
        return new CategoryJpaEntity(
            category.hasId() ? category.getId().value() : null,
            category.getName().value(),
            category.isActive()
        );
    }

    /**
     * Convierte de entidad JPA a entidad de dominio.
     */
    public Category toDomain(CategoryJpaEntity entity) {
        CategoryId id = CategoryId.of(entity.getIdCategory());
        CategoryName name = CategoryName.of(entity.getName());

        return Category.reconstitute(id, name, entity.isStatus());
    }
}
```

---

### 4.3. JpaCategoryRepositoryAdapter.java

**Path**: `src/main/java/com/mitocode/infrastructure/category/adapter/JpaCategoryRepositoryAdapter.java`

```java
package com.mitocode.infrastructure.category.adapter;

import com.mitocode.domain.category.Category;
import com.mitocode.domain.category.CategoryId;
import com.mitocode.domain.category.CategoryRepository;
import com.mitocode.infrastructure.category.entity.CategoryJpaEntity;
import com.mitocode.infrastructure.category.mapper.CategoryMapper;
import com.mitocode.repo.ICategoryRepo;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Adapter que implementa el puerto CategoryRepository usando JPA.
 * Traduce entre el modelo de dominio y la persistencia JPA.
 */
@Repository
public class JpaCategoryRepositoryAdapter implements CategoryRepository {

    private final ICategoryRepo jpaCategoryRepo;
    private final CategoryMapper mapper;

    public JpaCategoryRepositoryAdapter(
        ICategoryRepo jpaCategoryRepo,
        CategoryMapper mapper
    ) {
        this.jpaCategoryRepo = jpaCategoryRepo;
        this.mapper = mapper;
    }

    @Override
    public Category save(Category category) {
        CategoryJpaEntity entity = mapper.toJpaEntity(category);
        CategoryJpaEntity saved = jpaCategoryRepo.save(entity);
        return mapper.toDomain(saved);
    }

    @Override
    public Category update(Category category) {
        // En JPA, save() hace update si tiene ID
        CategoryJpaEntity entity = mapper.toJpaEntity(category);
        CategoryJpaEntity updated = jpaCategoryRepo.save(entity);
        return mapper.toDomain(updated);
    }

    @Override
    public Optional<Category> findById(CategoryId id) {
        return jpaCategoryRepo.findById(id.value())
            .map(mapper::toDomain);
    }

    @Override
    public List<Category> findAll() {
        return jpaCategoryRepo.findAll()
            .stream()
            .map(mapper::toDomain)
            .toList();
    }

    @Override
    public void deleteById(CategoryId id) {
        jpaCategoryRepo.deleteById(id.value());
    }

    @Override
    public boolean existsById(CategoryId id) {
        return jpaCategoryRepo.existsById(id.value());
    }
}
```

---

### 4.4. CategoryController.java (Adapter HTTP)

**Path**: `src/main/java/com/mitocode/infrastructure/category/adapter/CategoryController.java`

```java
package com.mitocode.infrastructure.category.adapter;

import com.mitocode.api.CategoryAPI;
import com.mitocode.application.category.dto.CategoryResponse;
import com.mitocode.application.category.dto.CreateCategoryRequest;
import com.mitocode.application.category.dto.UpdateCategoryRequest;
import com.mitocode.application.category.usecase.*;
import com.mitocode.dto.CategoryDTO;
import com.mitocode.dto.GenericResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.Arrays;
import java.util.List;

/**
 * HTTP Adapter (Controller) for Category endpoints.
 * Implements the CategoryAPI contract (OpenAPI documentation).
 * Delegates to Use Cases (application layer).
 */
@RestController
@RequestMapping("/categories")
public class CategoryController implements CategoryAPI {

    private final CreateCategoryUseCase createCategoryUseCase;
    private final GetAllCategoriesUseCase getAllCategoriesUseCase;
    private final GetCategoryByIdUseCase getCategoryByIdUseCase;
    private final UpdateCategoryUseCase updateCategoryUseCase;
    private final DeleteCategoryUseCase deleteCategoryUseCase;

    public CategoryController(
        CreateCategoryUseCase createCategoryUseCase,
        GetAllCategoriesUseCase getAllCategoriesUseCase,
        GetCategoryByIdUseCase getCategoryByIdUseCase,
        UpdateCategoryUseCase updateCategoryUseCase,
        DeleteCategoryUseCase deleteCategoryUseCase
    ) {
        this.createCategoryUseCase = createCategoryUseCase;
        this.getAllCategoriesUseCase = getAllCategoriesUseCase;
        this.getCategoryByIdUseCase = getCategoryByIdUseCase;
        this.updateCategoryUseCase = updateCategoryUseCase;
        this.deleteCategoryUseCase = deleteCategoryUseCase;
    }

    @Override
    public ResponseEntity<GenericResponse<CategoryDTO>> getAllCategories() {
        List<CategoryResponse> categories = getAllCategoriesUseCase.execute();

        // Convertir CategoryResponse � CategoryDTO (para mantener contrato API)
        List<CategoryDTO> dtos = categories.stream()
            .map(r -> new CategoryDTO(r.idCategory(), r.categoryName(), r.status()))
            .toList();

        return ResponseEntity.ok(new GenericResponse<>(200, "success", dtos));
    }

    @Override
    public ResponseEntity<GenericResponse<CategoryDTO>> getCategoryById(Integer id) {
        CategoryResponse category = getCategoryByIdUseCase.execute(id);

        CategoryDTO dto = new CategoryDTO(
            category.idCategory(),
            category.categoryName(),
            category.status()
        );

        return ResponseEntity.ok(
            new GenericResponse<>(200, "success", Arrays.asList(dto))
        );
    }

    @Override
    public ResponseEntity<Void> save(CategoryDTO dto) {
        // Convertir CategoryDTO � CreateCategoryRequest
        CreateCategoryRequest request = new CreateCategoryRequest(
            dto.categoryName(),
            dto.status()
        );

        CategoryResponse created = createCategoryUseCase.execute(request);

        URI location = ServletUriComponentsBuilder
            .fromCurrentRequest()
            .path("/{id}")
            .buildAndExpand(created.idCategory())
            .toUri();

        return ResponseEntity.created(location).build();
    }

    @Override
    public ResponseEntity<GenericResponse<CategoryDTO>> update(
        Integer id,
        CategoryDTO dto
    ) {
        // Convertir CategoryDTO � UpdateCategoryRequest
        UpdateCategoryRequest request = new UpdateCategoryRequest(
            dto.categoryName(),
            dto.status()
        );

        CategoryResponse updated = updateCategoryUseCase.execute(id, request);

        CategoryDTO responseDto = new CategoryDTO(
            updated.idCategory(),
            updated.categoryName(),
            updated.status()
        );

        return ResponseEntity.ok(
            new GenericResponse<>(200, "success", Arrays.asList(responseDto))
        );
    }

    @Override
    public ResponseEntity<Void> delete(Integer id) {
        deleteCategoryUseCase.execute(id);
        return ResponseEntity.noContent().build();
    }
}
```

---

<a name="tests"></a>
## 5. Tests

### 5.1. Tests de Dominio (Unit Tests)

**Path**: `src/test/java/com/mitocode/domain/category/CategoryTest.java`

```java
package com.mitocode.domain.category;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CategoryTest {

    @Test
    void shouldCreateCategoryWithValidName() {
        // Given
        CategoryName name = CategoryName.of("Fiction");

        // When
        Category category = Category.create(name);

        // Then
        assertNotNull(category);
        assertEquals("Fiction", category.getName().value());
        assertTrue(category.isActive());
        assertFalse(category.hasId());
    }

    @Test
    void shouldChangeNameWhenActive() {
        // Given
        Category category = Category.create(CategoryName.of("Fiction"));
        CategoryName newName = CategoryName.of("Science Fiction");

        // When
        category.changeName(newName);

        // Then
        assertEquals("Science Fiction", category.getName().value());
    }

    @Test
    void shouldThrowExceptionWhenChangingNameOfInactiveCategory() {
        // Given
        Category category = Category.create(CategoryName.of("Fiction"));
        category.deactivate();

        // When & Then
        assertThrows(IllegalStateException.class, () -> {
            category.changeName(CategoryName.of("New Name"));
        });
    }

    @Test
    void shouldRejectNullName() {
        assertThrows(IllegalArgumentException.class, () -> {
            CategoryName.of(null);
        });
    }

    @Test
    void shouldRejectEmptyName() {
        assertThrows(IllegalArgumentException.class, () -> {
            CategoryName.of("   ");
        });
    }

    @Test
    void shouldRejectNameExceeding20Characters() {
        assertThrows(IllegalArgumentException.class, () -> {
            CategoryName.of("This name is way too long for a category");
        });
    }

    @Test
    void shouldTrimName() {
        CategoryName name = CategoryName.of("  Fiction  ");
        assertEquals("Fiction", name.value());
    }
}
```

### 5.2. Tests de Aplicaci�n (Integration Tests)

**Path**: `src/test/java/com/mitocode/application/category/usecase/CreateCategoryUseCaseTest.java`

```java
package com.mitocode.application.category.usecase;

import com.mitocode.application.category.dto.CreateCategoryRequest;
import com.mitocode.application.category.dto.CategoryResponse;
import com.mitocode.domain.category.Category;
import com.mitocode.domain.category.CategoryId;
import com.mitocode.domain.category.CategoryName;
import com.mitocode.domain.category.CategoryRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CreateCategoryUseCaseTest {

    @Mock
    private CategoryRepository categoryRepository;

    @InjectMocks
    private CreateCategoryUseCase useCase;

    @Test
    void shouldCreateCategorySuccessfully() {
        // Given
        CreateCategoryRequest request = new CreateCategoryRequest("Fiction", true);

        Category savedCategory = Category.reconstitute(
            CategoryId.of(1),
            CategoryName.of("Fiction"),
            true
        );

        when(categoryRepository.save(any(Category.class)))
            .thenReturn(savedCategory);

        // When
        CategoryResponse response = useCase.execute(request);

        // Then
        assertNotNull(response);
        assertEquals(1, response.idCategory());
        assertEquals("Fiction", response.categoryName());
        assertTrue(response.status());

        verify(categoryRepository, times(1)).save(any(Category.class));
    }
}
```

### 5.3. Contract Tests

**Path**: `src/test/java/com/mitocode/infrastructure/category/adapter/CategoryControllerContractTest.java`

```java
package com.mitocode.infrastructure.category.adapter;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.Matchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@Transactional
class CategoryControllerContractTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void createCategory_shouldMatchOpenAPIContract() throws Exception {
        String requestBody = """
            {
              "categoryName": "Fiction",
              "status": true
            }
            """;

        mockMvc.perform(post("/categories")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBody))
            .andExpect(status().isCreated())
            .andExpect(header().exists("Location"))
            .andExpect(header().string("Location", containsString("/categories/")));
    }

    @Test
    void getAllCategories_shouldMatchOpenAPIContract() throws Exception {
        mockMvc.perform(get("/categories"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status").value(200))
            .andExpect(jsonPath("$.message").value("success"))
            .andExpect(jsonPath("$.data").isArray());
    }

    @Test
    void createCategory_withInvalidData_shouldReturn400() throws Exception {
        String requestBody = """
            {
              "categoryName": "",
              "status": true
            }
            """;

        mockMvc.perform(post("/categories")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBody))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.status").value(400))
            .andExpect(jsonPath("$.message").value("bad-request"));
    }
}
```

---

<a name="validacion"></a>
## 6. Validaci�n

### Checklist de Validaci�n:

- [ ]  **API Contract**: Todos los endpoints responden igual que antes
- [ ]  **Validaciones**: Funcionan id�nticamente
- [ ]  **Status Codes**: 200, 201, 204, 400, 404 funcionan
- [ ]  **GenericResponse**: Se mantiene el wrapper
- [ ]  **Location Header**: POST retorna Location
- [ ]  **Tests**: Todos pasando (unit + integration + contract)

### Comandos para validar:

```bash
# Compilar
./mvnw clean compile

# Ejecutar tests
./mvnw test

# Ejecutar solo tests de dominio (r�pidos)
./mvnw test -Dtest="**/domain/**/*Test"

# Ejecutar contract tests
./mvnw test -Dtest="**/*ContractTest"

# Ejecutar aplicaci�n
./mvnw spring-boot:run
```

---

<a name="replicar"></a>
## 7. Replicar a Otros M�dulos

### Orden sugerido:

1.  **Categories** (HECHO - este blueprint)
2. **Clients** (similar, sin dependencias)
3. **Books** (medio - depende de Categories)
4. **Sales** (complejo - nested objects + cascade)

### Patr�n a seguir para cada m�dulo:

```
1. Crear estructura de directorios
2. DOMINIO:
   - Value Objects (IDs, nombres, etc.)
   - Aggregate Root (entidad principal)
   - Repository (port/interface)
3. APLICACI�N:
   - DTOs (Request/Response)
   - Use Cases (uno por operaci�n)
4. INFRAESTRUCTURA:
   - JPA Entity
   - Mapper
   - Repository Adapter (implementa port)
   - Controller (usa use cases)
5. TESTS:
   - Domain tests (unit, sin mocks)
   - Application tests (con mocks)
   - Contract tests (API compliance)
```

---

## Conclusi�n

Este blueprint proporciona:
-  **C�digo completo** para Categories
-  **Patr�n replicable** para otros m�dulos
-  **100% compatibilidad** con API existente
-  **Tests** en cada capa
-  **Separaci�n clara** de responsabilidades

**Siguiente paso**: Implementar este c�digo y validar que funciona id�nticamente al c�digo MVC original.

---

**Generado por**: Claude Code (Anthropic)
**Fecha**: 2025-10-13
**Versi�n**: 1.0.0
