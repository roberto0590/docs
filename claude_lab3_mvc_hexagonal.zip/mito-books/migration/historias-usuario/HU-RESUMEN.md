# Historias de Usuario - MitoBooks
## Resumen Ejecutivo de la Migraci�n MVC � Hexagonal

**Proyecto**: MitoBooks - Bookstore Management System
**Fecha**: 2025-10-13
**Total de HU**: 21 (basadas en 21 endpoints OpenAPI)
**Objetivo**: Migrar de MVC tradicional a Arquitectura Hexagonal manteniendo 100% compatibilidad de APIs

---

## �ndice de Historias de Usuario

### M�dulo: Books (6 HU)
- **HU-001**: Listar todos los libros � `GET /books`
- **HU-002**: Obtener libro por ID � `GET /books/{id}`
- **HU-003**: Crear nuevo libro � `POST /books`
- **HU-004**: Actualizar libro � `PUT /books/{id}`
- **HU-005**: Eliminar libro � `DELETE /books/{id}`
- **HU-006**: Buscar libros por categor�a � `GET /books/byCategory`

### M�dulo: Categories (5 HU)
- **HU-007**: Listar todas las categor�as � `GET /categories`
- **HU-008**: Obtener categor�a por ID � `GET /categories/{id}`
- **HU-009**: Crear nueva categor�a � `POST /categories`
- **HU-010**: Actualizar categor�a � `PUT /categories/{id}`
- **HU-011**: Eliminar categor�a � `DELETE /categories/{id}`

### M�dulo: Clients (5 HU)
- **HU-012**: Listar todos los clientes � `GET /clients`
- **HU-013**: Obtener cliente por ID � `GET /clients/{id}`
- **HU-014**: Registrar nuevo cliente � `POST /clients`
- **HU-015**: Actualizar datos de cliente � `PUT /clients/{id}`
- **HU-016**: Eliminar cliente � `DELETE /clients/{id}`

### M�dulo: Sales (5 HU)
- **HU-017**: Listar todas las ventas � `GET /sales`
- **HU-018**: Obtener venta por ID � `GET /sales/{id}`
- **HU-019**: Procesar nueva venta � `POST /sales` P **COMPLEJA**
- **HU-020**: Actualizar venta � `PUT /sales/{id}`
- **HU-021**: Anular venta � `DELETE /sales/{id}`

---

## Priorizaci�n y Complejidad

| HU | M�dulo | Prioridad | Complejidad | Orden Sugerido |
|----|--------|-----------|-------------|----------------|
| HU-009 | Categories | CR�TICA | BAJA | 1 (comenzar aqu�) |
| HU-007 | Categories | ALTA | BAJA | 2 |
| HU-008 | Categories | ALTA | BAJA | 3 |
| HU-014 | Clients | ALTA | MEDIA | 4 |
| HU-012 | Clients | ALTA | MEDIA | 5 |
| HU-003 | Books | ALTA | MEDIA | 6 |
| HU-001 | Books | ALTA | MEDIA | 7 |
| HU-006 | Books | ALTA | MEDIA | 8 (query custom) |
| HU-019 | Sales | CR�TICA | ALTA | 9 (cascade + nested) |
| HU-017 | Sales | ALTA | ALTA | 10 |
| ... | ... | ... | ... | ... |

**Criterio de Orden**: Empezar por lo m�s simple (Categories) para establecer patrones, luego escalar a complejidad mayor.

---

## Estructura de Cada HU

Cada Historia de Usuario contiene:

### 1. Cabecera
- ID y t�tulo
- User Story (Como... Quiero... Para...)
- Endpoint asociado
- Prioridad y complejidad

### 2. Criterios de Aceptaci�n de Negocio (Gherkin)
- Escenario 1: Happy path
- Escenario 2: Validaciones fallidas
- Escenario 3: Casos edge
- Escenario N: Errores y excepciones

### 3. Criterios T�cnicos (8 categor�as)
- **CT-001**: API Contract (request/response id�nticos)
- **CT-002**: Request Validation (todas las validaciones)
- **CT-003**: Response Structure (formato exacto)
- **CT-004**: Business Rules (reglas de negocio)
- **CT-005**: Side Effects (efectos secundarios)
- **CT-006**: Performance (tiempos de respuesta)
- **CT-007**: Security (seguridad mantenida)
- **CT-008**: Error Handling (manejo de errores id�ntico)

### 4. Definici�n de Hecho (DoD)
- Desarrollo completado
- Tests pasando (unit, integration, contract)
- Validaci�n t�cnica OK
- Build exitoso

### 5. Mapeo a Arquitectura Hexagonal
- Domain layer: Entities, VOs, Domain Services
- Application layer: Use Cases, DTOs
- Infrastructure layer: Controllers, Repositories

---

## Resumen de Reglas de Negocio Identificadas

### Books
- **RN-B001**: El ID del libro debe ser asignado manualmente y ser �nico
- **RN-B002**: El ISBN debe ser �nico en el sistema
- **RN-B003**: La categor�a debe existir (FK v�lida)
- **RN-B004**: El rango de ID de categor�a es 1-100
- **RN-B005**: El estado (status) permite soft delete

### Categories
- **RN-C001**: El ID se genera autom�ticamente (IDENTITY)
- **RN-C002**: Los nombres deber�an ser �nicos (recomendaci�n)
- **RN-C003**: Eliminar una categor�a puede afectar libros asociados
- **RN-C004**: El estado permite soft delete

### Clients
- **RN-CL001**: El ID se genera autom�ticamente
- **RN-CL002**: Los nombres deben tener entre 3-20 caracteres
- **RN-CL003**: La fecha de nacimiento es obligatoria
- **RN-CL004**: Mapeo custom: firstName � primaryName, surname � lastName
- **RN-CL005**: Considerar GDPR para eliminaci�n de datos

### Sales
- **RN-S001**: El ID se genera autom�ticamente
- **RN-S002**: El cliente debe existir (FK v�lida)
- **RN-S003**: Debe tener al menos un detalle de venta
- **RN-S004**: El total debe coincidir con �(precio � cantidad)
- **RN-S005**: Los detalles se guardan con cascade ALL
- **RN-S006**: Eliminar venta elimina todos sus detalles (cascade DELETE)
- **RN-S007**: Considerar soft delete para auditor�a

---

## Validaciones Identificadas por M�dulo

### Books
- `idBook`: @NotNull
- `idCategory`: @NotNull, @Min(1), @Max(100)
- `title`: @NotNull, maxLength 50
- `isbn`: @NotNull, maxLength 30, unique
- `photoUrl`: @NotNull, maxLength 100
- `status`: @NotNull

### Categories
- `categoryName`: required, maxLength 20
- `status`: required

### Clients
- `firstName`: @NotNull, @Size(min=3, max=20)
- `surname`: @NotNull, @Size(min=3, max=20)
- `birthDateClient`: @NotNull, format date

### Sales
- `client`: @NotNull (nested validation)
- `momentSale`: @NotNull, format date-time
- `totalSale`: @NotNull, positive
- `statusSale`: @NotNull
- `details`: @NotNull, @Size(min=1) (nested validation)

### SaleDetails
- `book`: @NotNull (nested validation)
- `unitPrice`: @NotNull, positive
- `quantity`: @NotNull, @Min(1)
- `status`: @NotNull

---

## Endpoints por Status Code

| Status Code | Cantidad | Casos de Uso |
|-------------|----------|--------------|
| 200 OK | 14 | GET lists, GET by ID, PUT updates |
| 201 Created | 4 | POST creates con Location header |
| 204 No Content | 4 | DELETE operations |
| 400 Bad Request | Todos POST/PUT | Validation errors |
| 404 Not Found | Todos GET/{id}, PUT/{id}, DELETE/{id} | Resource not found |
| 500 Internal Error | Todos | Unexpected errors |

---

## Queries Personalizadas

### IBookRepo.getBooksByCategory()
```java
@Query("FROM Book b WHERE b.category.name LIKE %:name%")
List<Book> getBooksByCategory(@Param("name") String name);
```
- **HU Asociada**: HU-006
- **Criterio T�cnico Especial**: Query JPQL con LIKE debe mantenerse funcional
- **Nivel de Complejidad**: Media (requiere join impl�cito)

---

## ModelMapper Configurations

### defaultMapper
- Uso: Books, Categories
- Configuraci�n: Standard mapping

### clientMapper
- Uso: Clients
- Configuraci�n Custom:
  - `firstName` � `primaryName`
  - `surname` � `lastName`

### saleMapper
- Uso: Sales
- Configuraci�n: Nested mapping con Client fields

**Criterio T�cnico**: Los mapeos deben mantenerse funcionalmente id�nticos post-migraci�n.

---

## Checklist de Migraci�n por HU

Para cada HU, validar:

- [ ] **API Contract**: Request/Response id�nticos (validar con contract tests)
- [ ] **Validations**: Todas las validaciones funcionan igual
- [ ] **Business Rules**: Todas las reglas de negocio implementadas
- [ ] **Side Effects**: Efectos secundarios ejecutados correctamente
- [ ] **Error Handling**: Errores manejados de forma id�ntica
- [ ] **Performance**: Tiempos de respuesta iguales o mejores
- [ ] **Tests**: Unit + Integration + Contract tests pasando
- [ ] **Build**: Compilaci�n exitosa

---

## Dependencias Entre HU

```
HU-009 (Crear Category) � HU-003 (Crear Book) [Category debe existir]
HU-014 (Crear Client) � HU-019 (Crear Sale) [Client debe existir]
HU-003 (Crear Book) � HU-019 (Crear Sale) [Book debe existir en details]
```

**Orden de Implementaci�n Recomendado**:
1. Categories (sin dependencias)
2. Clients (sin dependencias)
3. Books (depende de Categories)
4. Sales (depende de Clients y Books)

---

## Archivos Generados

```
migration/historias-usuario/
   HU-RESUMEN.md                    # Este archivo
   HU-001-Gestionar-Libros.md       # HU completa de ejemplo (Books)
   HU-002-Gestionar-Ventas.md       # HU completa de ejemplo (Sales - compleja)
   [Pendientes: HU-003 a HU-021]    # A generar seg�n necesidad
```

---

## Pr�ximos Pasos

1.  Revisar este resumen
2.  Leer HU-001 (ejemplo Books - complejidad media)
3.  Leer HU-002 (ejemplo Sales - complejidad alta)
4. � Proceder a FASE 4: Mapeo de APIs
5. � Proceder a FASE 5: Migraci�n por Capas

---

## Notas Importantes

- **Compatibilidad 100%**: Todos los contratos API deben mantenerse id�nticos
- **Sin breaking changes**: Los clientes existentes no deben verse afectados
- **Tests como evidencia**: Los contract tests probar�n que no hay cambios
- **Migraci�n incremental**: Se puede migrar m�dulo por m�dulo
- **Rollback seguro**: Backup creado en `.backup/2025-10-13-02-52-53/`

---

**Generado por**: Claude Code (Anthropic)
**Fecha**: 2025-10-13
**Versi�n**: 1.0.0
