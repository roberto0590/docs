# Infrastructure Setup (App + Database)

## docker-compose.yml
```yaml
version: "3.8"

services:
  app:
    build: .
    container_name: mito_books_app
    restart: unless-stopped
    ports:
      - "3000:3000"
    env_file:
      - .env
    depends_on:
      - db
    command: >
      sh -c "npm install && npm run start"

  db:
    image: postgres:16
    container_name: mito_books_db
    restart: unless-stopped
    ports:
      - "${PG_LOCAL_PORT}:5432"
    environment:
      POSTGRES_USER: ${PG_USER}
      POSTGRES_PASSWORD: ${PG_PASSWORD}
      POSTGRES_DB: ${PG_DATABASE}
    volumes:
      - pg-data:/var/lib/postgresql/data

volumes:
  pg-data:

```

### .env
```.env
PORT=3000
NODE_ENV=production

PG_USER=postgres
PG_PASSWORD=postgres
PG_DATABASE=mito_books
PG_HOST=db
PG_LOCAL_PORT=5433
PG_PORT=5432
CORS_ORIGIN=*
```

### .Dockerfile
```.dockerfile

# Dockerfile
FROM node:20-alpine

# Set working directory
WORKDIR /usr/src/app

# Install dependencies
COPY package*.json ./
RUN npm install --production

# Copy app source code
COPY . .

# Expose port
EXPOSE 3000

# Start the app
CMD ["npm", "start"]