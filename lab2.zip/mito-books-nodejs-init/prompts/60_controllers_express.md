# mitobooks_nodejs/prompts/60_controllers_express.md

# Express Controllers and Routes

For each resource:
- Controller: `/src/controllers/<Resource>Controller.js`
- Router: `/src/routes/<resource>.js`
- Register routes in `/src/routes/index.js` under `/api`

Example:
```js
router.get('/books', controller.findAll);
router.post('/books', controller.create);
router.put('/books/:id', controller.update);
router.delete('/books/:id', controller.delete);