# mitobooks_nodejs/prompts/30_models_to_sequelize.md

// /src/models/models.js 
import { DataTypes } from 'sequelize';
import { getSequelize } from '../config/db.js';

const sequelize = getSequelize();

/* ========== CATEGORY ========== */
export const Category = sequelize.define('Category', {
  id_category: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  name:        { type: DataTypes.STRING,  allowNull: false },
  status:      { type: DataTypes.BOOLEAN, allowNull: true }
}, {
  tableName: 'category',
  timestamps: false
});

/* ========== BOOK ========== */
export const Book = sequelize.define('Book', {
  id_book:     { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  id_category: { type: DataTypes.INTEGER, allowNull: false },
  name:        { type: DataTypes.STRING,  allowNull: false },
  isbn:        { type: DataTypes.STRING,  allowNull: true },
  photoUrl:    { type: DataTypes.STRING,  allowNull: true },
  status:      { type: DataTypes.BOOLEAN, allowNull: true }
}, {
  tableName: 'book',
  timestamps: false
});

/* ========== CLIENT ========== */
export const Client = sequelize.define('Client', {
  id_client:   { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  primaryName: { type: DataTypes.STRING,  allowNull: false },
  lastName:    { type: DataTypes.STRING,  allowNull: false },
  birthdate:   { type: DataTypes.DATEONLY, allowNull: true }
}, {
  tableName: 'client',
  timestamps: false
});

/* ========== SALE ========== */
export const Sale = sequelize.define('Sale', {
  id_sale:   { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  id_client: { type: DataTypes.INTEGER, allowNull: false },
  moment:    { type: DataTypes.DATE,    allowNull: false },
  total:     { type: DataTypes.DECIMAL(10,2), allowNull: false, defaultValue: 0 },
  status:    { type: DataTypes.BOOLEAN, allowNull: true }
}, {
  tableName: 'sale',
  timestamps: false
});

/* ========== SALE_DETAIL ========== */
export const SaleDetail = sequelize.define('SaleDetail', {
  id_detail:  { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  id_sale:    { type: DataTypes.INTEGER, allowNull: false },
  id_book:    { type: DataTypes.INTEGER, allowNull: false },
  unit_price: { type: DataTypes.DECIMAL(10,2), allowNull: false },
  quantity:   { type: DataTypes.INTEGER, allowNull: false },
  status:     { type: DataTypes.BOOLEAN, allowNull: true }
}, {
  tableName: 'sale_detail',
  timestamps: false
});

/* ========== ASSOCIATIONS (exactas al diagrama) ========== */
// Category 1 — * Book
Category.hasMany(Book,   { foreignKey: 'id_category', as: 'books' });
Book.belongsTo(Category, { foreignKey: 'id_category', as: 'category' });

// Client 1 — * Sale
Client.hasMany(Sale, { foreignKey: 'id_client', as: 'sales' });
Sale.belongsTo(Client, { foreignKey: 'id_client', as: 'client' });

// Sale 1 — * SaleDetail
Sale.hasMany(SaleDetail, { foreignKey: 'id_sale', as: 'details' });
SaleDetail.belongsTo(Sale, { foreignKey: 'id_sale', as: 'sale' });

// Book 1 — * SaleDetail
Book.hasMany(SaleDetail, { foreignKey: 'id_book', as: 'saleDetails' });
SaleDetail.belongsTo(Book, { foreignKey: 'id_book', as: 'book' });

// Many-to-Many: Book ↔ Sale (through sale_detail)
Book.belongsToMany(Sale, { through: SaleDetail, foreignKey: 'id_book', otherKey: 'id_sale', as: 'sales' });
Sale.belongsToMany(Book, { through: SaleDetail, foreignKey: 'id_sale', otherKey: 'id_book', as: 'books' });

export default {
  Category,
  Book,
  Client,
  Sale,
  SaleDetail
};
