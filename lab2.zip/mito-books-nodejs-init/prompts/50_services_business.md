# mitobooks_nodejs/prompts/50_services_business.md

# Business Logic Layer

Each service corresponds to one resource and handles validations, transactions, and business rules.

Structure:
- `/src/services/<resource>Service.js`
- Use Sequelize transactions when creating or updating sales
- Throw `AppError(status, message)` for predictable errors