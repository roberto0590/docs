# mitobooks_nodejs/prompts/40_repos_data_access.md

import { Book } from '../models/Book.js';
import { Category } from '../models/Category.js';
import { Client } from '../models/Client.js';
import { Sale } from '../models/Sale.js';

export const BookRepository = {
  findAll: () => Book.findAll(),
  findById: (id) => Book.findByPk(id),
  create: (data) => Book.create(data),
  update: async (id, data) => { const b = await Book.findByPk(id); return b ? b.update(data) : null; },
  remove: (id) => Book.destroy({ where: { id } })
};

export const CategoryRepository = {
  findAll: () => Category.findAll(),
  findById: (id) => Category.findByPk(id),
  create: (data) => Category.create(data),
  update: async (id, data) => { const c = await Category.findByPk(id); return c ? c.update(data) : null; },
  remove: (id) => Category.destroy({ where: { id } })
};

export const ClientRepository = {
  findAll: () => Client.findAll(),
  findById: (id) => Client.findByPk(id),
  create: (data) => Client.create(data),
  update: async (id, data) => { const c = await Client.findByPk(id); return c ? c.update(data) : null; },
  remove: (id) => Client.destroy({ where: { id } })
};

export const SaleRepository = {
  findAll: () => Sale.findAll(),
  findById: (id) => Sale.findByPk(id),
  create: (data) => Sale.create(data)  
};