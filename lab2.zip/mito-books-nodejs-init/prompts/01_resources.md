# Domain Resources

| Entity       | Table Name | Fields Summary | Relationships |
|---------------|-------------|----------------|----------------|
| Book          | books       | id(UUID), title, author, price, stock | Many-to-One → Category |
| Category      | categories  | id(UUID), name | One-to-Many → Books |
| Client        | clients     | id(UUID), name, email | One-to-Many → Sales |
| Sale          | sales       | id(UUID), date, total | Many-to-One → Client, One-to-Many → SaleDetails |
| SaleDetail    | sale_items  | id(UUID), quantity, price | Many-to-One → Sale, Many-to-One → Book |

Notes:
- All PKs are UUID auto-generated  
- Decimal fields use `DECIMAL(10,2)`  
- Junction table: `sale_items`  
- Foreign keys follow pattern `fk_<table>_<column>`
