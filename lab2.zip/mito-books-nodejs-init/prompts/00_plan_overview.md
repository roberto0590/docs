# Plan Overview

## Goal
Migrate the Spring MVC app to Node.js (Express + PostgreSQL) in a minimal, working setup on port 3000.

## Execution Order
1. infra — Docker & environment setup  
2. package — Create Node.js manifest  
3. config — App configuration and bootstrap  
4. model — Convert JPA entities to Sequelize models  
5. repo — Data access layer  
6. service — Business logic layer  
7. web — Express controllers and routes  
8. verify — Global verification and summary

## Global Rules
- Each agent runs independently unless called by @plan  
- Default port: **3000**  
- Keep everything minimal and runnable  
- @plan is allowed to create/edit files, run commands, and verify results
