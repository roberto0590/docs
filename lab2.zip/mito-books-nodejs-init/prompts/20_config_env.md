# mitobooks_nodejs/prompts/20_config_env.md
Files to implement:
- `src/config/env.js`
- `src/config/db.js`
- `src/app.js`
- `src/server.js`

Rules:
- Validate `.env` variables
- Default port: **3000**
- Apply CORS, Helmet, Morgan, and JSON middleware