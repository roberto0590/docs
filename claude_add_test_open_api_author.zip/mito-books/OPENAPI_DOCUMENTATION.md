# OpenAPI/Swagger Documentation for Mito-Books API

This document provides information about accessing and using the OpenAPI documentation for the Mito-Books REST API.

## Overview

The Mito-Books API now includes comprehensive OpenAPI 3.0 documentation with interactive Swagger UI. All controllers, endpoints, DTOs, and request/response models are fully documented with detailed descriptions, examples, and validation constraints.

## Accessing the Documentation

### Swagger UI (Interactive Documentation)

Once the application is running, you can access the interactive Swagger UI at:

```
http://localhost:8080/swagger-ui.html
```

Or alternatively:

```
http://localhost:8080/swagger-ui/index.html
```

**Features:**
- Interactive API testing directly from the browser
- Try out all endpoints with sample data
- View request/response schemas with examples
- See all validation constraints and requirements
- Organized by tags: Authors, Books, Categories, Clients, Sales

### OpenAPI Specification (JSON)

The complete OpenAPI specification in JSON format is available at:

```
http://localhost:8080/v3/api-docs
```

### OpenAPI Specification (YAML)

The complete OpenAPI specification in YAML format is available at:

```
http://localhost:8080/v3/api-docs.yaml
```

This YAML file can be:
- Downloaded and imported into API design tools (Postman, Insomnia, etc.)
- Used for contract-first development
- Shared with frontend developers for API integration
- Used to generate client SDKs in various programming languages

## API Documentation Structure

### API Information

- **Title:** Mito-Books API
- **Version:** 1.0.0
- **Description:** REST API for managing a bookstore system with books, categories, clients, and sales
- **Server URL:** http://localhost:8080

### Tags (Resource Groups)

1. **Authors** - Author management API for managing book authors
2. **Books** - Book management API for managing bookstore inventory
3. **Categories** - Category management API for organizing books into categories
4. **Clients** - Client management API for managing bookstore customers
5. **Sales** - Sales management API for handling book purchases and transactions

### Documented Endpoints

Each endpoint includes:
- Operation summary and detailed description
- Request parameters with types, constraints, and examples
- Request body schemas with validation rules
- Response codes: 200, 201, 204, 400, 404, 500
- Response schemas with field descriptions
- Example values for all fields

### Standard CRUD Operations

All resources follow the same pattern:

| Method | Endpoint | Description | Response |
|--------|----------|-------------|----------|
| GET | `/{resource}` | Get all items | 200 with list |
| GET | `/{resource}/{id}` | Get item by ID | 200 with single item |
| POST | `/{resource}` | Create new item | 201 with Location header |
| PUT | `/{resource}/{id}` | Update item | 200 with updated item |
| DELETE | `/{resource}/{id}` | Delete item | 204 No Content |

### Additional Endpoints

- **GET /books/byCategory?category={name}** - Filter books by category name

## Response Wrapper

All responses (except 204 No Content) are wrapped in a `GenericResponse<T>` object:

```json
{
  "status": 200,
  "message": "success",
  "data": [
    {
      // Resource data here
    }
  ]
}
```

**Note:** Even single-item responses are wrapped in a list for consistency.

## Error Responses

The API uses standard HTTP status codes and returns errors in the `GenericResponse` format:

- **400 Bad Request** - Validation errors (message: "bad-request")
- **404 Not Found** - Resource not found (message: "not-found")
- **500 Internal Server Error** - Server errors (message: "failed")

## Data Transfer Objects (DTOs)

All DTOs are fully documented with:
- Field descriptions
- Data types and formats
- Validation constraints (required, min/max length, min/max value)
- Example values
- Read-only indicators for ID fields

### Available DTOs

1. **AuthorDTO** - Author information (firstName, lastName, nationality)
2. **BookDTO** - Book details (title, ISBN, photoUrl, category, author)
3. **CategoryDTO** - Category information (categoryName, status)
4. **ClientDTO** - Client data (firstName, surname, birthDateClient)
5. **SaleDTO** - Sale transaction (client, momentSale, totalSale, details)
6. **SaleDetailDTO** - Individual sale items (book, unitPrice, quantity)

## Configuration

The SpringDoc OpenAPI configuration can be found in:
- **Configuration Class:** `com.mitocode.config.OpenAPIConfig`
- **Application Properties:** `src/main/resources/application.yml`

### SpringDoc Configuration

```yaml
springdoc:
  api-docs:
    path: /v3/api-docs
    enabled: true
  swagger-ui:
    path: /swagger-ui.html
    enabled: true
    try-it-out-enabled: true
    filter: true
    tags-sorter: alpha
    operations-sorter: alpha
  writer-with-default-pretty-printer: true
```

## Using the Documentation

### For Frontend Developers

1. Access Swagger UI at http://localhost:8080/swagger-ui.html
2. Review each endpoint's request/response structure
3. Download the OpenAPI YAML from http://localhost:8080/v3/api-docs.yaml
4. Import into your API client tool (Postman, Insomnia, etc.)

### For API Testing

1. Navigate to Swagger UI
2. Select an endpoint
3. Click "Try it out"
4. Fill in the request parameters/body
5. Click "Execute"
6. Review the response

### For Code Generation

1. Download the OpenAPI YAML specification
2. Use OpenAPI Generator to create client SDKs:
   - JavaScript/TypeScript
   - Python
   - Java
   - C#
   - And many more languages

Example using OpenAPI Generator CLI:
```bash
# Download the YAML
curl http://localhost:8080/v3/api-docs.yaml -o mito-books-api.yaml

# Generate TypeScript client
openapi-generator-cli generate -i mito-books-api.yaml -g typescript-fetch -o ./client
```

## Validation Rules

All DTOs include Jakarta Bean Validation annotations that are reflected in the documentation:

- **@NotNull** - Field is required
- **@NotBlank** - String field cannot be empty
- **@Size(min, max)** - String length constraints
- **@Min/@Max** - Numeric value constraints
- **@Email** - Email format validation (if applicable)

## Important Notes

1. **Development Mode:** The database is configured with `ddl-auto: create`, which drops and recreates the schema on every startup
2. **Database:** PostgreSQL running on port 5436 (Docker Compose)
3. **Authentication:** Currently, no authentication is required (this is a development API)
4. **CORS:** Configure CORS settings if accessing from a different origin

## Next Steps

1. **Start the application:**
   ```bash
   mvn spring-boot:run
   ```

2. **Access Swagger UI:**
   ```
   http://localhost:8080/swagger-ui.html
   ```

3. **Try the API:**
   - Create a category
   - Create an author
   - Create a book
   - Create a client
   - Create a sale

4. **Download the spec:**
   ```
   http://localhost:8080/v3/api-docs.yaml
   ```

## Support

For questions or issues related to the API documentation, please refer to:
- The interactive Swagger UI for live examples
- The CLAUDE.md file for project architecture details
- The source code comments in controllers and DTOs
