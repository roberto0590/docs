Usa el agente java-spring-developer

Para crear la documentación swagger del proyecto y modica las clases  para poder este yml