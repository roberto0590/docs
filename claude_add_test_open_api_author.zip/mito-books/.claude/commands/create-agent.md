# Create Agent Command

Generates a new Claude Code agent following official best practices and conventions.

## Instructions

You are now operating as a **Claude Code Agent Generator** using the `claude-toolkit-generator` agent.

### Task Breakdown

Use the TodoWrite tool to create this checklist:

1. Gather agent requirements from user
2. Analyze existing similar agents for reference
3. Generate agent with proper YAML front matter
4. Create comprehensive workflow sections
5. Add quality requirements and validation
6. Save to `.claude/agents/{name}.md`
7. Validate agent structure and content
8. Update INDEX.md with new agent
9. Provide usage instructions

### Requirements Gathering

**Ask the user for:**

1. **Agent name** (kebab-case format)
   - Example: `swagger-expert`, `test-generator`, `code-reviewer`

2. **Description** (one-line, clear purpose)
   - Example: "Generates OpenAPI 3.0 documentation for Spring Boot APIs"

3. **Tools needed** (select from available tools)
   - Available: Read, Write, Edit, Grep, Glob, Bash
   - Example: [Read, Write, Grep, Glob]

4. **Primary objective** (what should the agent accomplish?)
   - Example: "Analyze Spring Boot controllers and generate swagger.yaml"

5. **Input files** (what files/directories to analyze)
   - Example: "Controllers in infrastructure/in/rest/controller/"

6. **Output location** (where to save results)
   - Example: ".claude/tasks/03-swagger.yaml"

7. **Workflow phases** (high-level steps)
   - Example:
     1. Discovery - find controllers
     2. Analysis - extract endpoints
     3. Generation - create OpenAPI
     4. Validation - check syntax
     5. Output - save and report

### Analysis Phase

**Step 1: Find similar agents**
```bash
ls -la .claude/agents/
```

Based on the agent type, read reference agents:
- **Documentation generators**: `swagger-expert.md`, `scalar-expert.md`
- **Code generators**: `java-hex-architect.md`, `domain-extractor.md`
- **Validators**: `hu-reviewer.md`, `migration-validator.md`
- **Test generators**: `test-generator.md`

**Step 2: Read reference agents**
```bash
cat .claude/agents/{reference-agent}.md
```

Extract patterns for:
- Workflow structure
- Bash command patterns
- Validation criteria
- Output format
- Success criteria

### Generation Phase

**Step 3: Create YAML Front Matter**

Required format:
```yaml
---
name: {agent-name}
description: {one-line description}
tools: [{tool1}, {tool2}, ...]
model: claude-sonnet-4-5
---
```

**Step 4: Create Agent Structure**

Required sections in order:

1. **Introduction** (role statement)
```markdown
You are an expert {role description}.
```

2. **Mission** (🎯)
```markdown
## 🎯 Mission

{Clear statement of what this agent does}
```

3. **Process** (📋)
```markdown
## 📋 {Primary Task} Process

### Step 1: {Phase Name}

**1.1 {Substep}:**
```bash
# Concrete command
{bash command}
```

{Explanation}
```

4. **Quality Requirements** (📊)
```markdown
## 📊 Quality Requirements

### MUST Include:
- ✅ {Requirement}

### MUST NOT Include:
- ❌ {Anti-requirement}
```

5. **Output Format** (📝)
```markdown
## 📝 Output Format

### Success Report:
{Expected report format}
```

6. **Commands Reference** (🔍)
```markdown
## 🔍 Commands Reference

```bash
# {Purpose}
{command}
```
```

7. **Success Criteria** (🎯)
```markdown
## 🎯 Success Criteria

Task is successful ONLY if:
- ✅ {Measurable criterion}
```

8. **Important Notes** (⚠️)
```markdown
## ⚠️ Important Notes

1. **{Critical rule}**: {Explanation}
```

**Step 5: Add Domain-Specific Content**

Based on agent type, add:
- **Mapping tables** for transformations
- **Code examples** for outputs
- **Validation rules** specific to domain
- **Error handling** patterns
- **Integration instructions** if applicable

### Validation Phase

**Step 6: Validate Agent Structure**

Check:
- [ ] YAML front matter is valid
- [ ] All required fields present (name, description, tools, model)
- [ ] All required sections present
- [ ] Sections in correct order
- [ ] Emojis used for section headers
- [ ] Concrete bash commands (not placeholders)
- [ ] Success criteria are measurable
- [ ] Output format is specified
- [ ] Examples provided where helpful

**Step 7: Validate Content Quality**

Check:
- [ ] Steps are sequential and logical
- [ ] Each step has clear input/output
- [ ] Bash commands are executable
- [ ] Validation happens before output
- [ ] Success report format is defined
- [ ] Important notes highlight critical rules

### Output Phase

**Step 8: Save Agent File**
```bash
# Ensure directory exists
mkdir -p .claude/agents

# Save to proper location
# Write to: .claude/agents/{agent-name}.md
```

**Step 9: Update INDEX**
```bash
# Read current INDEX
cat .claude/docs/INDEX.md

# Add new agent to the table
# Update the Available Agents section
```

**Step 10: Provide Usage Report**

## Quality Requirements

### MUST Include in Generated Agent:
- ✅ Valid YAML front matter with all required fields
- ✅ Clear mission statement (🎯)
- ✅ Step-by-step process (📋) with numbered substeps
- ✅ Concrete bash commands in code blocks
- ✅ Quality requirements (📊) with MUST/MUST NOT
- ✅ Output format specification (📝)
- ✅ Commands reference (🔍)
- ✅ Success criteria (🎯) with measurable outcomes
- ✅ Important notes (⚠️) for critical rules
- ✅ Examples and tables where applicable
- ✅ "Begin execution now" ending

### MUST NOT Include:
- ❌ Vague instructions without concrete commands
- ❌ Placeholder bash commands (e.g., "{command}")
- ❌ Missing YAML front matter
- ❌ Undefined success criteria
- ❌ Unspecified output location
- ❌ Sections out of order
- ❌ Code comments in examples (code should be self-explanatory)
- ❌ Instructional comments in generated code snippets

### Best Practices:
- ✅ Use emojis for section headers
- ✅ Number all steps and substeps
- ✅ Provide realistic examples
- ✅ Include mapping tables for transformations
- ✅ Specify exact file paths
- ✅ Define validation checkboxes
- ✅ End with "Begin execution now"

## Success Report Format

After creating the agent, provide this report:

```markdown
✅ Claude Code Agent Created Successfully!

📊 Agent Details:
   - Name: {agent-name}
   - Description: {description}
   - Tools: {tools}
   - Model: claude-sonnet-4-5

📁 Location: .claude/agents/{agent-name}.md
📏 Size: {file-size}

🔍 Quality Validation:
   - ✅ YAML front matter valid
   - ✅ All required sections present ({count}/9)
   - ✅ Concrete bash commands provided ({count} commands)
   - ✅ Success criteria defined ({count} criteria)
   - ✅ Output format specified
   - ✅ Examples included

📋 Generated Sections:
   - 🎯 Mission
   - 📋 Process ({n} steps with {m} substeps)
   - 📊 Quality Requirements
   - 📝 Output Format
   - 🔍 Commands Reference ({n} commands)
   - 🎯 Success Criteria ({n} criteria)
   - ⚠️ Important Notes ({n} notes)
   - 📚 {Additional sections if any}

📖 Reference Agents Used:
   - {reference-agent-1}
   - {reference-agent-2}

✨ Next Steps:
1. Review the agent at .claude/agents/{agent-name}.md
2. Test the agent using Task tool with subagent_type="{agent-name}"
3. Create a slash command if needed (run /create-command)
4. Add documentation in .claude/docs/ if complex
5. Update .claude/docs/INDEX.md (already updated)

📖 Usage:
To use this agent in Claude Code:
1. Via Task tool: Use Task tool with subagent_type="{agent-name}"
2. Via slash command: Create one using /create-command

Example prompt to test:
"Use the {agent-name} agent to {primary objective}"
```

## Example Interaction

**User:** "Create an agent to validate API responses against OpenAPI spec"

**You ask:**
- Agent name? → "api-response-validator"
- Description? → "Validates API responses against OpenAPI 3.0 specifications"
- Tools? → [Read, Bash, Grep]
- Primary objective? → "Compare actual API responses with OpenAPI spec schemas"
- Input files? → "OpenAPI spec and API test results"
- Output? → "Validation report with pass/fail status"
- Workflow phases?
  1. Read OpenAPI spec
  2. Parse schema definitions
  3. Execute API tests
  4. Compare responses with schemas
  5. Generate validation report

**You generate:**
- Agent with all required sections
- Concrete bash commands (curl, jq, grep)
- Validation rules
- Success criteria
- Save to `.claude/agents/api-response-validator.md`
- Update INDEX.md
- Provide usage report

## Tips for Quality Agents

### Good Workflow Structure:
```markdown
### Step 1: Discovery Phase

**1.1 Find Target Files:**
```bash
find src/main/java -path "*/pattern/*.java"
```

Analyze each file for:
- {Specific element 1}
- {Specific element 2}

**1.2 Extract Metadata:**
```bash
grep -E "pattern" file
```

For each match:
- Map {input} → {output}
```

### Good Validation Section:
```markdown
### Step 6: Validation

Before saving, validate:
- ✅ All {entities} analyzed (0 missed)
- ✅ All {elements} converted ({100%} coverage)
- ✅ Output format is valid ({syntax} check)
- ✅ Examples provided ({count} examples)
```

### Good Success Criteria:
```markdown
## 🎯 Success Criteria

Task is successful ONLY if:
- ✅ All {inputs} analyzed (0 {items} missed)
- ✅ Output saved to {exact-path}
- ✅ {Format} syntax is valid
- ✅ Report includes {specific-metrics}
- ✅ {Measurable-outcome} achieved
```

## Success Criteria

Mark task complete when:
- [ ] User requirements gathered
- [ ] Reference agents analyzed
- [ ] YAML front matter created
- [ ] All 9 required sections present
- [ ] Concrete bash commands provided (no placeholders)
- [ ] Success criteria are measurable
- [ ] Output format specified
- [ ] Validation rules defined
- [ ] Agent saved to `.claude/agents/{name}.md`
- [ ] INDEX.md updated
- [ ] Usage report provided to user

---

**Begin execution now.** Use the TodoWrite tool to track progress through each phase. Ask the user for requirements, analyze reference agents, generate a high-quality agent following all best practices, and provide the complete success report.