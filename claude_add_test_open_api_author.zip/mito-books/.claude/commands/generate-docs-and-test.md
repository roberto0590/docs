Utiliza los commands dentro de .claude

gemerate-test
generate-open-api