# Create Command

Generates a new Claude Code slash command following official best practices and conventions.

## Instructions

You are now operating as a **Claude Code Command Generator** using the `claude-toolkit-generator` agent.

### Task Breakdown

Use the TodoWrite tool to create this checklist:

1. Gather command requirements from user
2. Analyze existing similar commands for reference
3. Generate command with proper structure
4. Create phased workflow with TodoWrite integration
5. Add quality requirements and success criteria
6. Save to `.claude/commands/{name}.md`
7. Validate command structure and content
8. Update INDEX.md with new command
9. Provide usage instructions

### Requirements Gathering

**Ask the user for:**

1. **Command name** (without slash)
   - Example: `swagger`, `migrate`, `create-test`
   - Will be used as: `/{name}`

2. **Description** (one-line, what does the command do?)
   - Example: "Generate OpenAPI 3.0 documentation for Spring Boot API"

3. **Associated agent** (if any)
   - Example: `swagger-expert`, `test-generator`, or "none"

4. **Primary task** (what is the main goal?)
   - Example: "Analyze controllers and generate swagger.yaml"

5. **Workflow phases** (major steps in the process)
   - Example:
     1. Discovery - Check existing files
     2. Analysis - Extract metadata
     3. Generation - Create output
     4. Validation - Verify quality
     5. Output - Save and report

6. **Output location** (where to save results)
   - Example: `.claude/tasks/03-swagger.yaml`

7. **Success criteria** (how to know it worked)
   - Example: "All endpoints documented, file saved, syntax valid"

### Analysis Phase

**Step 1: Find similar commands**
```bash
ls -la .claude/commands/
```

Based on the command type, read reference commands:
- **Documentation generators**: `swagger.md`, `scalar-doc.md`
- **Code generators**: `hexdev.md`
- **Migration tools**: `migrate-old.md`
- **Multi-agent workflows**: Commands that invoke agents

**Step 2: Read reference commands**
```bash
cat .claude/commands/{reference-command}.md
```

Extract patterns for:
- Title and description format
- TodoWrite checklist structure
- Phase organization
- Bash command patterns
- Success criteria format

### Generation Phase

**Step 3: Create Command Title and Description**

Format:
```markdown
# {Command Name}

{One or two sentence description of what this command does and when to use it.}

## Instructions

You are now operating as a **{Role}** for {context}.
```

**Step 4: Create TodoWrite Checklist**

```markdown
### Task Breakdown

Use the TodoWrite tool to create this checklist:

1. {Step 1 - action oriented}
2. {Step 2 - action oriented}
3. {Step 3 - action oriented}
4. {Step 4 - action oriented}
5. {Step 5 - action oriented}
...
```

**Step 5: Create Workflow Phases**

For each major phase, create:

```markdown
### {Phase Name} Phase

**Step {N}: {Action}**
```bash
# {Command description}
{concrete bash command}
```

{Explanation of what this step does and what to extract/analyze}

**Step {N+1}: {Action}**
{Instructions for this step}

{Continue for all steps in this phase}
```

Common phase patterns:
- **Discovery Phase**: Find existing files, check prerequisites
- **Analysis Phase**: Extract data, parse files, identify patterns
- **Generation Phase**: Create output, apply transformations
- **Validation Phase**: Check quality, verify requirements
- **Output Phase**: Save files, update documentation, report results

**Step 6: Add Quality Requirements**

```markdown
## Quality Requirements

### MUST {verb}:
- ✅ {Requirement 1}
- ✅ {Requirement 2}
- ✅ {Requirement 3}

### MUST NOT {verb}:
- ❌ {Anti-requirement 1}
- ❌ {Anti-requirement 2}

### {Domain-Specific Requirements}:

{Tables, mappings, or additional rules specific to this command}
```

**Step 7: Add Success Criteria**

```markdown
## Success Criteria

Mark task complete when:
- [ ] {Criterion 1 - checkable}
- [ ] {Criterion 2 - checkable}
- [ ] {Criterion 3 - checkable}
- [ ] {Output saved to correct location}
- [ ] {Format/syntax validated}
- [ ] {Report provided to user}

---

**Begin execution now.** Use the TodoWrite tool to track your progress through each phase.
```

### Integration with Agents

If command uses an agent, add invocation pattern:

**Option 1: Direct agent invocation**
```markdown
### Execution Phase

**Use the {agent-name} agent:**

Invoke the Task tool with:
- subagent_type: "{agent-name}"
- prompt: "{detailed task for agent}"
- description: "{short description}"

The agent will:
1. {What agent does step 1}
2. {What agent does step 2}
3. {What agent does step 3}

Wait for agent completion and review results.
```

**Option 2: Manual workflow with agent patterns**
```markdown
### {Phase Name}

Follow the same workflow as the {agent-name} agent:

**Step 1: {Action}**
{Based on agent's workflow}
```

### Validation Phase

**Step 8: Validate Command Structure**

Check:
- [ ] Title in `# Format`
- [ ] Description paragraph present
- [ ] "Instructions" section with role statement
- [ ] TodoWrite checklist present
- [ ] Phases clearly separated
- [ ] Concrete bash commands provided
- [ ] Quality requirements defined
- [ ] Success criteria with checkboxes
- [ ] Ends with "Begin execution now"

**Step 9: Validate Content Quality**

Check:
- [ ] TodoWrite integration mentioned
- [ ] Bash commands are executable (not placeholders)
- [ ] Output location specified
- [ ] Success criteria are measurable
- [ ] Phases are logical and sequential
- [ ] Examples provided where helpful

### Output Phase

**Step 10: Save Command File**
```bash
# Ensure directory exists
mkdir -p .claude/commands

# Save to proper location
# Write to: .claude/commands/{command-name}.md
```

**Step 11: Update INDEX**
```bash
# Read current INDEX
cat .claude/docs/INDEX.md

# Add new command to the table
# Update the Available Slash Commands section
```

**Step 12: Provide Usage Report**

## Quality Requirements

### MUST Include in Generated Command:
- ✅ Clear title (# Command Name)
- ✅ Description paragraph explaining purpose
- ✅ "Instructions" section with role statement
- ✅ TodoWrite checklist (numbered list)
- ✅ Phased workflow with clear sections
- ✅ Concrete bash commands in code blocks
- ✅ Quality requirements section
- ✅ Success criteria with checkboxes
- ✅ "Begin execution now" ending
- ✅ TodoWrite tracking instructions

### MUST NOT Include:
- ❌ Vague instructions without concrete steps
- ❌ Placeholder commands (e.g., "{command}")
- ❌ Missing output location
- ❌ Undefined success criteria
- ❌ No TodoWrite integration
- ❌ Inconsistent formatting
- ❌ Code comments in examples (code should be self-explanatory)
- ❌ Instructional comments in generated code snippets

### Best Practices:
- ✅ Use ### for phase headers
- ✅ Use **Step N:** for individual steps
- ✅ Provide bash commands in code blocks with # descriptions
- ✅ Include examples where helpful
- ✅ Specify exact file paths
- ✅ Reference agents if applicable
- ✅ Use checkboxes for success criteria
- ✅ End with clear execution instruction

## Success Report Format

After creating the command, provide this report:

```markdown
✅ Claude Code Command Created Successfully!

📊 Command Details:
   - Name: /{command-name}
   - Description: {description}
   - Associated Agent: {agent-name or "None"}
   - Output: {output-location}

📁 Location: .claude/commands/{command-name}.md
📏 Size: {file-size}

🔍 Quality Validation:
   - ✅ Title and description present
   - ✅ Instructions section with role
   - ✅ TodoWrite checklist ({n} items)
   - ✅ Workflow phases ({n} phases)
   - ✅ Concrete bash commands ({n} commands)
   - ✅ Quality requirements defined
   - ✅ Success criteria ({n} checkboxes)
   - ✅ "Begin execution now" ending

📋 Workflow Structure:
   - TodoWrite Checklist: {n} items
   - Phase 1: {phase-name} ({n} steps)
   - Phase 2: {phase-name} ({n} steps)
   - Phase 3: {phase-name} ({n} steps)
   ...
   - Total Steps: {total}

📖 Reference Commands Used:
   - {reference-command-1}
   - {reference-command-2}

✨ Next Steps:
1. Review the command at .claude/commands/{command-name}.md
2. Test the command by typing /{command-name} in Claude Code
3. Update .claude/docs/INDEX.md (already updated)
4. Create documentation in .claude/docs/ if command is complex
5. Consider creating examples in .claude/docs/{command-name}-example.md

📖 Usage:
To use this command in Claude Code, simply type:
/{command-name}

The command will:
1. {What it does step 1}
2. {What it does step 2}
3. {What it does step 3}

Output will be saved to: {output-location}
```

## Example Interaction

**User:** "Create a command to run tests and generate coverage report"

**You ask:**
- Command name? → "test-coverage"
- Description? → "Run unit tests with coverage and generate HTML report"
- Associated agent? → "None" (simple bash workflow)
- Primary task? → "Execute tests, collect coverage, generate report"
- Workflow phases?
  1. Discovery - Check test files exist
  2. Execution - Run tests with coverage
  3. Analysis - Parse coverage results
  4. Generation - Create HTML report
  5. Output - Save and display summary
- Output location? → "target/site/jacoco/index.html"
- Success criteria? → "All tests pass, coverage >80%, report generated"

**You generate:**
- Command with title: "# Test Coverage"
- Description explaining purpose
- TodoWrite checklist with 5 items
- 5 phases with concrete maven/bash commands
- Quality requirements (coverage threshold, etc.)
- Success criteria checkboxes
- Save to `.claude/commands/test-coverage.md`
- Update INDEX.md
- Provide usage report

## Tips for Quality Commands

### Good TodoWrite Checklist:
```markdown
### Task Breakdown

Use the TodoWrite tool to create this checklist:

1. Check for existing test configuration
2. Run unit tests with coverage enabled
3. Parse coverage report for metrics
4. Generate HTML coverage report
5. Validate coverage meets threshold (>80%)
6. Display summary and report location
```

### Good Phase Structure:
```markdown
### Discovery Phase

**Step 1: Verify Test Configuration**
```bash
# Check for JUnit and JaCoCo in pom.xml
grep -A 5 "jacoco-maven-plugin" pom.xml
```

Ensure JaCoCo plugin is configured. If not present, add to pom.xml.

**Step 2: Count Test Files**
```bash
# Find all test files
find src/test/java -name "*Test.java" | wc -l
```

Report: Found {count} test files.
```

### Good Success Criteria:
```markdown
## Success Criteria

Mark task complete when:
- [ ] Test configuration verified (JaCoCo present)
- [ ] All tests executed successfully (0 failures)
- [ ] Coverage report generated at target/site/jacoco/index.html
- [ ] Coverage meets threshold (>80% line coverage)
- [ ] HTML report accessible
- [ ] Summary provided to user with metrics
```

## Command Patterns

### Pattern 1: Simple Workflow (No Agent)
```markdown
# {Command}

{Description}

## Instructions

You are a {role}.

### Task Breakdown
{TodoWrite checklist}

### Phase 1
{Bash commands and instructions}

### Phase 2
{Bash commands and instructions}

## Quality Requirements
{MUST/MUST NOT}

## Success Criteria
{Checkboxes}

---
**Begin execution now.**
```

### Pattern 2: Agent Invocation
```markdown
# {Command}

{Description}

## Instructions

You are using the **{agent-name}** agent.

### Task Breakdown
{TodoWrite checklist including agent invocation}

### Preparation Phase
{Setup steps}

### Execution Phase

**Use the {agent-name} agent:**
- Invoke Task tool with subagent_type="{agent-name}"
- Provide detailed prompt
- Wait for completion

### Post-Processing Phase
{Handle agent output}

## Success Criteria
{Checkboxes including agent completion}

---
**Begin execution now.**
```

### Pattern 3: Multi-Agent Workflow
```markdown
# {Command}

{Description - orchestrates multiple agents}

## Instructions

You are orchestrating a multi-agent workflow.

### Task Breakdown
{TodoWrite checklist with agent sequence}

### Phase 1: Agent 1
{Invoke first agent, wait, validate}

### Phase 2: Agent 2
{Invoke second agent with first's output}

### Phase 3: Integration
{Combine results, validate}

## Success Criteria
{Checkboxes for each agent and integration}

---
**Begin execution now.**
```

## Success Criteria

Mark task complete when:
- [ ] User requirements gathered
- [ ] Reference commands analyzed
- [ ] Title and description created
- [ ] TodoWrite checklist included
- [ ] All workflow phases present
- [ ] Concrete bash commands provided (no placeholders)
- [ ] Quality requirements defined
- [ ] Success criteria with checkboxes
- [ ] "Begin execution now" ending added
- [ ] Command saved to `.claude/commands/{name}.md`
- [ ] INDEX.md updated
- [ ] Usage report provided to user

---

**Begin execution now.** Use the TodoWrite tool to track progress through each phase. Ask the user for requirements, analyze reference commands, generate a high-quality command following all best practices, and provide the complete success report.