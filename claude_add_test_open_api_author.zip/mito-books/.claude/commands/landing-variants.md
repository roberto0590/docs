# Landing Variants

Generates a single, self-contained HTML file with 3 landing page design variants (Modern, Minimalist, Colorful) accessible via tabs, tailored to a specific theme and audience.

## Instructions

You are now operating as a **Landing Page Generator Orchestrator** coordinating the `landing-variants-generator` agent.

### Task Breakdown

Use the TodoWrite tool to create this checklist:

1. Gather theme and audience requirements from user
2. Validate user inputs are provided
3. Prepare output directory structure
4. Invoke landing-variants-generator agent
5. Validate generated HTML file
6. Verify file location and completeness
7. Provide usage instructions to user

### Requirements Gathering Phase

**Step 1: Ask User for Inputs**

Use the AskUserQuestion tool to gather:

1. **Tema (Theme/Topic)**
   - Question: "What is the theme or topic for the landing page?"
   - Examples: "Bookstore for young readers", "SaaS Analytics Platform", "Fitness Coaching", "Tech Startup"
   - This will define the content focus and industry context

2. **Propósito (Purpose)**
   - Question: "What is the main purpose or goal of this landing page?"
   - Examples: "Generate leads for book subscriptions", "Convert visitors to free trial signups", "Showcase portfolio and get contacts", "Sell online courses"
   - This will guide the CTA and messaging strategy

3. **Target (Target Audience)**
   - Question: "Who is the target audience?"
   - Examples: "Young adults 18-35 interested in fantasy novels", "Small business owners needing analytics", "Fitness enthusiasts aged 25-45", "Tech entrepreneurs"
   - This will inform tone, design choices, and testimonials

**Step 2: Validate Inputs**

Ensure all three inputs are provided and not empty. If any are missing, ask again.

### Preparation Phase

**Step 3: Prepare Output Directory**
```bash
mkdir -p outputs
```

Verify the `outputs/` directory exists. This is where the generated HTML will be saved.

**Step 4: Confirm Generation**

Report to user:
```
🎨 Ready to generate landing page variants with:
   - Theme: {tema}
   - Purpose: {propósito}
   - Audience: {target}

Generating 3 variants: Modern, Minimalist, Colorful...
```

### Execution Phase

**Step 5: Invoke Landing Variants Generator Agent**

Use the Task tool to invoke the agent:

- **subagent_type**: `landing-variants-generator`
- **description**: `Generate landing variants HTML`
- **prompt**:
```
Generate a landing page HTML file with these requirements:

Theme: {tema}
Purpose: {propósito}
Target Audience: {target}

Create a single HTML file named "landing-variants.html" with 3 complete landing page variants:
1. Modern - Vibrant gradients, glassmorphism, subtle animations
2. Minimalist - Black/white with accent color, elegant serif typography
3. Colorful - Vibrant multi-color palette, bold fonts, dynamic layout

Each variant must include:
- Hero section with compelling title and CTA button tailored to the theme
- Features section with 3 cards relevant to the purpose
- Testimonials section (2-3 testimonials) addressing the target audience
- Footer with basic information

Technical requirements:
- Functional tab navigation with vanilla JavaScript
- Fully responsive (mobile-first)
- All CSS and JS embedded (no external dependencies)
- Content tailored to theme, purpose, and audience (no Lorem Ipsum)

Save the file to: outputs/landing-variants.html
```

Wait for agent completion and capture the result.

### Validation Phase

**Step 6: Verify File Creation**
```bash
ls -lh outputs/landing-variants.html
```

Confirm the file exists and check file size (should be 15-50 KB typically).

**Step 7: Validate HTML Structure**
```bash
head -50 outputs/landing-variants.html
```

Check for:
- Valid HTML5 doctype (`<!DOCTYPE html>`)
- Meta viewport tag (responsive design)
- Tab navigation elements present
- No obvious syntax errors in first 50 lines

**Step 8: Verify Tab System**
```bash
grep -E "(tab-btn|data-tab=|class=\"variant)" outputs/landing-variants.html | head -10
```

Confirm:
- Tab buttons exist (Moderno, Minimalista, Colorido)
- Data attributes for tab switching are present
- Variant containers with IDs exist

**Step 9: Validate Responsive Design**
```bash
grep -E "@media|max-width|min-width" outputs/landing-variants.html | wc -l
```

Ensure media queries are present (count should be > 0).

### Output Phase

**Step 10: Provide Success Report**

Report to user:
```markdown
✅ Landing Page Variants Generated Successfully!

📊 Configuration:
   - Theme: {tema}
   - Purpose: {propósito}
   - Target Audience: {target}

📁 Location: outputs/landing-variants.html
📏 File Size: {size}

🎨 Included Variants:
   1. Modern - Purple-blue gradients, glassmorphism, subtle animations
   2. Minimalist - Black/white design, serif typography, clean lines
   3. Colorful - Vibrant palette, bold fonts, dynamic layout

✨ Next Steps:
   1. Open outputs/landing-variants.html in your browser
   2. Click the tabs (Moderno, Minimalista, Colorido) to switch variants
   3. Resize your browser window to test responsiveness
   4. Customize content, colors, or styles as needed
   5. Deploy to your web server or hosting platform

💡 Tips:
   - All code is embedded - no server required, works offline
   - Edit the HTML directly to customize further
   - Each variant is fully independent with its own styling
   - Mobile-optimized for all screen sizes

🔗 To view: Simply double-click the HTML file or open with your browser
```

## Quality Requirements

### MUST Complete:
- ✅ Ask user for tema, propósito, and target using AskUserQuestion
- ✅ Validate all inputs are non-empty
- ✅ Create outputs/ directory if it doesn't exist
- ✅ Invoke landing-variants-generator agent with detailed prompt
- ✅ Pass theme, purpose, and audience to agent
- ✅ Verify outputs/landing-variants.html exists after generation
- ✅ Validate HTML has DOCTYPE and meta viewport
- ✅ Confirm tab system structure is present
- ✅ Check media queries exist for responsive design
- ✅ Provide complete success report with file location

### MUST NOT Do:
- ❌ Skip asking user for inputs (always use AskUserQuestion)
- ❌ Use placeholder values for tema/propósito/target
- ❌ Save file to wrong location (must be outputs/landing-variants.html)
- ❌ Generate HTML directly (must delegate to agent)
- ❌ Skip validation steps
- ❌ Auto-open browser (user preference: validation only)
- ❌ Assume defaults without asking user

### Validation Checklist:

| Check | Command | Expected Result |
|-------|---------|-----------------|
| File exists | `ls outputs/landing-variants.html` | File found |
| Valid HTML | `head -5 outputs/landing-variants.html` | Contains `<!DOCTYPE html>` |
| Tab system | `grep "tab-btn" outputs/landing-variants.html` | Tab buttons present |
| Responsive | `grep "@media" outputs/landing-variants.html` | Media queries exist |
| Self-contained | `grep -E "(http://\|https://)" outputs/landing-variants.html` | No CDN links (should be 0 or very few) |

## Success Criteria

Mark task complete when:
- [ ] User provided tema, propósito, and target via AskUserQuestion
- [ ] All three inputs validated as non-empty
- [ ] outputs/ directory exists
- [ ] landing-variants-generator agent invoked with complete prompt
- [ ] Agent execution completed successfully
- [ ] File outputs/landing-variants.html exists
- [ ] HTML contains valid DOCTYPE and meta viewport
- [ ] Tab navigation system verified (3 tabs present)
- [ ] Media queries confirmed (responsive design)
- [ ] File size is reasonable (15-50 KB range)
- [ ] Success report provided to user with next steps
- [ ] No browser auto-open performed (validation only)

---

**Begin execution now.** Use the TodoWrite tool to track your progress. Ask the user for the required inputs, prepare the environment, invoke the landing-variants-generator agent with a detailed prompt, validate the output thoroughly, and provide the complete success report with usage instructions.