Usan el agente test-expert-developer

Para crear las unit test

* Flujo de trabajo
1. Cree en base a la arquitectura de proyecto cree las clases necesarios que necesitan convertura
2. Cree las unit test para cada caso de uso
3. Ejecuta el comando mvn test para validar que las test funcionan de forma correcta