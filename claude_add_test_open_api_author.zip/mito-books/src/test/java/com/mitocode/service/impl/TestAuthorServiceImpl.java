package com.mitocode.service.impl;

import com.mitocode.exception.ModelNotFoundException;
import com.mitocode.model.Author;
import com.mitocode.repo.IAuthorRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("AuthorServiceImpl Unit Tests")
class TestAuthorServiceImpl {

    @Mock
    private IAuthorRepo authorRepo;

    @InjectMocks
    private AuthorServiceImpl authorService;

    private Author testAuthor;

    @BeforeEach
    void setUp() {
        testAuthor = new Author(1, "Gabriel", "Garcia Marquez", "Colombian", null);
    }

    @Test
    @DisplayName("Should save author successfully")
    void shouldSaveAuthor_whenValidAuthorProvided() {
        // Arrange
        when(authorRepo.save(any(Author.class))).thenReturn(testAuthor);

        // Act
        Author savedAuthor = authorService.save(testAuthor);

        // Assert
        assertNotNull(savedAuthor);
        assertEquals(testAuthor.getIdAuthor(), savedAuthor.getIdAuthor());
        assertEquals(testAuthor.getFirstName(), savedAuthor.getFirstName());
        assertEquals(testAuthor.getLastName(), savedAuthor.getLastName());
        assertEquals(testAuthor.getNationality(), savedAuthor.getNationality());
        verify(authorRepo, times(1)).save(any(Author.class));
    }

    @Test
    @DisplayName("Should update author successfully when author exists")
    void shouldUpdateAuthor_whenAuthorExists() {
        // Arrange
        Author updatedAuthor = new Author(1, "Gabriel Jose", "Garcia Marquez", "Colombian", null);
        when(authorRepo.findById(anyInt())).thenReturn(Optional.of(testAuthor));
        when(authorRepo.save(any(Author.class))).thenReturn(updatedAuthor);

        // Act
        Author result = authorService.update(1, updatedAuthor);

        // Assert
        assertNotNull(result);
        assertEquals("Gabriel Jose", result.getFirstName());
        verify(authorRepo, times(1)).findById(1);
        verify(authorRepo, times(1)).save(any(Author.class));
    }

    @Test
    @DisplayName("Should throw exception when updating non-existent author")
    void shouldThrowException_whenUpdatingNonExistentAuthor() {
        // Arrange
        when(authorRepo.findById(anyInt())).thenReturn(Optional.empty());

        // Act & Assert
        ModelNotFoundException exception = assertThrows(ModelNotFoundException.class,
            () -> authorService.update(999, testAuthor));
        assertTrue(exception.getMessage().contains("ID NOT FOUND: 999"));
        verify(authorRepo, times(1)).findById(999);
        verify(authorRepo, never()).save(any(Author.class));
    }

    @Test
    @DisplayName("Should find all authors successfully")
    void shouldFindAllAuthors_whenAuthorsExist() {
        // Arrange
        Author author2 = new Author(2, "Jorge Luis", "Borges", "Argentinian", null);
        Author author3 = new Author(3, "Isabel", "Allende", "Chilean", null);
        List<Author> expectedAuthors = Arrays.asList(testAuthor, author2, author3);
        when(authorRepo.findAll()).thenReturn(expectedAuthors);

        // Act
        List<Author> actualAuthors = authorService.findAll();

        // Assert
        assertNotNull(actualAuthors);
        assertEquals(3, actualAuthors.size());
        assertEquals(expectedAuthors, actualAuthors);
        verify(authorRepo, times(1)).findAll();
    }

    @Test
    @DisplayName("Should return empty list when no authors exist")
    void shouldReturnEmptyList_whenNoAuthorsExist() {
        // Arrange
        when(authorRepo.findAll()).thenReturn(Arrays.asList());

        // Act
        List<Author> actualAuthors = authorService.findAll();

        // Assert
        assertNotNull(actualAuthors);
        assertTrue(actualAuthors.isEmpty());
        verify(authorRepo, times(1)).findAll();
    }

    @Test
    @DisplayName("Should find author by id successfully when author exists")
    void shouldFindAuthorById_whenAuthorExists() {
        // Arrange
        when(authorRepo.findById(anyInt())).thenReturn(Optional.of(testAuthor));

        // Act
        Author foundAuthor = authorService.findById(1);

        // Assert
        assertNotNull(foundAuthor);
        assertEquals(testAuthor.getIdAuthor(), foundAuthor.getIdAuthor());
        assertEquals(testAuthor.getFirstName(), foundAuthor.getFirstName());
        assertEquals(testAuthor.getLastName(), foundAuthor.getLastName());
        verify(authorRepo, times(1)).findById(1);
    }

    @Test
    @DisplayName("Should throw exception when finding non-existent author by id")
    void shouldThrowException_whenFindingNonExistentAuthorById() {
        // Arrange
        when(authorRepo.findById(anyInt())).thenReturn(Optional.empty());

        // Act & Assert
        ModelNotFoundException exception = assertThrows(ModelNotFoundException.class,
            () -> authorService.findById(999));
        assertTrue(exception.getMessage().contains("ID NOT FOUND: 999"));
        verify(authorRepo, times(1)).findById(999);
    }

    @Test
    @DisplayName("Should delete author successfully when author exists")
    void shouldDeleteAuthor_whenAuthorExists() {
        // Arrange
        when(authorRepo.findById(anyInt())).thenReturn(Optional.of(testAuthor));
        doNothing().when(authorRepo).deleteById(anyInt());

        // Act
        authorService.delete(1);

        // Assert
        verify(authorRepo, times(1)).findById(1);
        verify(authorRepo, times(1)).deleteById(1);
    }

    @Test
    @DisplayName("Should throw exception when deleting non-existent author")
    void shouldThrowException_whenDeletingNonExistentAuthor() {
        // Arrange
        when(authorRepo.findById(anyInt())).thenReturn(Optional.empty());

        // Act & Assert
        ModelNotFoundException exception = assertThrows(ModelNotFoundException.class,
            () -> authorService.delete(999));
        assertTrue(exception.getMessage().contains("ID NOT FOUND: 999"));
        verify(authorRepo, times(1)).findById(999);
        verify(authorRepo, never()).deleteById(anyInt());
    }

    @Test
    @DisplayName("Should save author with null nationality")
    void shouldSaveAuthor_whenNationalityIsNull() {
        // Arrange
        Author authorWithoutNationality = new Author(2, "Unknown", "Author", null, null);
        when(authorRepo.save(any(Author.class))).thenReturn(authorWithoutNationality);

        // Act
        Author savedAuthor = authorService.save(authorWithoutNationality);

        // Assert
        assertNotNull(savedAuthor);
        assertNull(savedAuthor.getNationality());
        verify(authorRepo, times(1)).save(any(Author.class));
    }

    @Test
    @DisplayName("Should save author with empty nationality")
    void shouldSaveAuthor_whenNationalityIsEmpty() {
        // Arrange
        Author authorWithEmptyNationality = new Author(3, "Test", "Author", "", null);
        when(authorRepo.save(any(Author.class))).thenReturn(authorWithEmptyNationality);

        // Act
        Author savedAuthor = authorService.save(authorWithEmptyNationality);

        // Assert
        assertNotNull(savedAuthor);
        assertEquals("", savedAuthor.getNationality());
        verify(authorRepo, times(1)).save(any(Author.class));
    }
}
