package com.mitocode.service.impl;

import com.mitocode.exception.ModelNotFoundException;
import com.mitocode.model.Author;
import com.mitocode.model.Book;
import com.mitocode.model.Category;
import com.mitocode.repo.IBookRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("BookServiceImpl Unit Tests")
class TestBookServiceImpl {

    @Mock
    private IBookRepo bookRepo;

    @InjectMocks
    private BookServiceImpl bookService;

    private Book testBook;
    private Category testCategory;
    private Author testAuthor;

    @BeforeEach
    void setUp() {
        testCategory = new Category(1, "Fiction", true);
        testAuthor = new Author(1, "John", "Doe", "American", null);
        testBook = new Book(1, testCategory, testAuthor, "Test Book", "ISBN123", "http://photo.url", true);
    }

    @Test
    @DisplayName("Should save book successfully")
    void shouldSaveBook_whenValidBookProvided() {
        // Arrange
        when(bookRepo.save(any(Book.class))).thenReturn(testBook);

        // Act
        Book savedBook = bookService.save(testBook);

        // Assert
        assertNotNull(savedBook);
        assertEquals(testBook.getIdBook(), savedBook.getIdBook());
        assertEquals(testBook.getTitle(), savedBook.getTitle());
        verify(bookRepo, times(1)).save(any(Book.class));
    }

    @Test
    @DisplayName("Should update book successfully when book exists")
    void shouldUpdateBook_whenBookExists() {
        // Arrange
        Book updatedBook = new Book(1, testCategory, testAuthor, "Updated Book", "ISBN123", "http://photo.url", true);
        when(bookRepo.findById(anyInt())).thenReturn(Optional.of(testBook));
        when(bookRepo.save(any(Book.class))).thenReturn(updatedBook);

        // Act
        Book result = bookService.update(1, updatedBook);

        // Assert
        assertNotNull(result);
        assertEquals("Updated Book", result.getTitle());
        verify(bookRepo, times(1)).findById(1);
        verify(bookRepo, times(1)).save(any(Book.class));
    }

    @Test
    @DisplayName("Should throw exception when updating non-existent book")
    void shouldThrowException_whenUpdatingNonExistentBook() {
        // Arrange
        when(bookRepo.findById(anyInt())).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(ModelNotFoundException.class, () -> bookService.update(999, testBook));
        verify(bookRepo, times(1)).findById(999);
        verify(bookRepo, never()).save(any(Book.class));
    }

    @Test
    @DisplayName("Should find all books successfully")
    void shouldFindAllBooks_whenBooksExist() {
        // Arrange
        Book book2 = new Book(2, testCategory, testAuthor, "Another Book", "ISBN456", "http://photo2.url", true);
        List<Book> expectedBooks = Arrays.asList(testBook, book2);
        when(bookRepo.findAll()).thenReturn(expectedBooks);

        // Act
        List<Book> actualBooks = bookService.findAll();

        // Assert
        assertNotNull(actualBooks);
        assertEquals(2, actualBooks.size());
        assertEquals(expectedBooks, actualBooks);
        verify(bookRepo, times(1)).findAll();
    }

    @Test
    @DisplayName("Should return empty list when no books exist")
    void shouldReturnEmptyList_whenNoBooksExist() {
        // Arrange
        when(bookRepo.findAll()).thenReturn(Arrays.asList());

        // Act
        List<Book> actualBooks = bookService.findAll();

        // Assert
        assertNotNull(actualBooks);
        assertTrue(actualBooks.isEmpty());
        verify(bookRepo, times(1)).findAll();
    }

    @Test
    @DisplayName("Should find book by id successfully when book exists")
    void shouldFindBookById_whenBookExists() {
        // Arrange
        when(bookRepo.findById(anyInt())).thenReturn(Optional.of(testBook));

        // Act
        Book foundBook = bookService.findById(1);

        // Assert
        assertNotNull(foundBook);
        assertEquals(testBook.getIdBook(), foundBook.getIdBook());
        assertEquals(testBook.getTitle(), foundBook.getTitle());
        verify(bookRepo, times(1)).findById(1);
    }

    @Test
    @DisplayName("Should throw exception when finding non-existent book by id")
    void shouldThrowException_whenFindingNonExistentBookById() {
        // Arrange
        when(bookRepo.findById(anyInt())).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(ModelNotFoundException.class, () -> bookService.findById(999));
        verify(bookRepo, times(1)).findById(999);
    }

    @Test
    @DisplayName("Should delete book successfully when book exists")
    void shouldDeleteBook_whenBookExists() {
        // Arrange
        when(bookRepo.findById(anyInt())).thenReturn(Optional.of(testBook));
        doNothing().when(bookRepo).deleteById(anyInt());

        // Act
        bookService.delete(1);

        // Assert
        verify(bookRepo, times(1)).findById(1);
        verify(bookRepo, times(1)).deleteById(1);
    }

    @Test
    @DisplayName("Should throw exception when deleting non-existent book")
    void shouldThrowException_whenDeletingNonExistentBook() {
        // Arrange
        when(bookRepo.findById(anyInt())).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(ModelNotFoundException.class, () -> bookService.delete(999));
        verify(bookRepo, times(1)).findById(999);
        verify(bookRepo, never()).deleteById(anyInt());
    }

    @Test
    @DisplayName("Should get books by category successfully")
    void shouldGetBooksByCategory_whenCategoryExists() {
        // Arrange
        List<Book> expectedBooks = Arrays.asList(testBook);
        when(bookRepo.getBooksByCategory(anyString())).thenReturn(expectedBooks);

        // Act
        List<Book> actualBooks = bookService.getBooksByCategory("Fiction");

        // Assert
        assertNotNull(actualBooks);
        assertEquals(1, actualBooks.size());
        assertEquals(testBook.getTitle(), actualBooks.get(0).getTitle());
        verify(bookRepo, times(1)).getBooksByCategory("Fiction");
    }

    @Test
    @DisplayName("Should return empty list when no books found for category")
    void shouldReturnEmptyList_whenNoBooksFoundForCategory() {
        // Arrange
        when(bookRepo.getBooksByCategory(anyString())).thenReturn(Arrays.asList());

        // Act
        List<Book> actualBooks = bookService.getBooksByCategory("NonExistentCategory");

        // Assert
        assertNotNull(actualBooks);
        assertTrue(actualBooks.isEmpty());
        verify(bookRepo, times(1)).getBooksByCategory("NonExistentCategory");
    }
}
