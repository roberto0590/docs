package com.mitocode.service.impl;

import com.mitocode.exception.ModelNotFoundException;
import com.mitocode.model.Category;
import com.mitocode.repo.ICategoryRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("CategoryServiceImpl Unit Tests")
class TestCategoryServiceImpl {

    @Mock
    private ICategoryRepo categoryRepo;

    @InjectMocks
    private CategoryServiceImpl categoryService;

    private Category testCategory;

    @BeforeEach
    void setUp() {
        testCategory = new Category(1, "Fiction", true);
    }

    @Test
    @DisplayName("Should save category successfully")
    void shouldSaveCategory_whenValidCategoryProvided() {
        // Arrange
        when(categoryRepo.save(any(Category.class))).thenReturn(testCategory);

        // Act
        Category savedCategory = categoryService.save(testCategory);

        // Assert
        assertNotNull(savedCategory);
        assertEquals(testCategory.getIdCategory(), savedCategory.getIdCategory());
        assertEquals(testCategory.getName(), savedCategory.getName());
        assertTrue(savedCategory.isStatus());
        verify(categoryRepo, times(1)).save(any(Category.class));
    }

    @Test
    @DisplayName("Should update category successfully when category exists")
    void shouldUpdateCategory_whenCategoryExists() {
        // Arrange
        Category updatedCategory = new Category(1, "Science Fiction", true);
        when(categoryRepo.findById(anyInt())).thenReturn(Optional.of(testCategory));
        when(categoryRepo.save(any(Category.class))).thenReturn(updatedCategory);

        // Act
        Category result = categoryService.update(1, updatedCategory);

        // Assert
        assertNotNull(result);
        assertEquals("Science Fiction", result.getName());
        verify(categoryRepo, times(1)).findById(1);
        verify(categoryRepo, times(1)).save(any(Category.class));
    }

    @Test
    @DisplayName("Should throw exception when updating non-existent category")
    void shouldThrowException_whenUpdatingNonExistentCategory() {
        // Arrange
        when(categoryRepo.findById(anyInt())).thenReturn(Optional.empty());

        // Act & Assert
        ModelNotFoundException exception = assertThrows(ModelNotFoundException.class,
            () -> categoryService.update(999, testCategory));
        assertTrue(exception.getMessage().contains("ID NOT FOUND: 999"));
        verify(categoryRepo, times(1)).findById(999);
        verify(categoryRepo, never()).save(any(Category.class));
    }

    @Test
    @DisplayName("Should find all categories successfully")
    void shouldFindAllCategories_whenCategoriesExist() {
        // Arrange
        Category category2 = new Category(2, "Non-Fiction", true);
        Category category3 = new Category(3, "Biography", false);
        List<Category> expectedCategories = Arrays.asList(testCategory, category2, category3);
        when(categoryRepo.findAll()).thenReturn(expectedCategories);

        // Act
        List<Category> actualCategories = categoryService.findAll();

        // Assert
        assertNotNull(actualCategories);
        assertEquals(3, actualCategories.size());
        assertEquals(expectedCategories, actualCategories);
        verify(categoryRepo, times(1)).findAll();
    }

    @Test
    @DisplayName("Should return empty list when no categories exist")
    void shouldReturnEmptyList_whenNoCategoriesExist() {
        // Arrange
        when(categoryRepo.findAll()).thenReturn(Arrays.asList());

        // Act
        List<Category> actualCategories = categoryService.findAll();

        // Assert
        assertNotNull(actualCategories);
        assertTrue(actualCategories.isEmpty());
        verify(categoryRepo, times(1)).findAll();
    }

    @Test
    @DisplayName("Should find category by id successfully when category exists")
    void shouldFindCategoryById_whenCategoryExists() {
        // Arrange
        when(categoryRepo.findById(anyInt())).thenReturn(Optional.of(testCategory));

        // Act
        Category foundCategory = categoryService.findById(1);

        // Assert
        assertNotNull(foundCategory);
        assertEquals(testCategory.getIdCategory(), foundCategory.getIdCategory());
        assertEquals(testCategory.getName(), foundCategory.getName());
        verify(categoryRepo, times(1)).findById(1);
    }

    @Test
    @DisplayName("Should throw exception when finding non-existent category by id")
    void shouldThrowException_whenFindingNonExistentCategoryById() {
        // Arrange
        when(categoryRepo.findById(anyInt())).thenReturn(Optional.empty());

        // Act & Assert
        ModelNotFoundException exception = assertThrows(ModelNotFoundException.class,
            () -> categoryService.findById(999));
        assertTrue(exception.getMessage().contains("ID NOT FOUND: 999"));
        verify(categoryRepo, times(1)).findById(999);
    }

    @Test
    @DisplayName("Should delete category successfully when category exists")
    void shouldDeleteCategory_whenCategoryExists() {
        // Arrange
        when(categoryRepo.findById(anyInt())).thenReturn(Optional.of(testCategory));
        doNothing().when(categoryRepo).deleteById(anyInt());

        // Act
        categoryService.delete(1);

        // Assert
        verify(categoryRepo, times(1)).findById(1);
        verify(categoryRepo, times(1)).deleteById(1);
    }

    @Test
    @DisplayName("Should throw exception when deleting non-existent category")
    void shouldThrowException_whenDeletingNonExistentCategory() {
        // Arrange
        when(categoryRepo.findById(anyInt())).thenReturn(Optional.empty());

        // Act & Assert
        ModelNotFoundException exception = assertThrows(ModelNotFoundException.class,
            () -> categoryService.delete(999));
        assertTrue(exception.getMessage().contains("ID NOT FOUND: 999"));
        verify(categoryRepo, times(1)).findById(999);
        verify(categoryRepo, never()).deleteById(anyInt());
    }

    @Test
    @DisplayName("Should handle category with inactive status")
    void shouldHandleCategory_whenStatusIsInactive() {
        // Arrange
        Category inactiveCategory = new Category(2, "Inactive Category", false);
        when(categoryRepo.save(any(Category.class))).thenReturn(inactiveCategory);

        // Act
        Category savedCategory = categoryService.save(inactiveCategory);

        // Assert
        assertNotNull(savedCategory);
        assertFalse(savedCategory.isStatus());
        verify(categoryRepo, times(1)).save(any(Category.class));
    }
}
