package com.mitocode.service.impl;

import com.mitocode.exception.ModelNotFoundException;
import com.mitocode.model.Client;
import com.mitocode.model.Sale;
import com.mitocode.model.SaleDetail;
import com.mitocode.repo.ISaleRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("SaleServiceImpl Unit Tests")
class TestSaleServiceImpl {

    @Mock
    private ISaleRepo saleRepo;

    @InjectMocks
    private SaleServiceImpl saleService;

    private Sale testSale;
    private Client testClient;

    @BeforeEach
    void setUp() {
        testClient = new Client(1, "John", "Doe", LocalDate.of(1990, 5, 15));
        testSale = new Sale(1, testClient, LocalDateTime.now(), 150.50, true, null);
    }

    @Test
    @DisplayName("Should save sale successfully")
    void shouldSaveSale_whenValidSaleProvided() {
        // Arrange
        when(saleRepo.save(any(Sale.class))).thenReturn(testSale);

        // Act
        Sale savedSale = saleService.save(testSale);

        // Assert
        assertNotNull(savedSale);
        assertEquals(testSale.getIdSale(), savedSale.getIdSale());
        assertEquals(testSale.getTotal(), savedSale.getTotal());
        assertTrue(savedSale.isStatus());
        assertNotNull(savedSale.getClient());
        verify(saleRepo, times(1)).save(any(Sale.class));
    }

    @Test
    @DisplayName("Should update sale successfully when sale exists")
    void shouldUpdateSale_whenSaleExists() {
        // Arrange
        Sale updatedSale = new Sale(1, testClient, LocalDateTime.now(), 200.75, true, null);
        when(saleRepo.findById(anyInt())).thenReturn(Optional.of(testSale));
        when(saleRepo.save(any(Sale.class))).thenReturn(updatedSale);

        // Act
        Sale result = saleService.update(1, updatedSale);

        // Assert
        assertNotNull(result);
        assertEquals(200.75, result.getTotal());
        verify(saleRepo, times(1)).findById(1);
        verify(saleRepo, times(1)).save(any(Sale.class));
    }

    @Test
    @DisplayName("Should throw exception when updating non-existent sale")
    void shouldThrowException_whenUpdatingNonExistentSale() {
        // Arrange
        when(saleRepo.findById(anyInt())).thenReturn(Optional.empty());

        // Act & Assert
        ModelNotFoundException exception = assertThrows(ModelNotFoundException.class,
            () -> saleService.update(999, testSale));
        assertTrue(exception.getMessage().contains("ID NOT FOUND: 999"));
        verify(saleRepo, times(1)).findById(999);
        verify(saleRepo, never()).save(any(Sale.class));
    }

    @Test
    @DisplayName("Should find all sales successfully")
    void shouldFindAllSales_whenSalesExist() {
        // Arrange
        Sale sale2 = new Sale(2, testClient, LocalDateTime.now(), 99.99, true, null);
        Sale sale3 = new Sale(3, testClient, LocalDateTime.now(), 250.00, false, null);
        List<Sale> expectedSales = Arrays.asList(testSale, sale2, sale3);
        when(saleRepo.findAll()).thenReturn(expectedSales);

        // Act
        List<Sale> actualSales = saleService.findAll();

        // Assert
        assertNotNull(actualSales);
        assertEquals(3, actualSales.size());
        assertEquals(expectedSales, actualSales);
        verify(saleRepo, times(1)).findAll();
    }

    @Test
    @DisplayName("Should return empty list when no sales exist")
    void shouldReturnEmptyList_whenNoSalesExist() {
        // Arrange
        when(saleRepo.findAll()).thenReturn(Arrays.asList());

        // Act
        List<Sale> actualSales = saleService.findAll();

        // Assert
        assertNotNull(actualSales);
        assertTrue(actualSales.isEmpty());
        verify(saleRepo, times(1)).findAll();
    }

    @Test
    @DisplayName("Should find sale by id successfully when sale exists")
    void shouldFindSaleById_whenSaleExists() {
        // Arrange
        when(saleRepo.findById(anyInt())).thenReturn(Optional.of(testSale));

        // Act
        Sale foundSale = saleService.findById(1);

        // Assert
        assertNotNull(foundSale);
        assertEquals(testSale.getIdSale(), foundSale.getIdSale());
        assertEquals(testSale.getTotal(), foundSale.getTotal());
        assertNotNull(foundSale.getClient());
        verify(saleRepo, times(1)).findById(1);
    }

    @Test
    @DisplayName("Should throw exception when finding non-existent sale by id")
    void shouldThrowException_whenFindingNonExistentSaleById() {
        // Arrange
        when(saleRepo.findById(anyInt())).thenReturn(Optional.empty());

        // Act & Assert
        ModelNotFoundException exception = assertThrows(ModelNotFoundException.class,
            () -> saleService.findById(999));
        assertTrue(exception.getMessage().contains("ID NOT FOUND: 999"));
        verify(saleRepo, times(1)).findById(999);
    }

    @Test
    @DisplayName("Should delete sale successfully when sale exists")
    void shouldDeleteSale_whenSaleExists() {
        // Arrange
        when(saleRepo.findById(anyInt())).thenReturn(Optional.of(testSale));
        doNothing().when(saleRepo).deleteById(anyInt());

        // Act
        saleService.delete(1);

        // Assert
        verify(saleRepo, times(1)).findById(1);
        verify(saleRepo, times(1)).deleteById(1);
    }

    @Test
    @DisplayName("Should throw exception when deleting non-existent sale")
    void shouldThrowException_whenDeletingNonExistentSale() {
        // Arrange
        when(saleRepo.findById(anyInt())).thenReturn(Optional.empty());

        // Act & Assert
        ModelNotFoundException exception = assertThrows(ModelNotFoundException.class,
            () -> saleService.delete(999));
        assertTrue(exception.getMessage().contains("ID NOT FOUND: 999"));
        verify(saleRepo, times(1)).findById(999);
        verify(saleRepo, never()).deleteById(anyInt());
    }

    @Test
    @DisplayName("Should handle sale with inactive status")
    void shouldHandleSale_whenStatusIsInactive() {
        // Arrange
        Sale inactiveSale = new Sale(4, testClient, LocalDateTime.now(), 50.00, false, null);
        when(saleRepo.save(any(Sale.class))).thenReturn(inactiveSale);

        // Act
        Sale savedSale = saleService.save(inactiveSale);

        // Assert
        assertNotNull(savedSale);
        assertFalse(savedSale.isStatus());
        verify(saleRepo, times(1)).save(any(Sale.class));
    }

    @Test
    @DisplayName("Should handle sale with zero total")
    void shouldHandleSale_whenTotalIsZero() {
        // Arrange
        Sale zeroSale = new Sale(5, testClient, LocalDateTime.now(), 0.0, true, null);
        when(saleRepo.save(any(Sale.class))).thenReturn(zeroSale);

        // Act
        Sale savedSale = saleService.save(zeroSale);

        // Assert
        assertNotNull(savedSale);
        assertEquals(0.0, savedSale.getTotal());
        verify(saleRepo, times(1)).save(any(Sale.class));
    }

    @Test
    @DisplayName("Should handle sale with large total amount")
    void shouldHandleSale_whenTotalIsLarge() {
        // Arrange
        Sale largeSale = new Sale(6, testClient, LocalDateTime.now(), 9999.99, true, null);
        when(saleRepo.save(any(Sale.class))).thenReturn(largeSale);

        // Act
        Sale savedSale = saleService.save(largeSale);

        // Assert
        assertNotNull(savedSale);
        assertEquals(9999.99, savedSale.getTotal());
        verify(saleRepo, times(1)).save(any(Sale.class));
    }
}
