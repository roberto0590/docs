package com.mitocode.service.impl;

import com.mitocode.exception.ModelNotFoundException;
import com.mitocode.model.Client;
import com.mitocode.repo.IClientRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("ClientServiceImpl Unit Tests")
class TestClientServiceImpl {

    @Mock
    private IClientRepo clientRepo;

    @InjectMocks
    private ClientServiceImpl clientService;

    private Client testClient;

    @BeforeEach
    void setUp() {
        testClient = new Client(1, "John", "Doe", LocalDate.of(1990, 5, 15));
    }

    @Test
    @DisplayName("Should save client successfully")
    void shouldSaveClient_whenValidClientProvided() {
        // Arrange
        when(clientRepo.save(any(Client.class))).thenReturn(testClient);

        // Act
        Client savedClient = clientService.save(testClient);

        // Assert
        assertNotNull(savedClient);
        assertEquals(testClient.getIdClient(), savedClient.getIdClient());
        assertEquals(testClient.getPrimaryName(), savedClient.getPrimaryName());
        assertEquals(testClient.getLastName(), savedClient.getLastName());
        assertEquals(testClient.getBirthDate(), savedClient.getBirthDate());
        verify(clientRepo, times(1)).save(any(Client.class));
    }

    @Test
    @DisplayName("Should update client successfully when client exists")
    void shouldUpdateClient_whenClientExists() {
        // Arrange
        Client updatedClient = new Client(1, "Jane", "Smith", LocalDate.of(1992, 8, 20));
        when(clientRepo.findById(anyInt())).thenReturn(Optional.of(testClient));
        when(clientRepo.save(any(Client.class))).thenReturn(updatedClient);

        // Act
        Client result = clientService.update(1, updatedClient);

        // Assert
        assertNotNull(result);
        assertEquals("Jane", result.getPrimaryName());
        assertEquals("Smith", result.getLastName());
        verify(clientRepo, times(1)).findById(1);
        verify(clientRepo, times(1)).save(any(Client.class));
    }

    @Test
    @DisplayName("Should throw exception when updating non-existent client")
    void shouldThrowException_whenUpdatingNonExistentClient() {
        // Arrange
        when(clientRepo.findById(anyInt())).thenReturn(Optional.empty());

        // Act & Assert
        ModelNotFoundException exception = assertThrows(ModelNotFoundException.class,
            () -> clientService.update(999, testClient));
        assertTrue(exception.getMessage().contains("ID NOT FOUND: 999"));
        verify(clientRepo, times(1)).findById(999);
        verify(clientRepo, never()).save(any(Client.class));
    }

    @Test
    @DisplayName("Should find all clients successfully")
    void shouldFindAllClients_whenClientsExist() {
        // Arrange
        Client client2 = new Client(2, "Alice", "Johnson", LocalDate.of(1985, 3, 10));
        Client client3 = new Client(3, "Bob", "Williams", LocalDate.of(1995, 12, 1));
        List<Client> expectedClients = Arrays.asList(testClient, client2, client3);
        when(clientRepo.findAll()).thenReturn(expectedClients);

        // Act
        List<Client> actualClients = clientService.findAll();

        // Assert
        assertNotNull(actualClients);
        assertEquals(3, actualClients.size());
        assertEquals(expectedClients, actualClients);
        verify(clientRepo, times(1)).findAll();
    }

    @Test
    @DisplayName("Should return empty list when no clients exist")
    void shouldReturnEmptyList_whenNoClientsExist() {
        // Arrange
        when(clientRepo.findAll()).thenReturn(Arrays.asList());

        // Act
        List<Client> actualClients = clientService.findAll();

        // Assert
        assertNotNull(actualClients);
        assertTrue(actualClients.isEmpty());
        verify(clientRepo, times(1)).findAll();
    }

    @Test
    @DisplayName("Should find client by id successfully when client exists")
    void shouldFindClientById_whenClientExists() {
        // Arrange
        when(clientRepo.findById(anyInt())).thenReturn(Optional.of(testClient));

        // Act
        Client foundClient = clientService.findById(1);

        // Assert
        assertNotNull(foundClient);
        assertEquals(testClient.getIdClient(), foundClient.getIdClient());
        assertEquals(testClient.getPrimaryName(), foundClient.getPrimaryName());
        assertEquals(testClient.getLastName(), foundClient.getLastName());
        verify(clientRepo, times(1)).findById(1);
    }

    @Test
    @DisplayName("Should throw exception when finding non-existent client by id")
    void shouldThrowException_whenFindingNonExistentClientById() {
        // Arrange
        when(clientRepo.findById(anyInt())).thenReturn(Optional.empty());

        // Act & Assert
        ModelNotFoundException exception = assertThrows(ModelNotFoundException.class,
            () -> clientService.findById(999));
        assertTrue(exception.getMessage().contains("ID NOT FOUND: 999"));
        verify(clientRepo, times(1)).findById(999);
    }

    @Test
    @DisplayName("Should delete client successfully when client exists")
    void shouldDeleteClient_whenClientExists() {
        // Arrange
        when(clientRepo.findById(anyInt())).thenReturn(Optional.of(testClient));
        doNothing().when(clientRepo).deleteById(anyInt());

        // Act
        clientService.delete(1);

        // Assert
        verify(clientRepo, times(1)).findById(1);
        verify(clientRepo, times(1)).deleteById(1);
    }

    @Test
    @DisplayName("Should throw exception when deleting non-existent client")
    void shouldThrowException_whenDeletingNonExistentClient() {
        // Arrange
        when(clientRepo.findById(anyInt())).thenReturn(Optional.empty());

        // Act & Assert
        ModelNotFoundException exception = assertThrows(ModelNotFoundException.class,
            () -> clientService.delete(999));
        assertTrue(exception.getMessage().contains("ID NOT FOUND: 999"));
        verify(clientRepo, times(1)).findById(999);
        verify(clientRepo, never()).deleteById(anyInt());
    }

    @Test
    @DisplayName("Should handle client with future birthdate")
    void shouldHandleClient_whenBirthdateIsFuture() {
        // Arrange
        Client futureClient = new Client(4, "Future", "Client", LocalDate.now().plusYears(1));
        when(clientRepo.save(any(Client.class))).thenReturn(futureClient);

        // Act
        Client savedClient = clientService.save(futureClient);

        // Assert
        assertNotNull(savedClient);
        assertTrue(savedClient.getBirthDate().isAfter(LocalDate.now()));
        verify(clientRepo, times(1)).save(any(Client.class));
    }

    @Test
    @DisplayName("Should handle client with very old birthdate")
    void shouldHandleClient_whenBirthdateIsVeryOld() {
        // Arrange
        Client oldClient = new Client(5, "Old", "Client", LocalDate.of(1900, 1, 1));
        when(clientRepo.save(any(Client.class))).thenReturn(oldClient);

        // Act
        Client savedClient = clientService.save(oldClient);

        // Assert
        assertNotNull(savedClient);
        assertEquals(LocalDate.of(1900, 1, 1), savedClient.getBirthDate());
        verify(clientRepo, times(1)).save(any(Client.class));
    }
}
