package com.mitocode.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mitocode.dto.ClientDTO;
import com.mitocode.exception.ModelNotFoundException;
import com.mitocode.model.Client;
import com.mitocode.service.IClientService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ClientController.class)
@DisplayName("ClientController Integration Tests")
class TestClientController {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private IClientService clientService;

    @MockBean(name = "clientMapper")
    private ModelMapper clientMapper;

    private Client testClient;
    private ClientDTO testClientDTO;

    @BeforeEach
    void setUp() {
        testClient = new Client(1, "John", "Doe", LocalDate.of(1990, 5, 15));
        testClientDTO = new ClientDTO(1, "John", "Doe", LocalDate.of(1990, 5, 15));
    }

    @Test
    @DisplayName("Should get all clients successfully")
    void shouldGetAllClients_whenClientsExist() throws Exception {
        // Arrange
        List<Client> clients = Arrays.asList(testClient);
        when(clientService.findAll()).thenReturn(clients);
        when(clientMapper.map(any(Client.class), eq(ClientDTO.class))).thenReturn(testClientDTO);

        // Act & Assert
        mockMvc.perform(get("/clients")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(200))
                .andExpect(jsonPath("$.message").value("success"))
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.data", hasSize(1)))
                .andExpect(jsonPath("$.data[0].idClient").value(1))
                .andExpect(jsonPath("$.data[0].firstName").value("John"))
                .andExpect(jsonPath("$.data[0].surname").value("Doe"));

        verify(clientService, times(1)).findAll();
    }

    @Test
    @DisplayName("Should get client by id successfully")
    void shouldGetClientById_whenClientExists() throws Exception {
        // Arrange
        when(clientService.findById(anyInt())).thenReturn(testClient);
        when(clientMapper.map(any(Client.class), eq(ClientDTO.class))).thenReturn(testClientDTO);

        // Act & Assert
        mockMvc.perform(get("/clients/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(200))
                .andExpect(jsonPath("$.message").value("success"))
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.data", hasSize(1)))
                .andExpect(jsonPath("$.data[0].idClient").value(1))
                .andExpect(jsonPath("$.data[0].firstName").value("John"));

        verify(clientService, times(1)).findById(1);
    }

    @Test
    @DisplayName("Should return 404 when client not found by id")
    void shouldReturn404_whenClientNotFoundById() throws Exception {
        // Arrange
        when(clientService.findById(anyInt())).thenThrow(new ModelNotFoundException("ID NOT FOUND: 999"));

        // Act & Assert
        mockMvc.perform(get("/clients/999")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        verify(clientService, times(1)).findById(999);
    }

    @Test
    @DisplayName("Should create client successfully with valid data")
    void shouldCreateClient_whenValidClientProvided() throws Exception {
        // Arrange
        when(clientMapper.map(any(ClientDTO.class), eq(Client.class))).thenReturn(testClient);
        when(clientService.save(any(Client.class))).thenReturn(testClient);

        // Act & Assert
        mockMvc.perform(post("/clients")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(testClientDTO)))
                .andExpect(status().isCreated())
                .andExpect(header().exists("Location"))
                .andExpect(header().string("Location", containsString("/clients/1")));

        verify(clientService, times(1)).save(any(Client.class));
    }

    @Test
    @DisplayName("Should return 400 when creating client with invalid data")
    void shouldReturn400_whenCreatingClientWithInvalidData() throws Exception {
        // Arrange - client with firstName too short
        ClientDTO invalidClientDTO = new ClientDTO(null, "Jo", "Doe", LocalDate.of(1990, 5, 15));

        // Act & Assert
        mockMvc.perform(post("/clients")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(invalidClientDTO)))
                .andExpect(status().isBadRequest());

        verify(clientService, never()).save(any(Client.class));
    }

    @Test
    @DisplayName("Should return 400 when creating client with null firstName")
    void shouldReturn400_whenCreatingClientWithNullFirstName() throws Exception {
        // Arrange
        ClientDTO invalidClientDTO = new ClientDTO(null, null, "Doe", LocalDate.of(1990, 5, 15));

        // Act & Assert
        mockMvc.perform(post("/clients")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(invalidClientDTO)))
                .andExpect(status().isBadRequest());

        verify(clientService, never()).save(any(Client.class));
    }

    @Test
    @DisplayName("Should update client successfully")
    void shouldUpdateClient_whenValidClientProvided() throws Exception {
        // Arrange
        Client updatedClient = new Client(1, "Jane", "Smith", LocalDate.of(1992, 8, 20));
        ClientDTO updatedClientDTO = new ClientDTO(1, "Jane", "Smith", LocalDate.of(1992, 8, 20));

        when(clientMapper.map(any(ClientDTO.class), eq(Client.class))).thenReturn(updatedClient);
        when(clientService.update(anyInt(), any(Client.class))).thenReturn(updatedClient);
        when(clientMapper.map(any(Client.class), eq(ClientDTO.class))).thenReturn(updatedClientDTO);

        // Act & Assert
        mockMvc.perform(put("/clients/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updatedClientDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(200))
                .andExpect(jsonPath("$.message").value("success"))
                .andExpect(jsonPath("$.data[0].firstName").value("Jane"))
                .andExpect(jsonPath("$.data[0].surname").value("Smith"));

        verify(clientService, times(1)).update(eq(1), any(Client.class));
    }

    @Test
    @DisplayName("Should return 404 when updating non-existent client")
    void shouldReturn404_whenUpdatingNonExistentClient() throws Exception {
        // Arrange
        when(clientMapper.map(any(ClientDTO.class), eq(Client.class))).thenReturn(testClient);
        when(clientService.update(anyInt(), any(Client.class)))
                .thenThrow(new ModelNotFoundException("ID NOT FOUND: 999"));

        // Act & Assert
        mockMvc.perform(put("/clients/999")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(testClientDTO)))
                .andExpect(status().isNotFound());

        verify(clientService, times(1)).update(eq(999), any(Client.class));
    }

    @Test
    @DisplayName("Should delete client successfully")
    void shouldDeleteClient_whenClientExists() throws Exception {
        // Arrange
        doNothing().when(clientService).delete(anyInt());

        // Act & Assert
        mockMvc.perform(delete("/clients/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        verify(clientService, times(1)).delete(1);
    }

    @Test
    @DisplayName("Should return 404 when deleting non-existent client")
    void shouldReturn404_whenDeletingNonExistentClient() throws Exception {
        // Arrange
        doThrow(new ModelNotFoundException("ID NOT FOUND: 999"))
                .when(clientService).delete(anyInt());

        // Act & Assert
        mockMvc.perform(delete("/clients/999")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        verify(clientService, times(1)).delete(999);
    }

    @Test
    @DisplayName("Should return empty list when no clients exist")
    void shouldReturnEmptyList_whenNoClientsExist() throws Exception {
        // Arrange
        when(clientService.findAll()).thenReturn(Arrays.asList());

        // Act & Assert
        mockMvc.perform(get("/clients")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(200))
                .andExpect(jsonPath("$.message").value("success"))
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.data", hasSize(0)));

        verify(clientService, times(1)).findAll();
    }
}
