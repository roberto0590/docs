package com.mitocode.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mitocode.dto.BookDTO;
import com.mitocode.exception.ModelNotFoundException;
import com.mitocode.model.Author;
import com.mitocode.model.Book;
import com.mitocode.model.Category;
import com.mitocode.service.IAuthorService;
import com.mitocode.service.IBookService;
import com.mitocode.service.ICategoryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(BookController.class)
@DisplayName("BookController Integration Tests")
class TestBookController {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private IBookService bookService;

    @MockBean
    private ICategoryService categoryService;

    @MockBean
    private IAuthorService authorService;

    @MockBean(name = "bookMapper")
    private ModelMapper bookMapper;

    private Book testBook;
    private BookDTO testBookDTO;
    private Category testCategory;
    private Author testAuthor;

    @BeforeEach
    void setUp() {
        testCategory = new Category(1, "Fiction", true);
        testAuthor = new Author(1, "John", "Doe", "American", null);
        testBook = new Book(1, testCategory, testAuthor, "Test Book", "ISBN123", "http://photo.url", true);
        testBookDTO = new BookDTO(1, 1, 1, "Test Book", "ISBN123", "http://photo.url", true);
    }

    @Test
    @DisplayName("Should get all books successfully")
    void shouldGetAllBooks_whenBooksExist() throws Exception {
        // Arrange
        List<Book> books = Arrays.asList(testBook);
        when(bookService.findAll()).thenReturn(books);
        when(bookMapper.map(any(Book.class), eq(BookDTO.class))).thenReturn(testBookDTO);

        // Act & Assert
        mockMvc.perform(get("/books")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(200))
                .andExpect(jsonPath("$.message").value("success"))
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.data", hasSize(1)))
                .andExpect(jsonPath("$.data[0].idBook").value(1))
                .andExpect(jsonPath("$.data[0].title").value("Test Book"));

        verify(bookService, times(1)).findAll();
    }

    @Test
    @DisplayName("Should get book by id successfully")
    void shouldGetBookById_whenBookExists() throws Exception {
        // Arrange
        when(bookService.findById(anyInt())).thenReturn(testBook);
        when(bookMapper.map(any(Book.class), eq(BookDTO.class))).thenReturn(testBookDTO);

        // Act & Assert
        mockMvc.perform(get("/books/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(200))
                .andExpect(jsonPath("$.message").value("success"))
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.data", hasSize(1)))
                .andExpect(jsonPath("$.data[0].idBook").value(1))
                .andExpect(jsonPath("$.data[0].title").value("Test Book"));

        verify(bookService, times(1)).findById(1);
    }

    @Test
    @DisplayName("Should return 404 when book not found by id")
    void shouldReturn404_whenBookNotFoundById() throws Exception {
        // Arrange
        when(bookService.findById(anyInt())).thenThrow(new ModelNotFoundException("ID NOT FOUND: 999"));

        // Act & Assert
        mockMvc.perform(get("/books/999")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        verify(bookService, times(1)).findById(999);
    }

    @Test
    @DisplayName("Should create book successfully")
    void shouldCreateBook_whenValidBookProvided() throws Exception {
        // Arrange
        when(categoryService.findById(anyInt())).thenReturn(testCategory);
        when(authorService.findById(anyInt())).thenReturn(testAuthor);
        when(bookMapper.map(any(BookDTO.class), eq(Book.class))).thenReturn(testBook);
        when(bookService.save(any(Book.class))).thenReturn(testBook);

        // Act & Assert
        mockMvc.perform(post("/books")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(testBookDTO)))
                .andExpect(status().isCreated())
                .andExpect(header().exists("Location"))
                .andExpect(header().string("Location", containsString("/books/1")));

        verify(bookService, times(1)).save(any(Book.class));
    }

    @Test
    @DisplayName("Should update book successfully")
    void shouldUpdateBook_whenValidBookProvided() throws Exception {
        // Arrange
        Book updatedBook = new Book(1, testCategory, testAuthor, "Updated Book", "ISBN123", "http://photo.url", true);
        BookDTO updatedBookDTO = new BookDTO(1, 1, 1, "Updated Book", "ISBN123", "http://photo.url", true);

        when(categoryService.findById(anyInt())).thenReturn(testCategory);
        when(authorService.findById(anyInt())).thenReturn(testAuthor);
        when(bookMapper.map(any(BookDTO.class), eq(Book.class))).thenReturn(updatedBook);
        when(bookService.update(anyInt(), any(Book.class))).thenReturn(updatedBook);
        when(bookMapper.map(any(Book.class), eq(BookDTO.class))).thenReturn(updatedBookDTO);

        // Act & Assert
        mockMvc.perform(put("/books/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updatedBookDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(200))
                .andExpect(jsonPath("$.message").value("success"))
                .andExpect(jsonPath("$.data[0].title").value("Updated Book"));

        verify(bookService, times(1)).update(eq(1), any(Book.class));
    }

    @Test
    @DisplayName("Should delete book successfully")
    void shouldDeleteBook_whenBookExists() throws Exception {
        // Arrange
        doNothing().when(bookService).delete(anyInt());

        // Act & Assert
        mockMvc.perform(delete("/books/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        verify(bookService, times(1)).delete(1);
    }

    @Test
    @DisplayName("Should get books by category successfully")
    void shouldGetBooksByCategory_whenCategoryExists() throws Exception {
        // Arrange
        List<Book> books = Arrays.asList(testBook);
        when(bookService.getBooksByCategory(anyString())).thenReturn(books);
        when(bookMapper.map(any(Book.class), eq(BookDTO.class))).thenReturn(testBookDTO);

        // Act & Assert
        mockMvc.perform(get("/books/byCategory")
                .param("category", "Fiction")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(200))
                .andExpect(jsonPath("$.message").value("success"))
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.data", hasSize(1)))
                .andExpect(jsonPath("$.data[0].title").value("Test Book"));

        verify(bookService, times(1)).getBooksByCategory("Fiction");
    }

    @Test
    @DisplayName("Should return empty list when no books found for category")
    void shouldReturnEmptyList_whenNoBooksFoundForCategory() throws Exception {
        // Arrange
        when(bookService.getBooksByCategory(anyString())).thenReturn(Arrays.asList());

        // Act & Assert
        mockMvc.perform(get("/books/byCategory")
                .param("category", "NonExistent")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(200))
                .andExpect(jsonPath("$.message").value("success"))
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.data", hasSize(0)));

        verify(bookService, times(1)).getBooksByCategory("NonExistent");
    }
}
