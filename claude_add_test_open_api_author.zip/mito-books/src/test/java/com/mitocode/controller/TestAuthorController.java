package com.mitocode.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mitocode.dto.AuthorDTO;
import com.mitocode.exception.ModelNotFoundException;
import com.mitocode.model.Author;
import com.mitocode.service.IAuthorService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AuthorController.class)
@DisplayName("AuthorController Integration Tests")
class TestAuthorController {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private IAuthorService authorService;

    @MockBean(name = "defaultMapper")
    private ModelMapper modelMapper;

    private Author testAuthor;
    private AuthorDTO testAuthorDTO;

    @BeforeEach
    void setUp() {
        testAuthor = new Author(1, "Gabriel", "Garcia Marquez", "Colombian", null);
        testAuthorDTO = new AuthorDTO(1, "Gabriel", "Garcia Marquez", "Colombian");
    }

    @Test
    @DisplayName("Should get all authors successfully")
    void shouldGetAllAuthors_whenAuthorsExist() throws Exception {
        // Arrange
        List<Author> authors = Arrays.asList(testAuthor);
        when(authorService.findAll()).thenReturn(authors);
        when(modelMapper.map(any(Author.class), eq(AuthorDTO.class))).thenReturn(testAuthorDTO);

        // Act & Assert
        mockMvc.perform(get("/authors")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(200))
                .andExpect(jsonPath("$.message").value("success"))
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.data", hasSize(1)))
                .andExpect(jsonPath("$.data[0].idAuthor").value(1))
                .andExpect(jsonPath("$.data[0].firstName").value("Gabriel"))
                .andExpect(jsonPath("$.data[0].lastName").value("Garcia Marquez"))
                .andExpect(jsonPath("$.data[0].nationality").value("Colombian"));

        verify(authorService, times(1)).findAll();
    }

    @Test
    @DisplayName("Should get author by id successfully")
    void shouldGetAuthorById_whenAuthorExists() throws Exception {
        // Arrange
        when(authorService.findById(anyInt())).thenReturn(testAuthor);
        when(modelMapper.map(any(Author.class), eq(AuthorDTO.class))).thenReturn(testAuthorDTO);

        // Act & Assert
        mockMvc.perform(get("/authors/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(200))
                .andExpect(jsonPath("$.message").value("success"))
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.data", hasSize(1)))
                .andExpect(jsonPath("$.data[0].idAuthor").value(1))
                .andExpect(jsonPath("$.data[0].firstName").value("Gabriel"));

        verify(authorService, times(1)).findById(1);
    }

    @Test
    @DisplayName("Should return 404 when author not found by id")
    void shouldReturn404_whenAuthorNotFoundById() throws Exception {
        // Arrange
        when(authorService.findById(anyInt())).thenThrow(new ModelNotFoundException("ID NOT FOUND: 999"));

        // Act & Assert
        mockMvc.perform(get("/authors/999")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        verify(authorService, times(1)).findById(999);
    }

    @Test
    @DisplayName("Should create author successfully with valid data")
    void shouldCreateAuthor_whenValidAuthorProvided() throws Exception {
        // Arrange
        when(modelMapper.map(any(AuthorDTO.class), eq(Author.class))).thenReturn(testAuthor);
        when(authorService.save(any(Author.class))).thenReturn(testAuthor);

        // Act & Assert
        mockMvc.perform(post("/authors")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(testAuthorDTO)))
                .andExpect(status().isCreated())
                .andExpect(header().exists("Location"))
                .andExpect(header().string("Location", containsString("/authors/1")));

        verify(authorService, times(1)).save(any(Author.class));
    }

    @Test
    @DisplayName("Should return 400 when creating author with blank firstName")
    void shouldReturn400_whenCreatingAuthorWithBlankFirstName() throws Exception {
        // Arrange
        AuthorDTO invalidAuthorDTO = new AuthorDTO(null, "", "Garcia Marquez", "Colombian");

        // Act & Assert
        mockMvc.perform(post("/authors")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(invalidAuthorDTO)))
                .andExpect(status().isBadRequest());

        verify(authorService, never()).save(any(Author.class));
    }

    @Test
    @DisplayName("Should return 400 when creating author with null lastName")
    void shouldReturn400_whenCreatingAuthorWithNullLastName() throws Exception {
        // Arrange
        AuthorDTO invalidAuthorDTO = new AuthorDTO(null, "Gabriel", null, "Colombian");

        // Act & Assert
        mockMvc.perform(post("/authors")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(invalidAuthorDTO)))
                .andExpect(status().isBadRequest());

        verify(authorService, never()).save(any(Author.class));
    }

    @Test
    @DisplayName("Should return 400 when creating author with firstName too short")
    void shouldReturn400_whenCreatingAuthorWithFirstNameTooShort() throws Exception {
        // Arrange
        AuthorDTO invalidAuthorDTO = new AuthorDTO(null, "G", "Garcia Marquez", "Colombian");

        // Act & Assert
        mockMvc.perform(post("/authors")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(invalidAuthorDTO)))
                .andExpect(status().isBadRequest());

        verify(authorService, never()).save(any(Author.class));
    }

    @Test
    @DisplayName("Should update author successfully")
    void shouldUpdateAuthor_whenValidAuthorProvided() throws Exception {
        // Arrange
        Author updatedAuthor = new Author(1, "Gabriel Jose", "Garcia Marquez", "Colombian", null);
        AuthorDTO updatedAuthorDTO = new AuthorDTO(1, "Gabriel Jose", "Garcia Marquez", "Colombian");

        when(modelMapper.map(any(AuthorDTO.class), eq(Author.class))).thenReturn(updatedAuthor);
        when(authorService.update(anyInt(), any(Author.class))).thenReturn(updatedAuthor);
        when(modelMapper.map(any(Author.class), eq(AuthorDTO.class))).thenReturn(updatedAuthorDTO);

        // Act & Assert
        mockMvc.perform(put("/authors/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updatedAuthorDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(200))
                .andExpect(jsonPath("$.message").value("success"))
                .andExpect(jsonPath("$.data[0].firstName").value("Gabriel Jose"))
                .andExpect(jsonPath("$.data[0].lastName").value("Garcia Marquez"));

        verify(authorService, times(1)).update(eq(1), any(Author.class));
    }

    @Test
    @DisplayName("Should return 404 when updating non-existent author")
    void shouldReturn404_whenUpdatingNonExistentAuthor() throws Exception {
        // Arrange
        when(modelMapper.map(any(AuthorDTO.class), eq(Author.class))).thenReturn(testAuthor);
        when(authorService.update(anyInt(), any(Author.class)))
                .thenThrow(new ModelNotFoundException("ID NOT FOUND: 999"));

        // Act & Assert
        mockMvc.perform(put("/authors/999")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(testAuthorDTO)))
                .andExpect(status().isNotFound());

        verify(authorService, times(1)).update(eq(999), any(Author.class));
    }

    @Test
    @DisplayName("Should delete author successfully")
    void shouldDeleteAuthor_whenAuthorExists() throws Exception {
        // Arrange
        doNothing().when(authorService).delete(anyInt());

        // Act & Assert
        mockMvc.perform(delete("/authors/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        verify(authorService, times(1)).delete(1);
    }

    @Test
    @DisplayName("Should return 404 when deleting non-existent author")
    void shouldReturn404_whenDeletingNonExistentAuthor() throws Exception {
        // Arrange
        doThrow(new ModelNotFoundException("ID NOT FOUND: 999"))
                .when(authorService).delete(anyInt());

        // Act & Assert
        mockMvc.perform(delete("/authors/999")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        verify(authorService, times(1)).delete(999);
    }

    @Test
    @DisplayName("Should return empty list when no authors exist")
    void shouldReturnEmptyList_whenNoAuthorsExist() throws Exception {
        // Arrange
        when(authorService.findAll()).thenReturn(Arrays.asList());

        // Act & Assert
        mockMvc.perform(get("/authors")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(200))
                .andExpect(jsonPath("$.message").value("success"))
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.data", hasSize(0)));

        verify(authorService, times(1)).findAll();
    }

    @Test
    @DisplayName("Should create author successfully without nationality")
    void shouldCreateAuthor_whenNationalityIsNull() throws Exception {
        // Arrange
        AuthorDTO authorWithoutNationality = new AuthorDTO(null, "John", "Doe", null);
        Author authorEntity = new Author(2, "John", "Doe", null, null);

        when(modelMapper.map(any(AuthorDTO.class), eq(Author.class))).thenReturn(authorEntity);
        when(authorService.save(any(Author.class))).thenReturn(authorEntity);

        // Act & Assert
        mockMvc.perform(post("/authors")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(authorWithoutNationality)))
                .andExpect(status().isCreated())
                .andExpect(header().exists("Location"));

        verify(authorService, times(1)).save(any(Author.class));
    }
}
