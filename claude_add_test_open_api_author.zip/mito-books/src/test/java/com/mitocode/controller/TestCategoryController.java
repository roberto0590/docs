package com.mitocode.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mitocode.dto.CategoryDTO;
import com.mitocode.exception.ModelNotFoundException;
import com.mitocode.model.Category;
import com.mitocode.service.ICategoryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(CategoryController.class)
@DisplayName("CategoryController Integration Tests")
class TestCategoryController {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private ICategoryService categoryService;

    @MockBean(name = "defaultMapper")
    private ModelMapper modelMapper;

    private Category testCategory;
    private CategoryDTO testCategoryDTO;

    @BeforeEach
    void setUp() {
        testCategory = new Category(1, "Fiction", true);
        testCategoryDTO = new CategoryDTO(1, "Fiction", true);
    }

    @Test
    @DisplayName("Should get all categories successfully")
    void shouldGetAllCategories_whenCategoriesExist() throws Exception {
        // Arrange
        List<Category> categories = Arrays.asList(testCategory);
        when(categoryService.findAll()).thenReturn(categories);
        when(modelMapper.map(any(Category.class), eq(CategoryDTO.class))).thenReturn(testCategoryDTO);

        // Act & Assert
        mockMvc.perform(get("/categories")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(200))
                .andExpect(jsonPath("$.message").value("success"))
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.data", hasSize(1)))
                .andExpect(jsonPath("$.data[0].idCategory").value(1))
                .andExpect(jsonPath("$.data[0].categoryName").value("Fiction"))
                .andExpect(jsonPath("$.data[0].status").value(true));

        verify(categoryService, times(1)).findAll();
    }

    @Test
    @DisplayName("Should get category by id successfully")
    void shouldGetCategoryById_whenCategoryExists() throws Exception {
        // Arrange
        when(categoryService.findById(anyInt())).thenReturn(testCategory);
        when(modelMapper.map(any(Category.class), eq(CategoryDTO.class))).thenReturn(testCategoryDTO);

        // Act & Assert
        mockMvc.perform(get("/categories/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(200))
                .andExpect(jsonPath("$.message").value("success"))
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.data", hasSize(1)))
                .andExpect(jsonPath("$.data[0].idCategory").value(1))
                .andExpect(jsonPath("$.data[0].categoryName").value("Fiction"));

        verify(categoryService, times(1)).findById(1);
    }

    @Test
    @DisplayName("Should return 404 when category not found by id")
    void shouldReturn404_whenCategoryNotFoundById() throws Exception {
        // Arrange
        when(categoryService.findById(anyInt())).thenThrow(new ModelNotFoundException("ID NOT FOUND: 999"));

        // Act & Assert
        mockMvc.perform(get("/categories/999")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        verify(categoryService, times(1)).findById(999);
    }

    @Test
    @DisplayName("Should create category successfully")
    void shouldCreateCategory_whenValidCategoryProvided() throws Exception {
        // Arrange
        when(modelMapper.map(any(CategoryDTO.class), eq(Category.class))).thenReturn(testCategory);
        when(categoryService.save(any(Category.class))).thenReturn(testCategory);

        // Act & Assert
        mockMvc.perform(post("/categories")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(testCategoryDTO)))
                .andExpect(status().isCreated())
                .andExpect(header().exists("Location"))
                .andExpect(header().string("Location", containsString("/categories/1")));

        verify(categoryService, times(1)).save(any(Category.class));
    }

    @Test
    @DisplayName("Should update category successfully")
    void shouldUpdateCategory_whenValidCategoryProvided() throws Exception {
        // Arrange
        Category updatedCategory = new Category(1, "Science Fiction", true);
        CategoryDTO updatedCategoryDTO = new CategoryDTO(1, "Science Fiction", true);

        when(modelMapper.map(any(CategoryDTO.class), eq(Category.class))).thenReturn(updatedCategory);
        when(categoryService.update(anyInt(), any(Category.class))).thenReturn(updatedCategory);
        when(modelMapper.map(any(Category.class), eq(CategoryDTO.class))).thenReturn(updatedCategoryDTO);

        // Act & Assert
        mockMvc.perform(put("/categories/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updatedCategoryDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(200))
                .andExpect(jsonPath("$.message").value("success"))
                .andExpect(jsonPath("$.data[0].categoryName").value("Science Fiction"));

        verify(categoryService, times(1)).update(eq(1), any(Category.class));
    }

    @Test
    @DisplayName("Should return 404 when updating non-existent category")
    void shouldReturn404_whenUpdatingNonExistentCategory() throws Exception {
        // Arrange
        when(modelMapper.map(any(CategoryDTO.class), eq(Category.class))).thenReturn(testCategory);
        when(categoryService.update(anyInt(), any(Category.class)))
                .thenThrow(new ModelNotFoundException("ID NOT FOUND: 999"));

        // Act & Assert
        mockMvc.perform(put("/categories/999")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(testCategoryDTO)))
                .andExpect(status().isNotFound());

        verify(categoryService, times(1)).update(eq(999), any(Category.class));
    }

    @Test
    @DisplayName("Should delete category successfully")
    void shouldDeleteCategory_whenCategoryExists() throws Exception {
        // Arrange
        doNothing().when(categoryService).delete(anyInt());

        // Act & Assert
        mockMvc.perform(delete("/categories/1")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        verify(categoryService, times(1)).delete(1);
    }

    @Test
    @DisplayName("Should return 404 when deleting non-existent category")
    void shouldReturn404_whenDeletingNonExistentCategory() throws Exception {
        // Arrange
        doThrow(new ModelNotFoundException("ID NOT FOUND: 999"))
                .when(categoryService).delete(anyInt());

        // Act & Assert
        mockMvc.perform(delete("/categories/999")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        verify(categoryService, times(1)).delete(999);
    }

    @Test
    @DisplayName("Should return empty list when no categories exist")
    void shouldReturnEmptyList_whenNoCategoriesExist() throws Exception {
        // Arrange
        when(categoryService.findAll()).thenReturn(Arrays.asList());

        // Act & Assert
        mockMvc.perform(get("/categories")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value(200))
                .andExpect(jsonPath("$.message").value("success"))
                .andExpect(jsonPath("$.data").isArray())
                .andExpect(jsonPath("$.data", hasSize(0)));

        verify(categoryService, times(1)).findAll();
    }
}
