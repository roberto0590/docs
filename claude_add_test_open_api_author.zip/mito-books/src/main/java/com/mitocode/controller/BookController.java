package com.mitocode.controller;

import com.mitocode.dto.BookDTO;
import com.mitocode.dto.GenericResponse;
import com.mitocode.model.Author;
import com.mitocode.model.Book;
import com.mitocode.model.Category;
import com.mitocode.service.IAuthorService;
import com.mitocode.service.IBookService;
import com.mitocode.service.ICategoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.Arrays;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/books")
@RequiredArgsConstructor
@Tag(name = "Books", description = "Book management API for managing bookstore inventory")
public class BookController {

    private final IBookService service;
    private final ICategoryService categoryService;
    private final IAuthorService authorService;

    @Qualifier("bookMapper")
    private final ModelMapper modelMapper;

    @Operation(summary = "Get all books", description = "Retrieves a list of all books in the inventory")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved list of books",
                    content = @Content(mediaType = "application/json", schema = @Schema(implementation = GenericResponse.class))),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json"))
    })
    @GetMapping
    public ResponseEntity<GenericResponse<BookDTO>> getAllBooks() {
        log.info("Fetching all books");
        List<BookDTO> list = service.findAll().stream().map(this::convertToDto).toList();
        log.info("Successfully retrieved {} books", list.size());

        return ResponseEntity.ok(new GenericResponse<>(200, "success", list));
    }

    @Operation(summary = "Get book by ID", description = "Retrieves a specific book by its unique identifier")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved book",
                    content = @Content(mediaType = "application/json", schema = @Schema(implementation = GenericResponse.class))),
            @ApiResponse(responseCode = "404", description = "Book not found",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json"))
    })
    @GetMapping("/{id}")
    public ResponseEntity<GenericResponse<BookDTO>> getBookById(
            @Parameter(description = "ID of the book to retrieve", required = true, example = "1")
            @PathVariable("id") Integer id) {
        log.info("Fetching book with ID: {}", id);
        Book obj = service.findById(id);
        log.info("Successfully retrieved book with ID: {}", id);

        return ResponseEntity.ok(new GenericResponse<>(200, "success", Arrays.asList(convertToDto(obj))));
    }

    @Operation(summary = "Create a new book", description = "Creates a new book in the inventory and returns the location in the response header")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Book created successfully",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "400", description = "Invalid input - validation failed",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json"))
    })
    @PostMapping
    public ResponseEntity<Void> save(
            @Parameter(description = "Book data to create", required = true)
            @Valid @RequestBody BookDTO dto) {
        log.info("Creating new book with title: {}", dto.getTitle());
        Book obj = service.save(convertToEntity(dto));
        log.info("Successfully created book with ID: {}", obj.getIdBook());

        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdBook()).toUri();

        return ResponseEntity.created(location).build();
    }

    @Operation(summary = "Update a book", description = "Updates an existing book by ID and returns the updated data")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Book updated successfully",
                    content = @Content(mediaType = "application/json", schema = @Schema(implementation = GenericResponse.class))),
            @ApiResponse(responseCode = "400", description = "Invalid input - validation failed",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "404", description = "Book not found",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json"))
    })
    @PutMapping("/{id}")
    public ResponseEntity<GenericResponse<BookDTO>> update(
            @Parameter(description = "ID of the book to update", required = true, example = "1")
            @PathVariable("id") Integer id,
            @Parameter(description = "Updated book data", required = true)
            @Valid @RequestBody BookDTO dto) {
        log.info("Updating book with ID: {}", id);
        //client.setIdBook(id);
        Book obj = service.update(id, convertToEntity(dto));
        log.info("Successfully updated book with ID: {}", id);

        return ResponseEntity.ok(new GenericResponse<>(200, "success", Arrays.asList(convertToDto(obj))));
    }

    @Operation(summary = "Delete a book", description = "Deletes a book by ID from the inventory")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Book deleted successfully",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "Book not found",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json"))
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(
            @Parameter(description = "ID of the book to delete", required = true, example = "1")
            @PathVariable("id") Integer id) {
        log.info("Deleting book with ID: {}", id);
        service.delete(id);
        log.info("Successfully deleted book with ID: {}", id);

        return ResponseEntity.noContent().build();
    }

    @Operation(summary = "Get books by category", description = "Retrieves all books belonging to a specific category")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved books for category",
                    content = @Content(mediaType = "application/json", schema = @Schema(implementation = GenericResponse.class))),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json"))
    })
    @GetMapping("/byCategory")
    public ResponseEntity<GenericResponse<BookDTO>> getBooksByCategory(
            @Parameter(description = "Name of the category to filter books", required = true, example = "Fiction")
            @RequestParam("category") String category) {
        log.info("Fetching books by category: {}", category);
        List<BookDTO> books = service.getBooksByCategory(category).stream().map(this::convertToDto).toList();
        log.info("Successfully retrieved {} books for category: {}", books.size(), category);

        return ResponseEntity.ok(new GenericResponse<>(200, "success", books));
    }

    private BookDTO convertToDto(Book obj) {
        return modelMapper.map(obj, BookDTO.class);
    }

    private Book convertToEntity(BookDTO dto) {
        Book book = modelMapper.map(dto, Book.class);

        // Set Category and Author from IDs
        Category category = categoryService.findById(dto.getIdCategory());
        Author author = authorService.findById(dto.getIdAuthor());

        book.setCategory(category);
        book.setAuthor(author);

        return book;
    }

}
