package com.mitocode.controller;

import com.mitocode.dto.AuthorDTO;
import com.mitocode.dto.GenericResponse;
import com.mitocode.model.Author;
import com.mitocode.service.IAuthorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.Arrays;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/authors")
@RequiredArgsConstructor
@Tag(name = "Authors", description = "Author management API for managing book authors")
public class AuthorController {

    private final IAuthorService service;

    @Qualifier("defaultMapper")
    private final ModelMapper modelMapper;

    @Operation(summary = "Get all authors", description = "Retrieves a list of all authors in the system")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved list of authors",
                    content = @Content(mediaType = "application/json", schema = @Schema(implementation = GenericResponse.class))),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json"))
    })
    @GetMapping
    public ResponseEntity<GenericResponse<AuthorDTO>> getAllAuthors() {
        log.info("logs mito Fetching all authors");
        List<AuthorDTO> list = service.findAll().stream().map(this::convertToDto).toList();
        log.info("logs mito Successfully retrieved {} authors", list.size());

        return ResponseEntity.ok(new GenericResponse<>(200, "success", list));
    }

    @Operation(summary = "Get author by ID", description = "Retrieves a specific author by their unique identifier")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved author",
                    content = @Content(mediaType = "application/json", schema = @Schema(implementation = GenericResponse.class))),
            @ApiResponse(responseCode = "404", description = "Author not found",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json"))
    })
    @GetMapping("/{id}")
    public ResponseEntity<GenericResponse<AuthorDTO>> getAuthorById(
            @Parameter(description = "ID of the author to retrieve", required = true, example = "1")
            @PathVariable("id") Integer id) {
        log.info("mito log Fetching author with ID: {}", id);
        Author obj = service.findById(id);
        log.info("mito log Successfully retrieved author with ID: {}", id);

        return ResponseEntity.ok(new GenericResponse<>(200, "success", Arrays.asList(convertToDto(obj))));
    }

    @Operation(summary = "Create a new author", description = "Creates a new author and returns the location in the response header")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Author created successfully",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "400", description = "Invalid input - validation failed",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json"))
    })
    @PostMapping
    public ResponseEntity<Void> save(
            @Parameter(description = "Author data to create", required = true)
            @Valid @RequestBody AuthorDTO dto) {
        log.info("Creating new author with name: {}", dto.getFirstName());
        Author obj = service.save(convertToEntity(dto));
        log.info("Successfully created author with ID: {}", obj.getIdAuthor());

        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdAuthor()).toUri();

        return ResponseEntity.created(location).build();
    }

    @Operation(summary = "Update an author", description = "Updates an existing author by ID and returns the updated data")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Author updated successfully",
                    content = @Content(mediaType = "application/json", schema = @Schema(implementation = GenericResponse.class))),
            @ApiResponse(responseCode = "400", description = "Invalid input - validation failed",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "404", description = "Author not found",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json"))
    })
    @PutMapping("/{id}")
    public ResponseEntity<GenericResponse<AuthorDTO>> update(
            @Parameter(description = "ID of the author to update", required = true, example = "1")
            @PathVariable("id") Integer id,
            @Parameter(description = "Updated author data", required = true)
            @Valid @RequestBody AuthorDTO dto) {
        log.info("Updating author with ID: {}", id);
        Author obj = service.update(id, convertToEntity(dto));
        log.info("Successfully updated author with ID: {}", id);

        return ResponseEntity.ok(new GenericResponse<>(200, "success", Arrays.asList(convertToDto(obj))));
    }

    @Operation(summary = "Delete an author", description = "Deletes an author by ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Author deleted successfully",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "Author not found",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json"))
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(
            @Parameter(description = "ID of the author to delete", required = true, example = "1")
            @PathVariable("id") Integer id) {
        log.info("Deleting author with ID: {}", id);
        service.delete(id);
        log.info("Successfully deleted author with ID: {}", id);

        return ResponseEntity.noContent().build();
    }

    private AuthorDTO convertToDto(Author obj) {
        return modelMapper.map(obj, AuthorDTO.class);
    }

    private Author convertToEntity(AuthorDTO dto) {
        return modelMapper.map(dto, Author.class);
    }
}
