package com.mitocode.controller;

import com.mitocode.dto.GenericResponse;
import com.mitocode.dto.SaleDTO;
import com.mitocode.model.Sale;
import com.mitocode.service.ISaleService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/sales")
@RequiredArgsConstructor
@Tag(name = "Sales", description = "Sales management API for handling book purchases and transactions")
public class SaleController {

    private final ISaleService service;
    @Qualifier("saleMapper")
    private final ModelMapper modelMapper;

    @Operation(summary = "Get all sales", description = "Retrieves a list of all sales transactions")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved list of sales",
                    content = @Content(mediaType = "application/json", schema = @Schema(implementation = GenericResponse.class))),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json"))
    })
    @GetMapping
    public ResponseEntity<GenericResponse<SaleDTO>> getAllSales() {
        List<SaleDTO> list = service.findAll().stream().map(this::convertToDto).toList();

        return ResponseEntity.ok(new GenericResponse<>(200, "success", list));
    }

    @Operation(summary = "Get sale by ID", description = "Retrieves a specific sale transaction by its unique identifier")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved sale",
                    content = @Content(mediaType = "application/json", schema = @Schema(implementation = GenericResponse.class))),
            @ApiResponse(responseCode = "404", description = "Sale not found",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json"))
    })
    @GetMapping("/{id}")
    public ResponseEntity<GenericResponse<SaleDTO>> getSaleById(
            @Parameter(description = "ID of the sale to retrieve", required = true, example = "1")
            @PathVariable("id") Integer id) {
        Sale obj = service.findById(id);

        return ResponseEntity.ok(new GenericResponse<>(200, "success", Arrays.asList(convertToDto(obj))));
    }

    @Operation(summary = "Create a new sale", description = "Creates a new sale transaction with client and sale details, returns the location in the response header")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Sale created successfully",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "400", description = "Invalid input - validation failed",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json"))
    })
    @PostMapping
    public ResponseEntity<Void> save(
            @Parameter(description = "Sale data to create including client and sale details", required = true)
            @Valid @RequestBody SaleDTO dto) {
        Sale obj = service.save(convertToEntity(dto));

        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdSale()).toUri();

        return ResponseEntity.created(location).build();
    }

    @Operation(summary = "Update a sale", description = "Updates an existing sale transaction by ID and returns the updated data")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Sale updated successfully",
                    content = @Content(mediaType = "application/json", schema = @Schema(implementation = GenericResponse.class))),
            @ApiResponse(responseCode = "400", description = "Invalid input - validation failed",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "404", description = "Sale not found",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json"))
    })
    @PutMapping("/{id}")
    public ResponseEntity<GenericResponse<SaleDTO>> update(
            @Parameter(description = "ID of the sale to update", required = true, example = "1")
            @PathVariable("id") Integer id,
            @Parameter(description = "Updated sale data", required = true)
            @Valid @RequestBody SaleDTO dto) {
        //sale.setIdSale(id);
        Sale obj = service.update(id, convertToEntity(dto));

        return ResponseEntity.ok(new GenericResponse<>(200, "success", Arrays.asList(convertToDto(obj))));
    }

    @Operation(summary = "Delete a sale", description = "Deletes a sale transaction by ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Sale deleted successfully",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "Sale not found",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json"))
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(
            @Parameter(description = "ID of the sale to delete", required = true, example = "1")
            @PathVariable("id") Integer id) {
        service.delete(id);

        return ResponseEntity.noContent().build();
    }


    private SaleDTO convertToDto(Sale obj) {
        return modelMapper.map(obj, SaleDTO.class);
    }

    private Sale convertToEntity(SaleDTO dto) {
        return modelMapper.map(dto, Sale.class);
    }

}
