package com.mitocode.controller;

import com.mitocode.dto.CategoryDTO;
import com.mitocode.dto.GenericResponse;
import com.mitocode.model.Category;
import com.mitocode.service.ICategoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/categories")
@RequiredArgsConstructor
@Tag(name = "Categories", description = "Category management API for organizing books into categories")
public class CategoryController {

    private final ICategoryService service;
    @Qualifier("defaultMapper")
    private final ModelMapper modelMapper;

    @Operation(summary = "Get all categories", description = "Retrieves a list of all book categories")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved list of categories",
                    content = @Content(mediaType = "application/json", schema = @Schema(implementation = GenericResponse.class))),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json"))
    })
    @GetMapping
    public ResponseEntity<GenericResponse<CategoryDTO>> getAllCategories() {
        //ModelMapper modelMapper = new ModelMapper();
        List<CategoryDTO> list = service.findAll().stream().map(this::convertToDto).toList(); //e -> convertToDto(e)
        //List<CategoryDTO> list = service.findAll().stream().map(e -> modelMapper.map(e, CategoryDTO.class)).toList();}
        //List<CategoryDTO> list = service.findAll().stream().map(e -> new CategoryDTO(e.getIdCategory(), e.getName(), e.isStatus())).toList();

        return ResponseEntity.ok(new GenericResponse<>(200, "success", list));
    }

    @Operation(summary = "Get category by ID", description = "Retrieves a specific category by its unique identifier")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved category",
                    content = @Content(mediaType = "application/json", schema = @Schema(implementation = GenericResponse.class))),
            @ApiResponse(responseCode = "404", description = "Category not found",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json"))
    })
    @GetMapping("/{id}")
    public ResponseEntity<GenericResponse<CategoryDTO>> getCategoryById(
            @Parameter(description = "ID of the category to retrieve", required = true, example = "1")
            @PathVariable("id") Integer id) {
        Category obj = service.findById(id);

        return ResponseEntity.ok(new GenericResponse<>(200, "success", Arrays.asList(convertToDto(obj))));
    }

    @Operation(summary = "Create a new category", description = "Creates a new book category and returns the location in the response header")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Category created successfully",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "400", description = "Invalid input - validation failed",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json"))
    })
    @PostMapping
    public ResponseEntity<Void> save(
            @Parameter(description = "Category data to create", required = true)
            @RequestBody CategoryDTO dto) {
        Category obj = service.save(convertToEntity(dto));

        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(obj.getIdCategory()).toUri();

        return ResponseEntity.created(location).build();
    }

    @Operation(summary = "Update a category", description = "Updates an existing category by ID and returns the updated data")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Category updated successfully",
                    content = @Content(mediaType = "application/json", schema = @Schema(implementation = GenericResponse.class))),
            @ApiResponse(responseCode = "400", description = "Invalid input - validation failed",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "404", description = "Category not found",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json"))
    })
    @PutMapping("/{id}")
    public ResponseEntity<GenericResponse<CategoryDTO>> update(
            @Parameter(description = "ID of the category to update", required = true, example = "1")
            @PathVariable("id") Integer id,
            @Parameter(description = "Updated category data", required = true)
            @RequestBody CategoryDTO dto) {
        //category.setIdCategory(id);
        Category obj = service.update(id, convertToEntity(dto));

        return ResponseEntity.ok(new GenericResponse<>(200, "success", Arrays.asList(convertToDto(obj))));
    }

    @Operation(summary = "Delete a category", description = "Deletes a category by ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Category deleted successfully",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "Category not found",
                    content = @Content(mediaType = "application/json")),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json"))
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(
            @Parameter(description = "ID of the category to delete", required = true, example = "1")
            @PathVariable("id") Integer id) {
        service.delete(id);

        return ResponseEntity.noContent().build();
    }


    private CategoryDTO convertToDto(Category obj) {
        return modelMapper.map(obj, CategoryDTO.class);
    }

    private Category convertToEntity(CategoryDTO dto) {
        return modelMapper.map(dto, Category.class);
    }

}
