package com.mitocode.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Data Transfer Object for Author entity")
public class AuthorDTO {

    @Schema(description = "Unique identifier of the author", example = "1", accessMode = Schema.AccessMode.READ_ONLY)
    private Integer idAuthor;

    @NotNull
    @NotBlank
    @Size(min = 2, max = 100)
    @Schema(description = "First name of the author", example = "Gabriel", requiredMode = Schema.RequiredMode.REQUIRED, minLength = 2, maxLength = 100)
    private String firstName;

    @NotNull
    @NotBlank
    @Size(min = 2, max = 100)
    @Schema(description = "Last name of the author", example = "García Márquez", requiredMode = Schema.RequiredMode.REQUIRED, minLength = 2, maxLength = 100)
    private String lastName;

    @Size(max = 50)
    @Schema(description = "Nationality of the author", example = "Colombian", maxLength = 50)
    private String nationality;
}