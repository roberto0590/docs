package com.mitocode.dto;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Data Transfer Object for Sale entity representing a complete sale transaction")
public class SaleDTO {

    @Schema(description = "Unique identifier of the sale", example = "1", accessMode = Schema.AccessMode.READ_ONLY)
    private Integer idSale;

    @NotNull
    @Schema(description = "Client who made the purchase", requiredMode = Schema.RequiredMode.REQUIRED)
    private ClientDTO client;

    @NotNull
    @Schema(description = "Date and time when the sale occurred", example = "2025-10-19T14:30:00", requiredMode = Schema.RequiredMode.REQUIRED, type = "string", format = "date-time")
    private LocalDateTime momentSale;

    @NotNull
    @Schema(description = "Total amount of the sale", example = "149.99", requiredMode = Schema.RequiredMode.REQUIRED)
    private double totalSale;

    @NotNull
    @Schema(description = "Status indicating if the sale is active/completed", example = "true", requiredMode = Schema.RequiredMode.REQUIRED)
    private boolean statusSale;

    @JsonManagedReference
    @NotNull
    @Schema(description = "List of items/books included in the sale", requiredMode = Schema.RequiredMode.REQUIRED)
    private List<SaleDetailDTO> details;
}
