package com.mitocode.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Data Transfer Object for Client entity")
public class ClientDTO {

    @Schema(description = "Unique identifier of the client", example = "1", accessMode = Schema.AccessMode.READ_ONLY)
    private Integer idClient;

    @NotNull
    //@NotEmpty
    //@NotBlank
    @Size(min = 3, max = 20)
    @Schema(description = "First name of the client", example = "John", requiredMode = Schema.RequiredMode.REQUIRED, minLength = 3, maxLength = 20)
    private String firstName;

    @NotNull
    @Size(min = 3, max = 20)
    @Schema(description = "Surname/Last name of the client", example = "Doe", requiredMode = Schema.RequiredMode.REQUIRED, minLength = 3, maxLength = 20)
    private String surname;

    @NotNull
    @Schema(description = "Birth date of the client", example = "1990-05-15", requiredMode = Schema.RequiredMode.REQUIRED, type = "string", format = "date")
    private LocalDate birthDateClient;

    /*@Email
    @Pattern(regexp = "[0-9]+")
    @Max(value = 99)
    @Min(value = 1)*/
}
