package com.mitocode.dto;

import io.swagger.v3.oas.annotations.media.Schema;

import java.util.List;

@Schema(description = "Generic wrapper for all API responses containing status, message, and data list")
public record GenericResponse<T>(
        @Schema(description = "HTTP status code", example = "200")
        int status,

        @Schema(description = "Response message indicating success or failure",
                example = "success",
                allowableValues = {"success", "failed", "not-found", "bad-request"})
        String message,

        @Schema(description = "List of response data objects (always a list, even for single items)")
        List<T> data
) {
}
