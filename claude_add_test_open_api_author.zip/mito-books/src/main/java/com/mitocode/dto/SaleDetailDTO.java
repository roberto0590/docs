package com.mitocode.dto;

import com.fasterxml.jackson.annotation.JsonBackReference;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Data Transfer Object for SaleDetail entity representing individual items in a sale")
public class SaleDetailDTO {

    //@NotNull
    @JsonBackReference
    @Schema(description = "Reference to the parent sale (hidden to prevent circular reference)")
    private SaleDTO sale;

    @NotNull
    @Schema(description = "Book included in this sale detail", requiredMode = Schema.RequiredMode.REQUIRED)
    private BookDTO book;

    @NotNull
    @Schema(description = "Unit price of the book at the time of sale", example = "29.99", requiredMode = Schema.RequiredMode.REQUIRED)
    private double unitPrice;

    @NotNull
    @Schema(description = "Quantity of books purchased", example = "2", requiredMode = Schema.RequiredMode.REQUIRED)
    private short quantity;

    @NotNull
    @Schema(description = "Status indicating if this detail is active", example = "true", requiredMode = Schema.RequiredMode.REQUIRED)
    private boolean status;
}
