package com.mitocode.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Data Transfer Object for Book entity")
public class BookDTO {

    @Schema(description = "Unique identifier of the book", example = "1", accessMode = Schema.AccessMode.READ_ONLY)
    private Integer idBook;

    @NotNull
    @Min(value = 1)
    @Max(value = 100)
    @Schema(description = "ID of the category this book belongs to", example = "5", requiredMode = Schema.RequiredMode.REQUIRED, minimum = "1", maximum = "100")
    private Integer idCategory;

    @NotNull
    @Min(value = 1)
    @Schema(description = "ID of the author who wrote this book", example = "3", requiredMode = Schema.RequiredMode.REQUIRED, minimum = "1")
    private Integer idAuthor;

    @NotNull
    @Schema(description = "Title of the book", example = "One Hundred Years of Solitude", requiredMode = Schema.RequiredMode.REQUIRED)
    private String title;

    @NotNull
    @Schema(description = "International Standard Book Number (ISBN)", example = "978-0-06-088328-7", requiredMode = Schema.RequiredMode.REQUIRED)
    private String isbn;

    @NotNull
    @Schema(description = "URL to the book cover photo", example = "https://example.com/books/solitude.jpg", requiredMode = Schema.RequiredMode.REQUIRED)
    private String photoUrl;

    @NotNull
    @Schema(description = "Status indicating if the book is active/available", example = "true", requiredMode = Schema.RequiredMode.REQUIRED)
    private boolean status;
}
