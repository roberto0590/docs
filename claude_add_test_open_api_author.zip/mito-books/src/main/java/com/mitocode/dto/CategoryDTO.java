package com.mitocode.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Data Transfer Object for Category entity")
public class CategoryDTO {

    @Schema(description = "Unique identifier of the category", example = "1", accessMode = Schema.AccessMode.READ_ONLY)
    private Integer idCategory;

    @Schema(description = "Name of the category", example = "Fiction", requiredMode = Schema.RequiredMode.REQUIRED)
    private String categoryName;

    @Schema(description = "Status indicating if the category is active", example = "true", requiredMode = Schema.RequiredMode.REQUIRED)
    private boolean status;
}
