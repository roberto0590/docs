package com.mitocode.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * OpenAPI configuration for Mito-Books API documentation.
 * Provides Swagger UI at /swagger-ui.html and OpenAPI spec at /v3/api-docs
 */
@Configuration
public class OpenAPIConfig {

    @Bean
    public OpenAPI mitoBooksOpenAPI() {
        Server localServer = new Server();
        localServer.setUrl("http://localhost:8080");
        localServer.setDescription("Local development server");

        Contact contact = new Contact();
        contact.setName("Mito-Books Development Team");
        contact.setEmail("support@mitobooks.com");
        contact.setUrl("https://mitobooks.com");

        License mitLicense = new License()
                .name("MIT License")
                .url("https://choosealicense.com/licenses/mit/");

        Info info = new Info()
                .title("Mito-Books API")
                .version("1.0.0")
                .description("REST API for managing a bookstore system with books, categories, clients, and sales. " +
                        "This API follows a layered architecture pattern with generic CRUD operations for all resources. " +
                        "All responses are wrapped in a GenericResponse object with status, message, and data fields.")
                .contact(contact)
                .license(mitLicense);

        return new OpenAPI()
                .info(info)
                .servers(List.of(localServer));
    }
}
