package com.mitocode.repo;

import com.mitocode.model.Author;

public interface IAuthorRepo extends IGenericRepo<Author, Integer> {
}
