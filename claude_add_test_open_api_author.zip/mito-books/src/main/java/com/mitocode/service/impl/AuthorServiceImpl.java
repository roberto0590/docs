package com.mitocode.service.impl;

import com.mitocode.model.Author;
import com.mitocode.repo.IAuthorRepo;
import com.mitocode.repo.IGenericRepo;
import com.mitocode.service.IAuthorService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * Service implementation for managing Author entities.
 * <p>
 * This service extends {@link CRUDImpl} to inherit standard CRUD operations
 * and implements {@link IAuthorService} to provide author-specific business logic.
 * </p>
 * <p>
 * Inherited CRUD operations include:
 * <ul>
 *   <li>{@code save(Author author)} - Persists a new author entity</li>
 *   <li>{@code update(Integer id, Author author)} - Updates an existing author</li>
 *   <li>{@code findAll()} - Retrieves all authors</li>
 *   <li>{@code findById(Integer id)} - Retrieves an author by ID</li>
 *   <li>{@code delete(Integer id)} - Deletes an author by ID</li>
 * </ul>
 * </p>
 *
 * @author MitoCode
 * @version 1.0
 * @see CRUDImpl
 * @see IAuthorService
 * @see Author
 */
@Service
@RequiredArgsConstructor
public class AuthorServiceImpl extends CRUDImpl<Author, Integer> implements IAuthorService {

    /**
     * Repository for accessing Author data from the database.
     * Injected via constructor using Lombok's @RequiredArgsConstructor.
     */
    private final IAuthorRepo repo;

    /**
     * Provides the repository instance for CRUD operations.
     * <p>
     * This method is required by the {@link CRUDImpl} abstract class to enable
     * generic CRUD operations. It returns the specific repository implementation
     * for Author entities.
     * </p>
     *
     * @return the Author repository instance used for data access operations
     */
    @Override
    protected IGenericRepo<Author, Integer> getRepo() {
        return repo;
    }
}
