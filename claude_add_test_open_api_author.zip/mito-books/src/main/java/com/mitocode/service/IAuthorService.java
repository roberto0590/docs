package com.mitocode.service;

import com.mitocode.model.Author;

public interface IAuthorService extends ICRUD<Author, Integer> {
}
