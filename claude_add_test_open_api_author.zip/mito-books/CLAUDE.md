# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Mito-Books is a Spring Boot 3.5.6 REST API application for managing a bookstore system with books, categories, clients, and sales. The application uses PostgreSQL as the database and follows a layered architecture with a generic CRUD pattern.

## Technology Stack

- Java 21
- Spring Boot 3.5.6
- Spring Data JPA with Hibernate
- PostgreSQL database
- ModelMapper for DTO conversions
- Lombok for boilerplate reduction
- Jakarta Validation for request validation
- Maven for build management
- Docker Compose for local database

## Development Commands

### Running the Application

```bash
# Start PostgreSQL via Docker Compose (runs automatically with spring-boot-docker-compose dependency)
docker compose up -d

# Run the application
mvn spring-boot:run

# Or run with Maven wrapper
./mvnw spring-boot:run
```

### Building

```bash
# Build the project
mvn clean install

# Build without tests
mvn clean install -DskipTests

# Package the application
mvn clean package
```

### Testing

```bash
# Run all tests
mvn test

# Run a specific test class
mvn test -Dtest=MitoBooksApplicationTests

# Run tests with coverage
mvn clean test
```

## Database Configuration

The application uses Docker Compose to manage PostgreSQL. Configuration is in `.env`:
- Database: `mito_books`
- User: `postgres`
- Password: `123`
- Local port: `5436` (mapped to container port `5432`)

**Important**: Hibernate is configured with `ddl-auto: create`, which drops and recreates the schema on every startup. This is suitable for development only.

## Architecture

### Layered Architecture Pattern

The codebase follows a strict 4-layer architecture:

1. **Controller Layer** (`com.mitocode.controller`)
   - REST endpoints using `@RestController`
   - All controllers return `GenericResponse<DTO>` wrapper for consistency
   - Handles HTTP request/response and DTO conversion
   - Uses `@Valid` for request validation

2. **Service Layer** (`com.mitocode.service` and `com.mitocode.service.impl`)
   - Business logic layer
   - All services extend `ICRUD<T, ID>` interface
   - Implementations extend `CRUDImpl` abstract class for standard operations
   - Works with entity objects, not DTOs

3. **Repository Layer** (`com.mitocode.repo`)
   - Data access layer using Spring Data JPA
   - All repositories extend `IGenericRepo<T, ID>` which extends `JpaRepository`
   - Uses `@NoRepositoryBean` annotation on the generic interface

4. **Model Layer** (`com.mitocode.model`)
   - JPA entities with `@Entity` annotation
   - Uses Lombok annotations (`@Data`, `@AllArgsConstructor`, `@NoArgsConstructor`)
   - Defines database structure and relationships

### Generic CRUD Pattern

The application implements a generic CRUD pattern to reduce code duplication:

- `ICRUD<T, ID>` interface defines standard operations: save, update, findAll, findById, delete
- `CRUDImpl<T, ID>` abstract class provides default implementations
- Each service extends `CRUDImpl` and overrides `getRepo()` to provide the repository
- This pattern ensures consistent behavior across all entities

Example:
```java
// Service interface
public interface IBookService extends ICRUD<Book, Integer> {}

// Service implementation
public class BookServiceImpl extends CRUDImpl<Book, Integer> implements IBookService {
    @Override
    protected IGenericRepo<Book, Integer> getRepo() {
        return repo;
    }
}
```

### DTO Mapping Strategy

The application uses ModelMapper with custom configurations defined in `MapperConfig`:

- `defaultMapper` - Standard ModelMapper bean for simple mappings
- `clientMapper` - Custom mapper for Client entity (maps `primaryName` ↔ `firstName`, `lastName` ↔ `surname`)
- `saleMapper` - Custom mapper for Sale entity with nested client mapping

Controllers use `@Qualifier` to inject the correct mapper bean. Always add custom mappings to `MapperConfig` when field names differ between entities and DTOs.

### Response Wrapper Pattern

All API responses use `GenericResponse<T>` wrapper:
```java
public class GenericResponse<T> {
    private int status;      // HTTP status code
    private String message;  // "success", "failed", "not-found", "bad-request"
    private List<T> data;    // Always a list, even for single items
}
```

### Error Handling

Global exception handling is centralized in `GlobalErrorHandler` (`@RestControllerAdvice`):
- `ModelNotFoundException` → 404 with GenericResponse wrapper
- `MethodArgumentNotValidException` → 400 with GenericResponse wrapper
- `Exception` → 500 with GenericResponse wrapper
- All errors return `CustomErrorResponse` with timestamp, message, and request details

### Domain Model Relationships

- `Sale` has many-to-one relationship with `Client`
- `Sale` has one-to-many relationship with `SaleDetail` (cascade all operations)
- `Book` has many-to-one relationship with `Category`
- All foreign keys use explicit `@ForeignKey` naming convention: `FK_{TABLE}_{REFERENCE}`

## Adding New Entities

When adding a new entity, follow this pattern:

1. Create entity in `com.mitocode.model` package with Lombok annotations
2. Create DTO in `com.mitocode.dto` with validation annotations
3. Create repository interface extending `IGenericRepo<Entity, ID>`
4. Create service interface extending `ICRUD<Entity, ID>`
5. Create service implementation extending `CRUDImpl<Entity, ID>`
6. Create controller with standard CRUD endpoints
7. If DTO field names differ from entity, add custom mapper bean in `MapperConfig`

## Package Structure

```
com.mitocode
├── config/          - Configuration beans (ModelMapper)
├── controller/      - REST controllers
├── dto/            - Data Transfer Objects
├── exception/      - Custom exceptions and error handlers
├── model/          - JPA entities
├── repo/           - Spring Data repositories
└── service/        - Business logic layer
    └── impl/       - Service implementations
```

## Important Conventions

- All repository interfaces extend `IGenericRepo<T, ID>`
- All service interfaces extend `ICRUD<T, ID>`
- All service implementations extend `CRUDImpl<T, ID>`
- Controllers return `ResponseEntity<GenericResponse<DTO>>`
- POST endpoints return 201 Created with Location header
- PUT endpoints return 200 OK with updated data
- DELETE endpoints return 204 No Content
- ID path variables are always named `{id}` and mapped to `@PathVariable("id")`
- Controllers use constructor injection via `@RequiredArgsConstructor`
- Validation errors throw `MethodArgumentNotValidException`, handled globally
- Not found errors throw `ModelNotFoundException`, handled globally
