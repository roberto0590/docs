package com.mitocode.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.ollama.OllamaChatModel;
import org.springframework.ai.ollama.api.OllamaOptions;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/chats")
@RequiredArgsConstructor
public class ChatController {

    private final OllamaChatModel ollamaChatModel;

    @GetMapping("/ollama" )
    public ResponseEntity<String> chatWithOllama(@RequestParam String text){
        ChatResponse chatResponse = ollamaChatModel.call(new Prompt(text,
                OllamaOptions.builder().model("gpt-oss:20b").temperature(0.4).build()
                ));

        String result = chatResponse.getResult().getOutput().getText();

        return ResponseEntity.ok(result);
    }
}
