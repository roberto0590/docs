export class Author{
    idAuthor: number;
    firstName: string;
    lastName: string;
    country: string;
    urlPhoto: string;
}