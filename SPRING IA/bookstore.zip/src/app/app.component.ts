import { ChangeDetectorRef, Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { ChatComponent } from './pages/chat/chat.component';
import { MatButtonModule } from '@angular/material/button';
import { LoadingService } from './services/loading.service';
import { MatToolbarModule } from '@angular/material/toolbar';
import { SpinnerComponent } from './pages/spinner/spinner.component';

@Component({
    selector: 'app-root',
    imports: [
        RouterOutlet,
        ChatComponent,
        MatButtonModule,
        MatToolbarModule,
        RouterOutlet,
        RouterLink,
        SpinnerComponent,
    ],
    templateUrl: './app.component.html',
    styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'bookstore';
  showChat: boolean = false;

  constructor(
    public loadingService: LoadingService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    // Marcar el componente para la detección de cambios después de que se haya inicializado
    this.cdr.detectChanges();
  }

  toggleChat() {
    this.showChat = !this.showChat;
  }
}
