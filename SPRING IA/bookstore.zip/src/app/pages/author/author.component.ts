import { Component } from '@angular/core';

@Component({
    selector: 'app-author',
    imports: [],
    templateUrl: './author.component.html',
    styleUrl: './author.component.css'
})
export class AuthorComponent {

}
