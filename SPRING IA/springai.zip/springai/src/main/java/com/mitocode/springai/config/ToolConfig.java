package com.mitocode.springai.config;

import com.mitocode.springai.repo.IBookRepo;
import com.mitocode.springai.service.impl.BookToolService;
import com.mitocode.springai.service.impl.MockWeatherService;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.function.FunctionToolCallback;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ToolConfig {

    @Bean
    public ToolCallback weatherFunctionInfo(){
        return FunctionToolCallback.builder("weatherFunction", new MockWeatherService())
                .description("Get the weather in location")
                .inputType(MockWeatherService.Request.class)
                .build();
    }

    @Bean
    public ToolCallback bookInfoFunction(IBookRepo repo){
        return FunctionToolCallback.builder("bookInfoFunction", new BookToolService(repo))
                .description("Get book info from book name")
                .inputType(BookToolService.Request.class)
                .build();
    }
}
