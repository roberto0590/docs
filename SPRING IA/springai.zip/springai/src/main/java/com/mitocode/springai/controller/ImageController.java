package com.mitocode.springai.controller;

import com.mitocode.springai.dto.ResponseDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.ai.image.ImagePrompt;
import org.springframework.ai.image.ImageResponse;
import org.springframework.ai.openai.OpenAiImageModel;
import org.springframework.ai.openai.OpenAiImageOptions;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/images")
@CrossOrigin(origins = "*")
@RequiredArgsConstructor
public class ImageController {

    private final OpenAiImageModel openAiImageModel;

    @GetMapping("/generate")
    public ResponseEntity<ResponseDTO<String>> generateImage(@RequestParam String param){
        ImageResponse imageResponse = openAiImageModel.call(new ImagePrompt(param,
                OpenAiImageOptions.builder()
                        .model("dall-e-3")
                        .quality("hd")
                        .N(1)
                        .height(1024)
                        .width(1024)
                        .build()
                ));

        String url = imageResponse.getResult().getOutput().getUrl();

        return ResponseEntity.ok(new ResponseDTO<>(200, "success", url));
    }

    @GetMapping("/generate/dalle2")
    public ResponseEntity<ResponseDTO<List<String>>> generateImage2(@RequestParam String param){
        ImageResponse imageResponse = openAiImageModel.call(new ImagePrompt(param,
                OpenAiImageOptions.builder()
                        .model("dall-e-2")
                        .N(3)
                        .height(256)
                        .width(256)
                        .build()
        ));

        //String url = imageResponse.getResult().getOutput().getUrl();
        List<String> images = imageResponse.getResults().stream().map(e -> e.getOutput().getUrl()).toList();

        return ResponseEntity.ok(new ResponseDTO<>(200, "success", images));
    }

    @GetMapping("/generateB64")
    public ResponseEntity<ResponseDTO<String>> generateImageB64(@RequestParam String param){
        ImageResponse imageResponse = openAiImageModel.call(new ImagePrompt(param,
                OpenAiImageOptions.builder()
                        .model("dall-e-3")
                        .quality("hd")
                        .N(1)
                        .height(1024)
                        .width(1024)
                        .responseFormat("b64_json")
                        .build()
        ));

        String b64 = imageResponse.getResult().getOutput().getB64Json();

        return ResponseEntity.ok(new ResponseDTO<>(200, "success", b64));
    }
}
