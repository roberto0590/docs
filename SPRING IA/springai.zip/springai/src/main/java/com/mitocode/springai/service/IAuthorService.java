package com.mitocode.springai.service;

import com.mitocode.springai.model.Author;

public interface IAuthorService extends ICRUD<Author, Integer>{
}
