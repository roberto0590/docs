package com.mitocode.springai.dto;

import java.util.List;

public record AuthorBook(
        String author,
        List<String> books
) {
}
