package com.mitocode.springai.controller;

import com.mitocode.springai.dto.AuthorBook;
import com.mitocode.springai.dto.AuthorBook2;
import com.mitocode.springai.dto.ResponseDTO;
import com.mitocode.springai.model.Author;
import com.mitocode.springai.util.ChatHistory;
import lombok.RequiredArgsConstructor;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.chat.memory.MessageWindowChatMemory;
import org.springframework.ai.chat.memory.repository.jdbc.JdbcChatMemoryRepository;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.ai.converter.BeanOutputConverter;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/chats")
@CrossOrigin(origins = "*")
@RequiredArgsConstructor
public class ChatController {

    private final OpenAiChatModel openAiChatModel;
    private final ChatHistory chatHistory;
    private final ChatMemory chatMemory;
    private final JdbcChatMemoryRepository chatMemoryRepository;

    @GetMapping("/generate")
    public ResponseEntity<ResponseDTO<String>> generateText(@RequestParam String message){
        //String result = openAiChatModel.call(message);
        ChatResponse chatResponse = openAiChatModel.call(new Prompt(message));
        String result = chatResponse.getResult().getOutput().getText();

        return ResponseEntity.ok(new ResponseDTO<>(200, "success", result));
    }

    @GetMapping("/generate/prompt")
    public ResponseEntity<ResponseDTO<String>> generatePrompt(@RequestParam String author, @RequestParam String bookName){
        PromptTemplate promptTemplate = new PromptTemplate("Tell me about {author} and his book {bookName} and only print 500 characters");
        Prompt prompt = promptTemplate.create(Map.of("author", author, "bookName", bookName));

        ChatResponse chatResponse = openAiChatModel.call(prompt);
        String result = chatResponse.getResult().getOutput().getText();

        return ResponseEntity.ok(new ResponseDTO<>(200, "success", result));
    }

    @GetMapping("/generate/output")
    public ResponseEntity<AuthorBook> generateOutput(@RequestParam String author){
        BeanOutputConverter<AuthorBook> outputConverter = new BeanOutputConverter<>(AuthorBook.class);

        String template = """
                Tell me book title of {author}. {format}
                """;

        PromptTemplate promptTemplate = new PromptTemplate(template);
        Prompt prompt = promptTemplate.create(Map.of("author", author, "format", outputConverter.getFormat()));

        ChatResponse chatResponse = openAiChatModel.call(prompt);
        String result = chatResponse.getResult().getOutput().getText();
        AuthorBook authorBook = outputConverter.convert(result);

        return ResponseEntity.ok(authorBook);
    }

    @GetMapping("/generate/output2")
    public ResponseEntity<AuthorBook2> generateOutput2(@RequestParam String author){
        BeanOutputConverter<AuthorBook2> outputConverter = new BeanOutputConverter<>(AuthorBook2.class);

        String template = """
                Tell me book title of {author}. {format}
                """;

        PromptTemplate promptTemplate = new PromptTemplate(template);
        Prompt prompt = promptTemplate.create(Map.of("author", author, "format", outputConverter.getFormat()));

        ChatResponse chatResponse = openAiChatModel.call(prompt);
        String result = chatResponse.getResult().getOutput().getText();

        //System.out.println(result);

        AuthorBook2 authorBook = outputConverter.convert(result);

        return ResponseEntity.ok(authorBook);
    }

    @GetMapping("/generateConversation")
    public ResponseEntity<ResponseDTO<String>> generateConversation(@RequestParam String message){
        /*List<Message> listMessage = new ArrayList<>();
        UserMessage chatMessage1 = new UserMessage("Hablemos del autor Mario Vargas Llosa");
        UserMessage chatMessage2 = new UserMessage(message);

        listMessage.add(chatMessage1);
        listMessage.add(chatMessage2);*/

        chatHistory.addMessage("1", new UserMessage(message));

        ChatResponse chatResponse = openAiChatModel.call(new Prompt(chatHistory.getAll("1"))); //new Prompt(listMessage)
        String result = chatResponse.getResult().getOutput().getText();

        return ResponseEntity.ok(new ResponseDTO<>(200, "success", result));
    }

    @GetMapping("/memory")
    public ResponseEntity<ResponseDTO<String>> memory(@RequestParam String message){
        chatMemory.add("1", List.of(new UserMessage(message)));
        ChatResponse chatResponse = openAiChatModel.call(new Prompt(chatMemory.get("1")));
        String result = chatResponse.getResult().getOutput().getText();

        return ResponseEntity.ok(new ResponseDTO<>(200, "success", result));
    }

    @GetMapping("/memoryrepo")
    public ResponseEntity<ResponseDTO<String>> memoryRepo(@RequestParam String username, @RequestParam String message){
        ChatMemory chatMemoryRepo = MessageWindowChatMemory.builder()
                .chatMemoryRepository(chatMemoryRepository)
                .maxMessages(5) //FIFO
                .build();

        chatMemoryRepo.add(username, List.of(new UserMessage(message)));
        ChatResponse chatResponse = openAiChatModel.call(new Prompt(chatMemoryRepo.get(username)));
        String result = chatResponse.getResult().getOutput().getText();

        return ResponseEntity.ok(new ResponseDTO<>(200, "success", result));
    }
}
