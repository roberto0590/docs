package com.mitocode.springai.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.content.Media;
import org.springframework.ai.image.ImagePrompt;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.ai.openai.OpenAiImageModel;
import org.springframework.ai.openai.OpenAiImageOptions;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/multis")
@RequiredArgsConstructor
public class MultiModalityController {

    private final OpenAiChatModel openAiChatModel;
    private final OpenAiImageModel openAiImageModel;

    @GetMapping
    public String multiModality(){
        ClassPathResource classPathResource = new ClassPathResource("/images/factura.jpg");

        UserMessage userMessage = UserMessage.builder()
                .text("¿Explicame que ves en esta imagen?, datallame el contenido de cada elemento")
                .media(new Media(MimeTypeUtils.IMAGE_JPEG, classPathResource))
                .build();

        ChatResponse chatResponse = openAiChatModel.call(new Prompt(List.of(userMessage)));
        String result = chatResponse.getResult().getOutput().getText();

        return result;
    }

    @GetMapping("/image")
    public String multiModalityURL() throws Exception {
        UserMessage userMessage = UserMessage.builder()
                .text("¿Explicame que ves en esta imagen? y si pertenece a una pelicula")
                .media(new Media(MimeTypeUtils.IMAGE_JPEG, new URI("https://img.europapress.es/fotoweb/fotonoticia_20220412165352_1200.jpg").toURL().toURI())).build();

        ChatResponse chatResponse = openAiChatModel.call(new Prompt(List.of(userMessage)));
        String result = chatResponse.getResult().getOutput().getText();

        return result;
    }

    @GetMapping("/image2")
    public String multiModalityURL2() throws Exception {
        UserMessage userMessage = UserMessage.builder()
                .text("Explicame que ves en cada imagen? dime si es de una pelicula e inventa una historia de ambos")
                .media(List.of(
                        new Media(MimeTypeUtils.IMAGE_JPEG, new URI("https://img.europapress.es/fotoweb/fotonoticia_20220412165352_1200.jpg").toURL().toURI()),
                        new Media(MimeTypeUtils.IMAGE_JPEG, new URI("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRkr4crv5vRotmYd78_VghLFcnM73R-9CES1g&s").toURL().toURI())
                ))
                .build();

        ChatResponse chatResponse = openAiChatModel.call(new Prompt(List.of(userMessage)));
        String result = chatResponse.getResult().getOutput().getText();

        return result;
    }

    //subiendo una imagen
    @GetMapping("/upload")
    public String multiModalityUpload(@RequestParam("image") MultipartFile imageFile) throws Exception {
        UserMessage userMessage = UserMessage.builder()
                .text("¿Explicame que ves en esta imagen? e inventa una historia")
                .media(List.of(new Media(MimeTypeUtils.IMAGE_JPEG, new ByteArrayResource(imageFile.getBytes()))))
                .build();

        ChatResponse chatResponse = openAiChatModel.call(new Prompt(List.of(userMessage)));
        String description = chatResponse.getResult().getOutput().getText();

        String url = openAiImageModel.call(new ImagePrompt("Generame una variante en tono sepia de esta imagen con esta descripcion: " + description,
                OpenAiImageOptions.builder()
                        .model("dall-e-3")
                        .quality("hd")
                        .N(1)
                        .height(1024)
                        .width(1024)
                        .build()
        )).getResult().getOutput().getUrl();

        return url;
    }
}
