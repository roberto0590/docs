package com.mitocode.springai.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.ai.chroma.vectorstore.ChromaVectorStore;
import org.springframework.ai.document.Document;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.ai.reader.ExtractedTextFormatter;
import org.springframework.ai.reader.pdf.PagePdfDocumentReader;
import org.springframework.ai.reader.pdf.config.PdfDocumentReaderConfig;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/etls")
@RequiredArgsConstructor
public class ETLController {

    private final ChromaVectorStore vectorStore;
    private final OpenAiChatModel openAiChatModel;

    @GetMapping
    public ResponseEntity<String> etlPDF(@RequestParam String message) {
        PagePdfDocumentReader pdfReader = new PagePdfDocumentReader("classpath:/pdf/const.pdf",
                PdfDocumentReaderConfig.builder()
                        .withPageTopMargin(0)
                        .withPageExtractedTextFormatter(ExtractedTextFormatter.builder()
                                .withNumberOfTopTextLinesToDelete(0)
                                .build())
                        .withPagesPerDocument(1)
                        .build());

        vectorStore.add(pdfReader.read());

        List<Document> results = vectorStore.similaritySearch(SearchRequest.builder().query(message).topK(2).build());

        String information = results.stream().map(Document::getText).collect(Collectors.joining("\n"));

        PromptTemplate promptTemplate = new PromptTemplate("Responde esta pregunta {message} con la siguiente informacion: {information}");
        Prompt prompt = promptTemplate.create(Map.of("message", message, "information", information));

        ChatResponse chatResponse = openAiChatModel.call(prompt);
        String iaResult = chatResponse.getResult().getOutput().getText();

        return ResponseEntity.ok(iaResult);

    }
}
