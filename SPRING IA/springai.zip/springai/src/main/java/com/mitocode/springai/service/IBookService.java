package com.mitocode.springai.service;

import com.mitocode.springai.model.Book;

public interface IBookService extends ICRUD<Book, Integer>{

}
