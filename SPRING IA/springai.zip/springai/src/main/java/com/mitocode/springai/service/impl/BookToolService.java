package com.mitocode.springai.service.impl;

import com.mitocode.springai.model.Book;
import com.mitocode.springai.repo.IBookRepo;
import lombok.RequiredArgsConstructor;

import java.util.List;
import java.util.function.Function;

@RequiredArgsConstructor
public class BookToolService implements Function<BookToolService.Request, BookToolService.Response> {

    private final IBookRepo repo;

    public record Request(String bookName){}
    public record Response(List<Book> books){}

    @Override
    public Response apply(Request request) {
        List<Book> books = repo.findByNameLike("%" + request.bookName() + "%");

        return new Response(books);
    }


}
