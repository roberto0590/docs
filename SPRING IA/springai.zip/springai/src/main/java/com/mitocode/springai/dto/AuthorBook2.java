package com.mitocode.springai.dto;

import com.mitocode.springai.model.Book;

import java.util.List;

public record AuthorBook2(
        String author,
        List<Book> books
) {
}
