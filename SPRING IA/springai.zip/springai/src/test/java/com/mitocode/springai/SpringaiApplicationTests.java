package com.mitocode.springai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringaiApplicationTests {

    @Test
    void contextLoads() {
    }

}
