package com.mitocode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAiDeepseekApplicationTests {

    @Test
    void contextLoads() {
    }

}
