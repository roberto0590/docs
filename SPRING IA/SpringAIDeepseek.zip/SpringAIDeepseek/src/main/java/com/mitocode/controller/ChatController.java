package com.mitocode.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.ai.deepseek.DeepSeekChatModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/chats")
@RequiredArgsConstructor
public class ChatController {

    private final DeepSeekChatModel chatModel;

    @GetMapping
    public ResponseEntity<String> chat(@RequestParam String message) {
         String result = chatModel.call(message);

         return ResponseEntity.ok(result);
    }
}
