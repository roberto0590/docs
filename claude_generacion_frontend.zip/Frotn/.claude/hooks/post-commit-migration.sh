#!/bin/bash
echo "📝 Post-commit: Updating progress..."
# Hook para actualizar progreso después de cada commit
node scripts/update-migration-progress.js 2>/dev/null || true
echo "✅ Progress updated!"
