#!/bin/bash
# Only run during migration
BRANCH=$(git branch --show-current)
[[ ! $BRANCH =~ ^migration/.* ]] && exit 0

echo "🔍 Pre-commit validation..."

# Test changed files
CHANGED=$(git diff --cached --name-only | grep -E '\.(ts|js)$')
if [ -n "$CHANGED" ]; then
  echo "🧪 Testing changed files..."
  npm run test:related $CHANGED || {
    echo "❌ Tests failed for changed files!"
    exit 1
  }
fi

echo "✅ Pre-commit validation passed!"
