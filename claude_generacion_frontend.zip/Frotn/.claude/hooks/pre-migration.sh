#!/bin/bash
echo "🔍 Pre-Migration Validation..."

# Check MVC structure
if [ ! -d "src/controllers" ] && [ ! -d "app/controllers" ]; then
  echo "❌ No controllers found. Is this an MVC project?"
  exit 1
fi

# Check git status
if ! git diff-index --quiet HEAD --; then
  echo "❌ Uncommitted changes. Commit or stash first."
  exit 1
fi

# Create backup
BACKUP_DIR=".backup/pre-migration-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_DIR"
cp -r src "$BACKUP_DIR/" 2>/dev/null || cp -r app "$BACKUP_DIR/"
echo "✅ Backup created: $BACKUP_DIR"

# Run tests if they exist
if [ -f "package.json" ] && grep -q "\"test\"" package.json; then
  echo "🧪 Running existing tests..."
  npm test || {
    echo "⚠️  Tests failing. Fix before migration or continue at your own risk."
    read -p "Continue? (y/n) " -n 1 -r
    echo
    [[ ! $REPLY =~ ^[Yy]$ ]] && exit 1
  }
fi

echo "✅ Pre-migration checks passed!"
