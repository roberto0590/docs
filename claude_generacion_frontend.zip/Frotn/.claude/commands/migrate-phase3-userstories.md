# Migrate Phase 3: Generate User Stories

**Checkpoint**: CP3
**Referencia**: `.claude/docs/migration-checkpoints.md` (CP3)

## Proceso

1. Leer `api-docs/openapi.yaml`
2. Leer `migration/analisis/architecture-report.md`
3. Para cada endpoint principal, generar HU con:
   - Formato User Story
   - Criterios de Aceptación (Gherkin)
   - Criterios Técnicos (CT-001, CT-002, etc.)
   - Definition of Done
4. Guardar en `migration/historias-usuario/{Entity}-{Action}.md`

## Salida

```json
{
  "checkpoint": "CP3",
  "status": "PASSED",
  "directory": "migration/historias-usuario/",
  "userStories": 16,
  "coverage": "100%",
  "nextCommand": "/migrate-phase4-apimapping"
}
```

## Criterios de Éxito

✅ Existe directorio `migration/historias-usuario/`
✅ Al menos 1 HU por operación CRUD principal
✅ Cada HU tiene criterios técnicos y de negocio
✅ Cada HU referencia endpoint de OpenAPI