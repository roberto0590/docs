# Swagger Command

Generate comprehensive OpenAPI 3.0 documentation for any Spring Boot REST API, regardless of architecture pattern.

## Instructions

You are now operating as a **Universal Swagger Documentation Expert** for Spring Boot applications.

This command works with **ANY architecture pattern**:
- Hexagonal Architecture (Ports & Adapters)
- MVC (Model-View-Controller)
- Layered Architecture (Controller-Service-Repository)
- Clean Architecture
- Any custom pattern with REST controllers

### Task Breakdown

Use the TodoWrite tool to create this checklist:

1. Check for existing swagger.yaml or openapi.yaml files
2. Detect project architecture pattern automatically
3. Discover all REST controllers (any pattern)
4. Extract API endpoints and operations
5. Identify all DTOs and request/response objects
6. Analyze validation constraints
7. Document error handling mechanisms
8. Generate OpenAPI schemas from all DTOs
9. Create comprehensive examples for all operations
10. Save to `.claude/tasks/swagger.yaml`
11. Validate OpenAPI 3.0.3 compliance
12. Provide integration instructions

### Discovery Phase

**Step 1: Find existing OpenAPI documentation**
```bash
find . -name "swagger.yaml" -o -name "openapi.yaml" -o -name "api-docs.yaml" -o -name "*openapi*.yaml"
```

If existing files are found, read them to understand current documentation state.

**Step 2: Extract project metadata**
```bash
cat pom.xml | grep -E "<artifactId>|<version>|<name>|<description>"
```

Extract application name and version for OpenAPI info section.

**Step 3: Read configuration files**
```bash
cat src/main/resources/application.properties 2>/dev/null || cat src/main/resources/application.yml
```

Extract:
- `server.port` (default: 8080)
- `server.servlet.context-path` (default: /)
- `spring.application.name`
- SpringDoc configuration if present

### Architecture Detection Phase

**Step 4: Auto-detect architecture pattern**

Use Glob and Grep to identify the pattern:

**Hexagonal Architecture Detection**:
```bash
find src/main/java -type d -name "domain" -o -name "application" -o -name "infrastructure"
find src/main/java -path "*/domain/port/*"
find src/main/java -path "*/infrastructure/in/rest/*"
```

**MVC Detection**:
```bash
find src/main/java -type d -name "controller" -o -name "service" -o -name "repository"
find src/main/java -path "*/controller/*Controller.java"
```

**Layered Detection**:
```bash
find src/main/java -type d -name "web" -o -name "business" -o -name "persistence"
```

**Report detected pattern**: "Detected architecture: [Hexagonal|MVC|Layered|Custom]"

### Controller Discovery Phase

**Step 5: Find ALL REST controllers**

Use multiple search patterns to catch all variations:

```bash
find src/main/java -name "*Controller.java"
find src/main/java -type f -name "*.java" | xargs grep -l "@RestController"
find src/main/java -type f -name "*.java" | xargs grep -l "@Controller"
```

For each controller found:
- Read the file completely
- Extract `@RequestMapping` base path
- Identify all HTTP method annotations (`@GetMapping`, `@PostMapping`, etc.)
- Extract path variables, query parameters, request bodies
- Identify return types and response entities

**Step 6: Identify API interfaces (if present)**

```bash
find src/main/java -name "*API.java" -o -name "*Api.java"
```

If API interfaces exist, prioritize them for documentation extraction.

### DTO Discovery Phase

**Step 7: Find all DTOs**

Use comprehensive search patterns:

```bash
find src/main/java -name "*DTO.java" -o -name "*Dto.java"
find src/main/java -name "*Request*.java"
find src/main/java -name "*Response*.java"
find src/main/java -path "*/dto/*.java"
```

For each DTO found:
- Read the complete file
- Extract field names and types
- Identify validation annotations
- Check for nested DTOs
- Look for JavaDoc comments

### Validation Analysis Phase

**Step 8: Extract validation constraints**

For each DTO, map Jakarta/Javax validation annotations:

**Common Validation Mappings**:
- `@NotNull` → `required: true` in schema
- `@NotBlank` → `minLength: 1, required: true`
- `@NotEmpty` → `minItems: 1` for arrays
- `@Size(min=x, max=y)` → `minLength: x, maxLength: y`
- `@Min(x)` → `minimum: x`
- `@Max(x)` → `maximum: x`
- `@Pattern(regexp="...")` → `pattern: "..."`
- `@Email` → `format: email`
- `@Positive` → `minimum: 1`
- `@PositiveOrZero` → `minimum: 0`
- `@Negative` → `maximum: -1`
- `@Past` → Date in the past
- `@Future` → Date in the future
- `@DecimalMin(value)` → `minimum: value`
- `@DecimalMax(value)` → `maximum: value`

### Error Handling Analysis Phase

**Step 9: Find exception handlers**

```bash
find src/main/java -name "*ErrorHandler.java" -o -name "*ExceptionHandler.java" -o -name "*ControllerAdvice.java"
```

Read the error handler and:
- Identify all `@ExceptionHandler` methods
- Map exceptions to HTTP status codes
- Extract error response structure
- Document custom error responses

**Step 10: Find domain exceptions**

```bash
find src/main/java -path "*/exception/*.java" -o -path "*/exceptions/*.java"
```

List all custom exceptions and their HTTP mappings.

### Generation Phase

**Step 11: Generate OpenAPI structure**

Create OpenAPI 3.0.3 document with:

**Info Section**:
```yaml
openapi: 3.0.3
info:
  title: [from pom.xml or application name]
  description: |
    [Auto-generated based on detected architecture]

    ## Architecture Pattern
    [Detected pattern with brief explanation]

    ## Features
    [List of main entities/controllers found]

    ## Technology Stack
    - Spring Boot [version from pom.xml]
    - Java [version from pom.xml]
    - [Other dependencies]

  version: [from pom.xml]
  contact:
    name: Development Team
```

**Servers Section**:
```yaml
servers:
  - url: http://localhost:{port}{contextPath}
    description: Local development server
    variables:
      port:
        default: '[from config or 8080]'
      contextPath:
        default: '[from config or empty]'
```

**Tags Section**:
- Generate one tag per controller or entity group
- Use descriptive names based on controller names

**Step 12: Generate paths for each endpoint**

For each controller method:

```yaml
/api/resource:
  get:
    tags:
      - [Entity Name]
    summary: [Auto-generate from method name]
    description: |
      [Detailed description]

      **Architecture Flow**:
      [Based on detected pattern]

      **Business Rules**:
      [From validation and logic analysis]

    operationId: [camelCase from method name]

    parameters:
      [Path variables and query params]

    requestBody:
      [If POST/PUT/PATCH]

    responses:
      '200':
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ResponseDTO'
            examples:
              success:
                summary: Successful response
                value:
                  [Realistic example]

      '400':
        $ref: '#/components/responses/BadRequest'

      '404':
        $ref: '#/components/responses/NotFound'

      '500':
        $ref: '#/components/responses/ServerError'
```

**Step 13: Generate schemas for all DTOs**

For each DTO:

```yaml
components:
  schemas:
    EntityDTO:
      type: object
      description: [DTO purpose]
      required:
        [Fields with @NotNull/@NotBlank]
      properties:
        fieldName:
          type: [string|integer|number|boolean|array|object]
          format: [if applicable: date, date-time, email, etc.]
          description: [Field purpose]
          minLength: [from @Size]
          maxLength: [from @Size]
          minimum: [from @Min/@DecimalMin]
          maximum: [from @Max/@DecimalMax]
          pattern: [from @Pattern]
          example: [Realistic value]
```

**Step 14: Generate reusable error responses**

```yaml
components:
  responses:
    BadRequest:
      description: Validation error
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/ErrorResponse'
          examples:
            validationError:
              [Realistic example]

    NotFound:
      description: Resource not found
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/ErrorResponse'
          examples:
            notFound:
              [Realistic example]

    ServerError:
      description: Internal server error
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/ErrorResponse'
```

**Step 15: Generate realistic examples**

For each endpoint:
- **Success examples**: Use domain-appropriate data
- **Error examples**: Show actual error response format
- **Edge cases**: Empty lists, boundary values

Example quality standards:
- Book titles: "Clean Code", "Design Patterns" (not "string")
- Dates: "2025-10-19" or "2025-10-19T10:30:00" (not "2023-01-01")
- IDs: 1, 2, 3 (not 999)
- Names: "John Doe" (not "name")
- Prices: 49.99, 25.00 (not 100)

### Output Phase

**Step 16: Create output directory**
```bash
mkdir -p .claude/tasks
```

**Step 17: Save OpenAPI document**

Write to `.claude/tasks/swagger.yaml` with:
- Valid YAML syntax
- Complete schemas
- All endpoints documented
- Realistic examples
- Validation constraints
- Error responses

### Validation Phase

**Step 18: Validate YAML syntax**
```bash
cat .claude/tasks/swagger.yaml | head -50
```

Verify:
- Valid YAML structure
- No syntax errors
- Proper indentation
- Complete sections

**Step 19: Validate OpenAPI compliance**

Check:
- OpenAPI version: 3.0.3
- Required sections present (info, paths, components)
- All `$ref` references are valid
- Examples match schemas
- HTTP status codes are valid

### Reporting Phase

**Step 20: Generate statistics**

Count and report:
- Controllers analyzed
- Endpoints documented
- DTOs converted to schemas
- Tags created
- Examples provided
- Validation constraints mapped
- Error responses documented

**Step 21: Provide integration guide**

Include instructions for:

**If SpringDoc is already configured**:
```
Your project already has SpringDoc OpenAPI configured!

Access documentation at:
- Swagger UI: http://localhost:[port]/swagger-ui.html
- OpenAPI JSON: http://localhost:[port]/v3/api-docs
- OpenAPI YAML: http://localhost:[port]/v3/api-docs.yaml

The generated static file at .claude/tasks/swagger.yaml can be used
as a backup or for external tools.
```

**If SpringDoc is NOT configured**:
```
To use this documentation, add SpringDoc to your project:

Maven (pom.xml):
<dependency>
    <groupId>org.springdoc</groupId>
    <artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
    <version>2.7.0</version>
</dependency>

Configuration (application.yml):
springdoc:
  api-docs:
    path: /v3/api-docs
    enabled: true
  swagger-ui:
    path: /swagger-ui.html
    enabled: true

Or use the static file:
1. Copy .claude/tasks/swagger.yaml to src/main/resources/static/
2. Configure swagger-ui.url=/swagger.yaml
```

## Quality Requirements

### MUST Include:
- ✅ Auto-detection of architecture pattern
- ✅ All REST endpoints regardless of location
- ✅ All DTOs from any package
- ✅ Complete request/response schemas
- ✅ All validation constraints mapped
- ✅ HTTP status codes (200, 201, 204, 400, 404, 500)
- ✅ Realistic examples for every operation
- ✅ Error response schemas with examples
- ✅ Operation IDs (camelCase)
- ✅ Tags for logical grouping
- ✅ Detailed descriptions

### MUST NOT:
- ❌ Assume specific architecture (must detect)
- ❌ Miss controllers in non-standard locations
- ❌ Skip DTOs without standard naming
- ❌ Use placeholder examples ("string", "123")
- ❌ Include internal implementation details
- ❌ Expose JPA entities directly
- ❌ Use invalid OpenAPI syntax
- ❌ Hard-code architecture-specific paths

### Architecture-Specific Handling:

**Hexagonal Architecture**:
- Document REST controllers in `infrastructure/in/rest`
- Use DTOs from `infrastructure/in/rest/dto`
- Mention use case flow in descriptions
- Explain ports and adapters concept

**MVC Architecture**:
- Document controllers from `controller` package
- Use DTOs/models from `dto` or `model` packages
- Mention service layer in descriptions
- Explain traditional MVC flow

**Custom Patterns**:
- Adapt to discovered structure
- Document whatever is found
- Explain the specific pattern used

## Output Format

**File**: `.claude/tasks/swagger.yaml`

**Structure**: OpenAPI 3.0.3 compliant YAML

**Sections**:
1. Info (with architecture description)
2. Servers (with variables)
3. Tags (per entity/controller)
4. Paths (all endpoints)
5. Components:
   - Schemas (all DTOs)
   - Responses (error responses)
   - Parameters (reusable params)

## Success Report Template

After completion, provide:

```markdown
📊 Swagger Documentation Generated Successfully!

🏗️ Architecture Detected: [Pattern Name]

📈 Documentation Statistics:
   - Controllers analyzed: [X]
   - Endpoints documented: [Y]
   - DTOs converted to schemas: [Z]
   - Tags created: [N]
   - Validation constraints mapped: [M]
   - Examples provided: [P]

📁 File Location: .claude/tasks/swagger.yaml
📏 File Size: [size]

🔍 Coverage:
   - GET endpoints: [count]
   - POST endpoints: [count]
   - PUT endpoints: [count]
   - DELETE endpoints: [count]
   - PATCH endpoints: [count]

✅ Quality Validation:
   - ✅ OpenAPI 3.0.3 compliant
   - ✅ Valid YAML syntax
   - ✅ All endpoints documented
   - ✅ Realistic examples included
   - ✅ Validation constraints mapped
   - ✅ Error responses documented

🚀 Next Steps:
[Integration instructions based on project configuration]
```

## Success Criteria

Mark task complete when:
- [ ] Architecture pattern detected and documented
- [ ] All REST controllers discovered (any location)
- [ ] All endpoints extracted and documented
- [ ] All DTOs identified and converted to schemas
- [ ] Validation constraints fully mapped
- [ ] Realistic examples provided for all operations
- [ ] Error responses documented with examples
- [ ] File saved to `.claude/tasks/swagger.yaml`
- [ ] YAML syntax validated
- [ ] OpenAPI 3.0.3 compliance verified
- [ ] Statistics reported
- [ ] Integration instructions provided
- [ ] Architecture-appropriate descriptions included

---

**Begin execution now.** Use the TodoWrite tool to track your progress through each phase.