# Migrate Phase 0: Check Project State

**Propósito**: Detectar progreso existente y validar integridad del proyecto

**Checkpoint**: CP0

**Referencia**: `.claude/docs/migration-checkpoints.md` (CHECKPOINT 0)

---

## Entrada Esperada

Ninguna (comando sin argumentos)

---

## Proceso

### 1. Leer Estado de Migración

**Archivo**: `.migration/state.json`

```typescript
Si existe .migration/state.json:
  - Leer y parsear JSON
  - Mostrar progreso por fase
  - Mostrar progreso por entidad
  - Determinar desde qué fase continuar
Sino:
  - Primera ejecución
  - Inicializar nuevo state.json
```

### 2. Validar Proyecto Spring Boot

```bash
# Verificar pom.xml
test -f pom.xml || ERROR "pom.xml no encontrado"
grep -q "spring-boot-starter-parent" pom.xml || ERROR "No es proyecto Spring Boot"
grep -q "<version>3.5.6</version>" pom.xml || ERROR "Versión Spring Boot incorrecta"
```

### 3. Validar Estructura Base

```bash
test -d src/main/java/com/mitocode || ERROR "Estructura de paquetes incorrecta"
test -d src/test/java/com/mitocode || ERROR "Directorio de tests no existe"
```

### 4. Detectar Entidades

```bash
# Buscar controllers existentes para identificar entidades
entities=$(find src/main/java -name "*Controller.java" | sed 's/Controller.java//' | xargs -n1 basename)
```

### 5. Crear Backup Incremental

```bash
timestamp=$(date +%Y-%m-%d-%H-%M-%S)
mkdir -p .backup/$timestamp

# Solo archivos que serán modificados
if [ -d src/main/java/com/mitocode/controller ]; then
  cp -r src/main/java/com/mitocode/controller .backup/$timestamp/
fi
if [ -d src/main/java/com/mitocode/service ]; then
  cp -r src/main/java/com/mitocode/service .backup/$timestamp/
fi
if [ -d src/main/java/com/mitocode/model ]; then
  cp -r src/main/java/com/mitocode/model .backup/$timestamp/
fi
```

---

## Salida Esperada

```json
{
  "checkpoint": "CP0",
  "status": "PASSED",
  "timestamp": "2025-01-15T10:30:00Z",
  "details": {
    "springBootVersion": "3.5.6",
    "javaVersion": "21",
    "previousProgress": {
      "phase1_openapi": "completed",
      "phase2_analysis": "completed",
      "phase5_migration": {
        "Category": "completed",
        "Book": "pending"
      }
    },
    "entities": ["Book", "Category", "Client", "Sale"],
    "resumeFrom": "PHASE_5_BOOK",
    "backupLocation": ".backup/2025-01-15-10-30-00/"
  },
  "nextCommand": "/migrate-phase1-openapi"
}
```

---

## Criterios de Éxito

- ✅ Existe `pom.xml` con Spring Boot 3.5.6
- ✅ Existe estructura de paquetes `src/main/java/com/mitocode`
- ✅ Backup creado en `.backup/YYYY-MM-DD-HH-mm-ss/`
- ✅ Estado guardado en `.migration/state.json`

---

## Si Falla

### Error: pom.xml no encontrado
**Acción**: ABORT - No es proyecto Maven

### Error: Versión Spring Boot incorrecta
**Acción**: Preguntar si se debe actualizar Spring Boot
**Re-intento**: Después de actualizar, volver a ejecutar CP0

### Error: Estructura de paquetes incorrecta
**Acción**: Preguntar por el paquete base
**Re-intento**: Actualizar configuración y volver a ejecutar CP0

---

## Actualización de Estado

Después de pasar el checkpoint, actualizar `.migration/state.json`:

```json
{
  "version": "1.0.0",
  "lastCheckpoint": "CP0",
  "lastUpdate": "2025-01-15T10:30:00Z",
  "checkpoints": {
    "CP0": {
      "status": "PASSED",
      "timestamp": "2025-01-15T10:30:00Z",
      "details": { ... }
    }
  },
  "config": {
    "basePackage": "com.mitocode",
    "entities": ["Book", "Category", "Client", "Sale"],
    "backupDir": ".backup/2025-01-15-10-30-00/"
  }
}
```