# Migrate Phase 4: API Mapping

**Checkpoint**: CP4
**Referencia**: `.claude/docs/migration-checkpoints.md` (CP4)

## Proceso

1. Leer `api-docs/openapi.yaml` (verdad absoluta)
2. Detectar endpoints en código actual
3. Comparar spec vs implementación
4. Generar fixtures de prueba en `api-contracts/`
5. Generar tests de contrato (`*ContractTest.java`)
6. Ejecutar tests de contrato

## Salida

```json
{
  "checkpoint": "CP4",
  "status": "PASSED",
  "contracts": 25,
  "matches": 25,
  "mismatches": 0,
  "tests": "PASSED",
  "nextCommand": "/migrate-phase5-entity"
}
```

## Criterios de Éxito

✅ Existen contratos en `api-contracts/`
✅ Existen tests de contrato
✅ Todos los tests pasan
✅ 0 mismatches entre código y spec