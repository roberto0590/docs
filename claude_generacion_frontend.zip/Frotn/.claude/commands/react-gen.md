---
description: Generates complete React frontend from Swagger/OpenAPI specification with guided setup
---

Use the Task tool with `subagent_type: "react-swagger-generator"` to generate a complete React frontend application from your Swagger/OpenAPI specification.

The agent will guide you through an interactive setup process:

1. **Swagger File Location** - Provide path to your swagger.yaml or openapi.json
2. **Design Preferences** - Choose design reference, color palette, and UI style
3. **Target Audience** - Specify who will use the app and on which devices
4. **Technology Stack** - Select UI library, state management, validation library
5. **Features** - Enable authentication, pagination, dark mode, etc.

The agent will then:
- Analyze your Swagger specification
- Extract all endpoints, schemas, and operations
- Generate TypeScript types from schemas
- Create API services for all endpoints
- Build React components (pages, forms, tables)
- Set up routing and navigation
- Apply your color palette and design preferences
- Generate complete documentation

**Output:** Complete React project in `frontend/` directory, ready to run with `npm install && npm run dev`

**Example workflow:**
```
User: /react-gen
Agent: Starting React frontend generation...
Agent: Please provide the path to your Swagger/OpenAPI file
User: .claude/tasks/03-swagger.yaml
Agent: Analyzing Swagger specification...
Agent: Found 15 endpoints across 3 entities (Books, Categories, Sales)
Agent: What UI library would you like to use? (Tailwind/Material-UI/Bootstrap/etc.)
User: Tailwind CSS
... (continues with interactive questions)
Agent: ✅ React Frontend Generated Successfully!
Agent: Navigate to frontend/ and run: npm install && npm run dev
```

**What gets generated:**
- Complete project structure (components, services, hooks, types, pages)
- TypeScript types for all Swagger schemas
- API services for all endpoints
- CRUD components for each entity
- Form validation matching Swagger constraints
- Routing configuration
- Styled components with your color palette
- Complete README and documentation
- Configuration files (package.json, tsconfig, vite.config)

**Perfect for:**
- Rapidly prototyping frontends from existing APIs
- Creating admin dashboards
- Building CRUD applications
- Generating boilerplate for new React projects
- Ensuring frontend matches backend API contract