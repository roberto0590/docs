---
name: scalar-doc
version: 2025-10-13
description: Genera documentación completa de API con Scalar, OpenAPI 3.0 y diagramas de secuencia.
---

# scalar-doc — Documentación Completa de API

```
/scalar-doc
```

## Resume

Usa el agente `document-expert` para generar documentación exhaustiva del proyecto siguiendo el patrón de Responsabilidad Única (SRP).
El agente creará interfaces API separadas, configurará Scalar UI, generará diagramas de secuencia y documentación completa.

**IMPORTANTE**: Este comando debe delegar TODO el trabajo al agente `document-expert`.

## Trabajo

### 0. Delegar al Agente Document-Expert

**ANTES DE HACER CUALQUIER COSA**, lanza el agente `document-expert` con estas instrucciones:

```
Usa el agente document-expert para ejecutar TODO el trabajo de documentación descrito a continuación.
El agente debe seguir EXACTAMENTE todos los pasos y reglas definidas en este documento.
```

### 1. Análisis del Proyecto (Ejecutado por el Agente)

1.1. **Revisar Entities PRIMERO (CRÍTICO)**
   - Busca todos los archivos `*Entity.java` o `@Entity` classes
   - Para CADA entidad, identifica la estrategia de ID:
     - `@Id + @GeneratedValue` → IDs auto-generados
     - `@Id` (sin @GeneratedValue) → IDs manuales
   - Documenta esta información para usar en DTOs

1.2. **Revisar Controllers**
   - Busca todos los archivos `*Controller.java` en el proyecto
   - Identifica todos los endpoints (GET, POST, PUT, DELETE, PATCH)
   - Analiza los DTOs utilizados en request/response

1.3. **Revisar DTOs**
   - Identifica todos los DTOs en el package `dto`
   - Verifica anotaciones de validación (@NotNull, @Size, @Min, @Max, etc.)
   - Analiza relaciones entre DTOs (nested objects)
   - **NO modifiques campos de ID existentes** - solo documéntalos según la estrategia de la entidad

1.4. **Revisar Exceptions**
   - Busca `GlobalErrorHandler` o similar
   - Identifica todas las excepciones manejadas
   - Verifica los códigos HTTP de respuesta (400, 404, 500, etc.)
   - Analiza la estructura de error responses (CustomErrorResponse, etc.)

1.5. **Revisar Configuración**
   - Lee `application.yml` o `application.properties`
   - Verifica si SpringDoc está configurado
   - Identifica el puerto de la aplicación (default: 8080)

### 2. Verificar Dependencias

2.1. **Revisar pom.xml** (Maven) o **build.gradle** (Gradle)
   - Verifica que exista `springdoc-openapi-starter-webmvc-ui`
   - Si no existe, INFORMAR al usuario que debe agregarla:
     ```xml
     <dependency>
         <groupId>org.springdoc</groupId>
         <artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
         <version>2.7.0</version>
     </dependency>
     ```

### 3. Crear Interfaces API (Patrón SRP)

Para **cada Controller** encontrado:

3.1. **Crear Interface API**
   - Ubicación: `src/main/java/{package}/api/{Entity}API.java`
   - Ejemplo: `BookController` → `com.mitocode.api.BookAPI`

3.2. **Contenido de la Interface**
   Incluir:
   - `@Tag(name, description)` con descripción completa
   - Para cada método del controller:
     - `@Operation(summary, description)` con:
       - Descripción clara del propósito
       - **Happy Path**: Explicación paso a paso del flujo exitoso
       - **Unhappy Path**: Todos los escenarios de error posibles
       - **Use Cases**: Casos de uso reales del endpoint
       - **Business Rules**: Reglas de negocio aplicables
       - **Warnings**: Advertencias importantes (soft delete, auditoría, etc.)
     - `@ApiResponses` con TODOS los códigos HTTP:
       - 200: OK (GET, PUT exitosos)
       - 201: Created (POST exitoso)
       - 204: No Content (DELETE exitoso)
       - 400: Bad Request (validación fallida)
       - 404: Not Found (recurso no encontrado)
       - 500: Internal Server Error (errores del sistema)
     - Para cada código de respuesta:
       - `@Content` con `@Schema`
       - `@ExampleObject` con JSON de ejemplo REALISTA
     - `@Parameter` para path/query params con:
       - `description`: Descripción clara
       - `required`: true/false
       - `example`: Ejemplo de valor
     - `@RequestBody` con:
       - `description`: Qué datos se esperan
       - `required`: true
       - `@Content` con `@ExampleObject` de JSON completo

3.3. **Ejemplos de Responses**
   - **Success Examples**: JSON con datos realistas del dominio
   - **Error Examples**: GenericResponse<CustomErrorResponse> con:
     - status code apropiado
     - message descriptivo
     - timestamp en formato ISO
     - path del endpoint

3.4. **Validaciones Documentadas**
   - Documenta todas las validaciones en la descripción
   - Incluye min/max, required, formato esperado

3.5. **CRÍTICO: Manejo de IDs**
   **ANTES de documentar cualquier DTO, verifica la estrategia de ID en la entidad:**

   ```java
   // Si la entidad tiene @GeneratedValue:
   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Integer idX;

   // Entonces en el DTO:
   @Schema(description = "...",
           example = "1",
           accessMode = Schema.AccessMode.READ_ONLY)
   private Integer idX;
   // Y NO incluyas idX en ejemplos de POST
   ```

   ```java
   // Si la entidad NO tiene @GeneratedValue:
   @Id
   private Integer idX;

   // Entonces en el DTO:
   @NotNull
   @Schema(description = "... (manually assigned)",
           example = "1",
           required = true)
   private Integer idX;
   // Y SÍ incluye idX en ejemplos de POST
   ```

   **REGLA DE ORO: La documentación DESCRIBE el comportamiento, NO lo cambia.**

### 4. Actualizar Controllers

Para **cada Controller**:

4.1. **Implementar Interface API**
   ```java
   @RestController
   @RequestMapping("/endpoint")
   public class EntityController implements EntityAPI {
       // Implementación
   }
   ```

4.2. **Simplificar Métodos**
   - Eliminar todas las anotaciones de documentación del controller
   - Usar solo `@Override` en cada método
   - Mantener solo la lógica de negocio
   - Controllers deben quedar limpios y legibles

4.3. **Imports**
   - Eliminar imports de `io.swagger.v3.oas.annotations.*` no necesarios
   - Agregar import de la interface API

### 5. Configurar SpringDoc

5.1. **Actualizar application.yml/properties**
   ```yaml
   springdoc:
     api-docs:
       path: /v3/api-docs
       enabled: true
     swagger-ui:
       path: /swagger-ui.html
       enabled: true
     show-actuator: false
     default-consumes-media-type: application/json
     default-produces-media-type: application/json
   ```

### 6. Crear Página Scalar UI

6.1. **Crear archivo HTML**
   - Ubicación: `src/main/resources/static/scalar.html`
   - Contenido:
     ```html
     <!DOCTYPE html>
     <html lang="es">
     <head>
         <meta charset="UTF-8">
         <meta name="viewport" content="width=device-width, initial-scale=1.0">
         <title>{Project Name} API - Scalar Documentation</title>
         <style>
             body { margin: 0; padding: 0; }
         </style>
     </head>
     <body>
         <script
             id="api-reference"
             data-url="/v3/api-docs"
             data-configuration='{"theme":"purple","layout":"modern","defaultHttpClient":{"targetKey":"javascript","clientKey":"fetch"}}'
         ></script>
         <script src="https://cdn.jsdelivr.net/npm/@scalar/api-reference"></script>
     </body>
     </html>
     ```

### 7. Generar Diagramas de Secuencia

7.1. **Crear archivo SEQUENCE_DIAGRAMS.md**
   - Ubicación: Raíz del proyecto

7.2. **Contenido a incluir**:

   **Para cada flujo principal (mínimo 3-5 flujos)**:
   - Diagrama en formato Mermaid
   - Happy Path con todos los pasos
   - Unhappy Path con manejo de errores
   - Actores involucrados (Cliente, Controller, Service, Repository, Database)
   - Notas explicativas en puntos críticos

   **Flujos mínimos a documentar**:
   - Creación de entidad principal (POST con validación)
   - Consulta por ID con manejo de 404
   - Actualización con validación y 404
   - Operación custom más compleja del dominio
   - Manejo global de excepciones (400, 404, 500)

   **Diagrama de arquitectura**:
   - Diagrama de capas (Controller → Service → Repository → DB)
   - Flujo de ModelMapper
   - Flujo de GlobalErrorHandler

   **Sección de patrones**:
   - Generic CRUD Pattern (si aplica)
   - Repository Pattern
   - DTO Pattern
   - Exception Handling Strategy

### 8. Crear Resumen de Documentación

8.1. **Crear archivo API_DOCUMENTATION_SUMMARY.md**
   - Ubicación: Raíz del proyecto

8.2. **Contenido a incluir**:

   - **URLs de acceso**:
     - Scalar UI: `http://localhost:{port}/scalar.html`
     - Swagger UI: `http://localhost:{port}/swagger-ui.html`
     - OpenAPI JSON: `http://localhost:{port}/v3/api-docs`
     - OpenAPI YAML: `http://localhost:{port}/v3/api-docs.yaml`

   - **Arquitectura de documentación**:
     - Estructura de carpetas
     - Patrón SRP aplicado
     - Beneficios de la separación

   - **Cobertura de documentación**:
     - Tabla de endpoints documentados
     - Tabla de response codes cubiertos
     - Cantidad de ejemplos incluidos

   - **Cómo usar la documentación**:
     - Pasos para iniciar la aplicación
     - Cómo acceder a Scalar UI
     - Cómo explorar endpoints
     - Cómo probar APIs

   - **Validaciones documentadas**:
     - Lista de todas las validaciones por DTO
     - Formatos esperados
     - Rangos válidos

   - **Archivos creados/modificados**:
     - Lista completa de archivos nuevos
     - Lista de archivos modificados

   - **Checklist de completitud**:
     - Verificación de que todo está documentado

   - **Próximos pasos recomendados**:
     - Para desarrolladores
     - Para el equipo
     - Mejoras futuras sugeridas

### 9. Validación Final

9.1. **Verificar separación SRP**
   - Controllers implementan interfaces API ✅
   - Interfaces tienen TODA la documentación ✅
   - Controllers solo tienen lógica de negocio ✅
   - No hay duplicación de anotaciones ✅

9.2. **Verificar cobertura**
   - Todos los endpoints documentados ✅
   - Todos los códigos HTTP documentados ✅
   - Todos los DTOs con @Schema ✅
   - Ejemplos realistas en todos los endpoints ✅
   - Happy y Unhappy paths explicados ✅

9.3. **Verificar archivos generados**
   - Interfaces API creadas ✅
   - scalar.html creado ✅
   - SEQUENCE_DIAGRAMS.md creado ✅
   - API_DOCUMENTATION_SUMMARY.md creado ✅
   - application.yml configurado ✅

### 10. Entregar Documentación al Usuario

10.1. **Mensaje Final**
   - Listar TODAS las URLs donde acceder a la documentación
   - Explicar cómo iniciar la aplicación
   - Destacar la URL principal de Scalar
   - Mencionar los archivos creados
   - Resumir mejoras implementadas

10.2. **Instrucciones de uso**
   - Comandos para compilar (si hay issues con Java version)
   - Comandos para iniciar la app
   - Pasos para verificar la documentación

## Reglas Importantes

### Prohibiciones
- ❌ NO leas archivos en `src/test` (tests no se documentan)
- ❌ NO ejecutes el trabajo manualmente (USA EL AGENTE document-expert)
- ❌ NO omitas ejemplos de response
- ❌ NO dejes endpoints sin documentar
- ❌ NO mezcles documentación con lógica en controllers
- ❌ NO agregues `accessMode = READ_ONLY` a IDs sin verificar si tienen `@GeneratedValue`
- ❌ NO cambies el comportamiento del sistema con la documentación

### Obligaciones
- ✅ SIEMPRE usa el agente document-expert (no trabajes manualmente)
- ✅ SIEMPRE crea interfaces API separadas
- ✅ SIEMPRE incluye happy y unhappy paths
- ✅ SIEMPRE usa ejemplos realistas (no "string", "123", etc.)
- ✅ SIEMPRE documenta TODOS los códigos HTTP posibles
- ✅ SIEMPRE crea la página scalar.html
- ✅ SIEMPRE genera diagramas de secuencia
- ✅ SIEMPRE crea el resumen ejecutivo
- ✅ SIEMPRE verifica que el proyecto compile

### Estándares de Calidad

**Ejemplos de Request/Response**:
- Deben usar datos del dominio del negocio
- Fechas en formato ISO (YYYY-MM-DD o YYYY-MM-DDTHH:mm:ss)
- IDs numéricos realistas (1, 2, 3... no 999)
- Strings descriptivos ("Clean Code", no "string")
- Booleanos apropiados al contexto

**Descripciones**:
- Deben ser claras y concisas
- Explicar el "qué" y el "por qué"
- Incluir contexto de negocio
- Mencionar efectos secundarios
- Advertir sobre operaciones peligrosas

**Códigos HTTP**:
- 200: Operación exitosa (GET, PUT)
- 201: Recurso creado con Location header
- 204: Operación exitosa sin contenido (DELETE)
- 400: Validación fallida o datos inválidos
- 404: Recurso no encontrado
- 500: Error del servidor (solo en GlobalErrorHandler)

## Checklist de Completitud

Antes de terminar, verificar:

- [ ] Todos los controllers tienen su interface API
- [ ] Todas las interfaces están en package `api`
- [ ] Todos los controllers implementan sus interfaces
- [ ] Todos los métodos usan @Override
- [ ] Todos los endpoints tienen @Operation completo
- [ ] Todos los endpoints tienen @ApiResponses con todos los códigos
- [ ] Todos los request/response tienen ejemplos
- [ ] Todos los parámetros tienen @Parameter
- [ ] Archivo scalar.html creado
- [ ] Archivo SEQUENCE_DIAGRAMS.md creado
- [ ] Archivo API_DOCUMENTATION_SUMMARY.md creado
- [ ] application.yml configurado
- [ ] Al menos 5 diagramas de secuencia creados
- [ ] Diagrama de arquitectura incluido
- [ ] URLs de acceso documentadas
- [ ] Instrucciones de inicio documentadas

## Salida Final

Entregar al usuario:

1. **Resumen de archivos creados** con rutas completas
2. **URL principal de Scalar**: `http://localhost:{port}/scalar.html`
3. **Todas las URLs** de documentación disponibles
4. **Comandos** para iniciar la aplicación
5. **Lista de mejoras** implementadas
6. **Estadísticas**: X endpoints, Y ejemplos, Z diagramas
7. **Siguiente paso**: Cómo verificar que todo funciona
