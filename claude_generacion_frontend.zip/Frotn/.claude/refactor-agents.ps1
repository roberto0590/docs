# Refactor all agents to add color field and update model to opus-4

$agentColors = @{
    "swagger-expert.md" = "blue"
    "scalar-expert.md" = "blue"
    "scalar-generator.md" = "blue"
    "java-hex-architect.md" = "green"
    "domain-extractor.md" = "green"
    "react-swagger-generator.md" = "green"
    "web-mockup-generator.md" = "green"
    "landing-variants-generator.md" = "green"
    "hu-reviewer.md" = "yellow"
    "migration-validator.md" = "yellow"
    "hu-generator.md" = "magenta"
    "test-generator.md" = "magenta"
    "architecture-analyzer.md" = "cyan"
    "api-mapper.md" = "cyan"
}

$agentsDir = "C:\Users\Axel\Documents\Claude code\mito-books\mito-books\.claude\agents"
Set-Location $agentsDir

$updated = 0
$errors = 0

foreach ($agent in $agentColors.Keys) {
    if (Test-Path $agent) {
        $content = Get-Content $agent -Raw
        $color = $agentColors[$agent]

        # Add color field after description
        $content = $content -replace '(description:.*?)(\r?\n)(tools:)', "`$1`$2color: $color`$2`$3"

        # Change model
        $content = $content -replace 'model: claude-sonnet-4-5', 'model: claude-opus-4'

        # Write back
        Set-Content -Path $agent -Value $content -NoNewline

        Write-Host "✓ Updated: $agent (color: $color)" -ForegroundColor Green
        $updated++
    } else {
        Write-Host "✗ NOT FOUND: $agent" -ForegroundColor Red
        $errors++
    }
}

Write-Host "`n========================================"  -ForegroundColor Cyan
Write-Host "Refactoring Complete!" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Updated: $updated agents" -ForegroundColor Green
Write-Host "Errors: $errors" -ForegroundColor $(if ($errors -gt 0) { 'Red' } else { 'Green' })
Write-Host ""
Write-Host "Color Distribution:" -ForegroundColor Yellow
Write-Host "  Blue (Documentation): 3 agents" -ForegroundColor Blue
Write-Host "  Green (Code Generators): 5 agents" -ForegroundColor Green
Write-Host "  Yellow (Validators): 2 agents" -ForegroundColor Yellow
Write-Host "  Magenta (HU/Test): 2 agents" -ForegroundColor Magenta
Write-Host "  Cyan (Analyzers): 2 agents" -ForegroundColor Cyan
