# 🏗️ Workflow de Migración MVC a Hexagonal

## Inicio Rápido

```bash
# 1. Activar output style
/output-style hexagonal-migration

# 2. Ejecutar migración completa
/migrate --with-scalar

# Eso es todo! El comando ejecuta todas las fases automáticamente.
```

## Fases del Workflow

1. **Pre-validación** - Verifica proyecto MVC válido
2. **Documentación API** - Genera OpenAPI con Scalar
3. **Análisis** - Arquitectura actual
4. **Historias de Usuario** - Con criterios técnicos y de negocio
5. **Mapeo APIs** - Contratos contra OpenAPI
6. **Migración** - Tres capas (Domain, Application, Infrastructure)
7. **Tests** - Desde criterios de aceptación
8. **Validación** - Exhaustiva de TODO

## Checkpoints

En cada fase hay un checkpoint donde puedes:
- [CONTINUAR] - Seguir a la siguiente fase
- [AJUSTAR] - Hacer cambios manuales
- [ABORTAR] - Rollback automático

## Rollback

Si algo sale mal:
```bash
# Los hooks crean backups automáticos
ls .backup/
# Restaurar manualmente si es necesario
cp -r .backup/[fecha]/src ./
```

## Hooks Instalados

- `pre-migration.sh` - Validación inicial + backup
- `post-migration.sh` - Tests + build
- `pre-commit-migration.sh` - Tests de cambios
- `post-commit-migration.sh` - Tracking de progreso

## Documentación Completa

Ver: claude_new/MASTER-GUIDE.md
