#!/bin/bash

# Opus agents
sed -i '/^description:/a color: green' domain-extractor.md
sed -i 's/model: claude-sonnet-4-5/model: claude-opus-4/' domain-extractor.md

sed -i '/^description:/a color: cyan' architecture-analyzer.md
sed -i 's/model: claude-sonnet-4-5/model: claude-opus-4/' architecture-analyzer.md

# Sonnet agents
sed -i '/^description:/a color: green' java-hex-architect.md
sed -i 's/model: .*/model: claude-sonnet-4-5/' java-hex-architect.md

sed -i '/^description:/a color: blue' swagger-expert.md
sed -i 's/model: .*/model: claude-sonnet-4-5/' swagger-expert.md

sed -i '/^description:/a color: blue' scalar-expert.md
sed -i 's/model: .*/model: claude-sonnet-4-5/' scalar-expert.md

sed -i '/^description:/a color: blue' scalar-generator.md
sed -i 's/model: .*/model: claude-sonnet-4-5/' scalar-generator.md

sed -i '/^description:/a color: green' react-swagger-generator.md
sed -i 's/model: .*/model: claude-sonnet-4-5/' react-swagger-generator.md

sed -i '/^description:/a color: magenta' hu-generator.md
sed -i 's/model: .*/model: claude-sonnet-4-5/' hu-generator.md

sed -i '/^description:/a color: magenta' test-generator.md
sed -i 's/model: .*/model: claude-sonnet-4-5/' test-generator.md

sed -i '/^description:/a color: yellow' hu-reviewer.md
sed -i 's/model: .*/model: claude-sonnet-4-5/' hu-reviewer.md

sed -i '/^description:/a color: yellow' migration-validator.md
sed -i 's/model: .*/model: claude-sonnet-4-5/' migration-validator.md

sed -i '/^description:/a color: cyan' api-mapper.md
sed -i 's/model: .*/model: claude-sonnet-4-5/' api-mapper.md

# Haiku agents
sed -i '/^description:/a color: green' web-mockup-generator.md
sed -i 's/model: .*/model: claude-haiku-4/' web-mockup-generator.md

sed -i '/^description:/a color: green' landing-variants-generator.md
sed -i 's/model: .*/model: claude-haiku-4/' landing-variants-generator.md

echo "All agents updated successfully!"
