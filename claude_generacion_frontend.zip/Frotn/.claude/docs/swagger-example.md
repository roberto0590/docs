 # Swagger Command - Practical Example

This document shows a real example of using the `/swagger` command on the mito-books project.

## Before Running

Project structure:
```
src/main/java/com/mitocode/
├── book/
│   ├── infrastructure/in/rest/
│   │   ├── controller/BookController.java
│   │   └── dto/
│   │       ├── CreateBookRequestDto.java
│   │       ├── UpdateBookRequestDto.java
│   │       └── BookResponseDto.java
│   ├── application/usecase/
│   │   ├── CreateBookUseCaseImpl.java
│   │   └── FindBookUseCaseImpl.java
│   └── domain/
│       ├── model/entity/Book.java
│       └── port/in/CreateBookUseCase.java
├── category/
│   └── infrastructure/in/rest/
│       ├── controller/CategoryController.java
│       └── dto/...
└── sale/
    └── infrastructure/in/rest/
        ├── controller/SaleController.java
        └── dto/...
```

## Example Controller

`BookController.java`:
```java
@RestController
@RequestMapping("/api/books")
@RequiredArgsConstructor
public class BookController {
    private final CreateBookUseCase createBookUseCase;
    private final FindBookUseCase findBookUseCase;
    private final UpdateBookUseCase updateBookUseCase;
    private final DeleteBookUseCase deleteBookUseCase;
    private final BookWebMapper mapper;

    @GetMapping
    public ResponseEntity<GenericResponse<List<BookResponseDto>>> findAll() {
        List<Book> books = findBookUseCase.findAll();
        List<BookResponseDto> response = books.stream()
                .map(mapper::toResponse)
                .toList();
        return ResponseEntity.ok(new GenericResponse<>(true, response));
    }

    @GetMapping("/{id}")
    public ResponseEntity<GenericResponse<BookResponseDto>> findById(@PathVariable Long id) {
        Optional<Book> book = findBookUseCase.findById(id);
        BookResponseDto response = mapper.toResponse(book.orElseThrow(
            () -> new BookNotFoundException(id)
        ));
        return ResponseEntity.ok(new GenericResponse<>(true, response));
    }

    @PostMapping
    public ResponseEntity<GenericResponse<BookResponseDto>> create(
            @Valid @RequestBody CreateBookRequestDto request) {
        CreateBookCommand command = mapper.toCommand(request);
        Book book = createBookUseCase.create(command);
        BookResponseDto response = mapper.toResponse(book);
        return ResponseEntity.ok(new GenericResponse<>(true, response));
    }

    @PutMapping("/{id}")
    public ResponseEntity<GenericResponse<BookResponseDto>> update(
            @PathVariable Long id,
            @Valid @RequestBody UpdateBookRequestDto request) {
        UpdateBookCommand command = mapper.toCommand(id, request);
        Book book = updateBookUseCase.update(command);
        BookResponseDto response = mapper.toResponse(book);
        return ResponseEntity.ok(new GenericResponse<>(true, response));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<GenericResponse<Void>> delete(@PathVariable Long id) {
        deleteBookUseCase.deleteById(id);
        return ResponseEntity.ok(new GenericResponse<>(true, null));
    }
}
```

## Example DTOs

`CreateBookRequestDto.java`:
```java
import jakarta.validation.constraints.*;

public record CreateBookRequestDto(
    @NotBlank(message = "Title is required")
    @Size(max = 200, message = "Title must not exceed 200 characters")
    String title,

    @NotNull(message = "Category ID is required")
    @Positive(message = "Category ID must be positive")
    Long categoryId,

    @NotNull(message = "Price is required")
    @Positive(message = "Price must be positive")
    BigDecimal price,

    @NotNull(message = "Stock is required")
    @PositiveOrZero(message = "Stock cannot be negative")
    Integer stock,

    @Size(max = 1000, message = "Description must not exceed 1000 characters")
    String description
) {}
```

`BookResponseDto.java`:
```java
public record BookResponseDto(
    Long id,
    String title,
    String categoryName,
    BigDecimal price,
    Integer stock,
    String description,
    LocalDateTime createdAt,
    LocalDateTime updatedAt
) {}
```

## Running the Command

```bash
/swagger
```

## Generated Output

The command analyzes the project and generates `.claude/tasks/03-swagger.yaml`:

```yaml
openapi: 3.0.3
info:
  title: Mito Books API
  description: |
    REST API for bookstore management system using Spring Boot 3.5.6 with hexagonal architecture.

    ## Features
    - Book Management
    - Category Management
    - Sales Tracking

    ## Architecture
    Hexagonal Architecture (Ports & Adapters) with:
    - Domain Layer: Business entities and rules
    - Application Layer: Use cases
    - Infrastructure Layer: REST API, JPA Persistence

  version: 1.0.0
  contact:
    name: Development Team

servers:
  - url: http://localhost:8080
    description: Local development

tags:
  - name: Books
    description: Book catalog management operations
  - name: Categories
    description: Book category operations
  - name: Sales
    description: Sales transaction operations

paths:
  /api/books:
    get:
      tags:
        - Books
      summary: Retrieve all books
      description: Returns a list of all books in the catalog
      operationId: findAllBooks
      responses:
        '200':
          description: Successful operation
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/GenericResponseListOfBookResponseDto'
              examples:
                success:
                  value:
                    success: true
                    data:
                      - id: 1
                        title: "Clean Code"
                        categoryName: "Programming"
                        price: 45.99
                        stock: 10
                        description: "A handbook of agile software craftsmanship"
                        createdAt: "2025-10-01T10:00:00"
                        updatedAt: "2025-10-01T10:00:00"
                      - id: 2
                        title: "Design Patterns"
                        categoryName: "Software Engineering"
                        price: 52.00
                        stock: 5
                        description: "Elements of reusable object-oriented software"
                        createdAt: "2025-10-02T11:00:00"
                        updatedAt: "2025-10-02T11:00:00"
        '500':
          $ref: '#/components/responses/InternalServerError'

    post:
      tags:
        - Books
      summary: Create a new book
      description: Adds a new book to the catalog
      operationId: createBook
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/CreateBookRequestDto'
            examples:
              validBook:
                value:
                  title: "Refactoring"
                  categoryId: 1
                  price: 48.50
                  stock: 15
                  description: "Improving the design of existing code"
      responses:
        '200':
          description: Book created successfully
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/GenericResponseBookResponseDto'
              examples:
                success:
                  value:
                    success: true
                    data:
                      id: 3
                      title: "Refactoring"
                      categoryName: "Programming"
                      price: 48.50
                      stock: 15
                      description: "Improving the design of existing code"
                      createdAt: "2025-10-18T14:30:00"
                      updatedAt: "2025-10-18T14:30:00"
        '400':
          $ref: '#/components/responses/BadRequest'
        '500':
          $ref: '#/components/responses/InternalServerError'

  /api/books/{id}:
    get:
      tags:
        - Books
      summary: Retrieve book by ID
      description: Returns a single book identified by its unique ID
      operationId: findBookById
      parameters:
        - name: id
          in: path
          description: Unique identifier of the book
          required: true
          schema:
            type: integer
            format: int64
            example: 1
      responses:
        '200':
          description: Book found
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/GenericResponseBookResponseDto'
        '404':
          $ref: '#/components/responses/NotFound'
        '500':
          $ref: '#/components/responses/InternalServerError'

    put:
      tags:
        - Books
      summary: Update an existing book
      description: Updates all fields of an existing book
      operationId: updateBook
      parameters:
        - name: id
          in: path
          required: true
          schema:
            type: integer
            format: int64
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/UpdateBookRequestDto'
            examples:
              update:
                value:
                  title: "Clean Code - 2nd Edition"
                  categoryId: 1
                  price: 49.99
                  stock: 20
                  description: "Updated edition with new practices"
      responses:
        '200':
          description: Book updated successfully
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/GenericResponseBookResponseDto'
        '400':
          $ref: '#/components/responses/BadRequest'
        '404':
          $ref: '#/components/responses/NotFound'
        '500':
          $ref: '#/components/responses/InternalServerError'

    delete:
      tags:
        - Books
      summary: Delete a book
      description: Permanently removes a book from the catalog
      operationId: deleteBook
      parameters:
        - name: id
          in: path
          required: true
          schema:
            type: integer
            format: int64
      responses:
        '200':
          description: Book deleted successfully
          content:
            application/json:
              schema:
                type: object
                properties:
                  success:
                    type: boolean
                    example: true
                  data:
                    type: object
                    nullable: true
                    example: null
        '404':
          $ref: '#/components/responses/NotFound'
        '500':
          $ref: '#/components/responses/InternalServerError'

components:
  schemas:
    # Generic Response Wrappers
    GenericResponseBookResponseDto:
      type: object
      properties:
        success:
          type: boolean
          example: true
        data:
          $ref: '#/components/schemas/BookResponseDto'

    GenericResponseListOfBookResponseDto:
      type: object
      properties:
        success:
          type: boolean
          example: true
        data:
          type: array
          items:
            $ref: '#/components/schemas/BookResponseDto'

    GenericResponseCustomErrorResponse:
      type: object
      properties:
        success:
          type: boolean
          example: false
        data:
          $ref: '#/components/schemas/CustomErrorResponse'

    # Error Schema
    CustomErrorResponse:
      type: object
      properties:
        timestamp:
          type: string
          format: date-time
          example: "2025-10-18T14:30:00"
        status:
          type: integer
          example: 404
        error:
          type: string
          example: "Not Found"
        message:
          type: string
          example: "Book not found with id: 999"
        path:
          type: string
          example: "/api/books/999"

    # Request DTOs
    CreateBookRequestDto:
      type: object
      required:
        - title
        - categoryId
        - price
        - stock
      properties:
        title:
          type: string
          minLength: 1
          maxLength: 200
          description: Book title
          example: "Clean Code"
        categoryId:
          type: integer
          format: int64
          minimum: 1
          description: ID of the category this book belongs to
          example: 1
        price:
          type: number
          format: double
          minimum: 0.01
          description: Book price in USD
          example: 45.99
        stock:
          type: integer
          minimum: 0
          description: Available quantity in stock
          example: 10
        description:
          type: string
          maxLength: 1000
          description: Detailed book description
          example: "A handbook of agile software craftsmanship"

    UpdateBookRequestDto:
      type: object
      required:
        - title
        - categoryId
        - price
        - stock
      properties:
        title:
          type: string
          minLength: 1
          maxLength: 200
          example: "Clean Code - Updated"
        categoryId:
          type: integer
          format: int64
          minimum: 1
          example: 1
        price:
          type: number
          format: double
          minimum: 0.01
          example: 49.99
        stock:
          type: integer
          minimum: 0
          example: 15
        description:
          type: string
          maxLength: 1000
          example: "Updated description"

    # Response DTOs
    BookResponseDto:
      type: object
      properties:
        id:
          type: integer
          format: int64
          example: 1
        title:
          type: string
          example: "Clean Code"
        categoryName:
          type: string
          example: "Programming"
        price:
          type: number
          format: double
          example: 45.99
        stock:
          type: integer
          example: 10
        description:
          type: string
          example: "A handbook of agile software craftsmanship"
        createdAt:
          type: string
          format: date-time
          example: "2025-10-01T10:00:00"
        updatedAt:
          type: string
          format: date-time
          example: "2025-10-01T10:00:00"

  responses:
    BadRequest:
      description: Invalid request data
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/GenericResponseCustomErrorResponse'
          examples:
            validationError:
              value:
                success: false
                data:
                  timestamp: "2025-10-18T14:30:00"
                  status: 400
                  error: "Bad Request"
                  message: "Validation failed: title must not be blank"
                  path: "/api/books"

    NotFound:
      description: Resource not found
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/GenericResponseCustomErrorResponse'
          examples:
            bookNotFound:
              value:
                success: false
                data:
                  timestamp: "2025-10-18T14:30:00"
                  status: 404
                  error: "Not Found"
                  message: "Book not found with id: 999"
                  path: "/api/books/999"

    InternalServerError:
      description: Internal server error
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/GenericResponseCustomErrorResponse'
```

## Console Output

```
🔍 Analyzing Spring Boot project...

📂 Project Structure Detected:
   ✓ Controllers: 3 files
   ✓ Request DTOs: 8 files
   ✓ Response DTOs: 8 files
   ✓ Exception handlers: 1 file

📊 Controllers Analysis:
   ✓ BookController → 5 endpoints
   ✓ CategoryController → 4 endpoints
   ✓ SaleController → 6 endpoints

📝 Generating OpenAPI Documentation...
   ✓ Creating info section
   ✓ Extracting server configuration
   ✓ Defining tags
   ✓ Documenting paths
   ✓ Generating schemas
   ✓ Adding validation constraints
   ✓ Including error responses
   ✓ Adding examples

✅ Swagger documentation generated successfully!

📊 Summary:
   - Controllers: 3
   - Endpoints: 15
   - Schemas: 24 (16 DTOs + 8 wrappers)
   - Tags: 3
   - Examples: 45

📁 Output: .claude/tasks/03-swagger.yaml

🔗 Integration Instructions:

1. Add Maven dependency:
   <dependency>
       <groupId>org.springdoc</groupId>
       <artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
       <version>2.3.0</version>
   </dependency>

2. Configure application.properties:
   springdoc.api-docs.path=/api-docs
   springdoc.swagger-ui.path=/swagger-ui.html

3. Access Swagger UI:
   http://localhost:8080/swagger-ui.html

✨ Documentation is ready to use!
```

## Next Steps

1. **Review the generated file**: Open `.claude/tasks/03-swagger.yaml` and review
2. **Customize descriptions**: Add business context to operation descriptions
3. **Add authentication**: If your API requires auth, uncomment security schemes
4. **Integrate with Spring Boot**: Follow the integration instructions
5. **Test in Swagger UI**: Use the interactive UI to test endpoints
6. **Version control**: Commit the file or copy to `src/main/resources/static/`

## Tips

- Re-run `/swagger` after adding new controllers or modifying DTOs
- Use the template at `.claude/tasks/03-swagger-template.yaml` as a reference
- Validate syntax at https://editor.swagger.io/
- Compare with SpringDoc auto-generated docs for accuracy