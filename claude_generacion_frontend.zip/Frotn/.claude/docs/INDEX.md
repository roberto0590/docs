# Claude Toolkit Documentation Index

Quick access to all documentation, commands, and agents available in this project.

## 📚 Available Toolkits

### Swagger/OpenAPI Documentation Toolkit
Universal solution for automatic API documentation generation supporting **ANY architecture pattern**.

**Quick Start**: Run `/swagger` in Claude Code

**Supported Architectures**:
- ✅ Hexagonal Architecture (Ports & Adapters)
- ✅ MVC (Model-View-Controller)
- ✅ Layered Architecture (Controller-Service-Repository)
- ✅ Clean Architecture
- ✅ Any custom pattern with REST controllers

**Documentation**:
- [Toolkit Overview](swagger-toolkit-readme.md) - Complete feature overview
- [Usage Guide](swagger-command-usage.md) - How to use the /swagger command
- [Practical Example](swagger-example.md) - Real-world example with mito-books

**Files**:
- Command: `.claude/commands/swagger.md` (Universal - Auto-detects architecture)
- Output: `.claude/tasks/swagger.yaml`

---

### Claude Toolkit Generator
Meta-toolkit for creating professional Claude Code agents and commands with best practices.

**Quick Start**: Run `/create-agent` or `/create-command` in Claude Code

**Documentation**:
- [Complete Guide](claude-toolkit-generator-guide.md) - Full documentation with examples

**Files**:
- Agent: `.claude/agents/claude-toolkit-generator.md`
- Command: `.claude/commands/create-agent.md`
- Command: `.claude/commands/create-command.md`

**Key Features**:
- ✅ Generates agents with proper YAML front matter
- ✅ Creates commands with TodoWrite integration
- ✅ Enforces best practices and conventions
- ✅ **NO COMMENTS RULE** - Self-explanatory code only
- ✅ Quality validation checklists
- ✅ Auto-updates INDEX.md

---

## 🤖 Available Agents

All agents are located in `.claude/agents/`

| Agent | Description | Tools |
|-------|-------------|-------|
| `claude-toolkit-generator` | Generates Claude Code agents and commands with best practices | Read, Write, Grep, Glob |
| `swagger-expert` | Generates OpenAPI 3.0 documentation | Read, Write, Grep, Glob, Bash |
| `scalar-expert` | Generates Scalar API documentation | Read, Write, Bash, Grep, Glob |
| `scalar-generator` | Generates OpenAPI documentation with Scalar | Read, Write, Bash, Grep, Glob |
| `java-hex-architect` | Implements Java 11 + Spring Boot 2.7.x with hexagonal architecture | All tools (*) |
| `domain-extractor` | Extracts domain logic and migrates to hexagonal architecture | Read, Write, Edit, Grep, Glob |
| `architecture-analyzer` | Analyzes existing MVC structure and creates migration blueprint | Read, Grep, Glob, Bash |
| `hu-generator` | Generates User Stories with business AND technical acceptance criteria | Read, Write, Grep |
| `hu-reviewer` | Validates that implemented code complies with HU criteria | Read, Grep, Glob, Bash |
| `api-mapper` | Maps and validates API contracts against OpenAPI spec | Read, Write, Grep, Glob |
| `migration-validator` | Validates that ALL migration criteria were met | Read, Bash, Grep |
| `test-generator` | Generates unit tests from HU acceptance criteria | Read, Write, Grep |
| `web-mockup-generator` | Generates complete HTML mockups with Unsplash images and responsive design | Read, Write, Bash |
| `landing-variants-generator` | Generates single HTML file with multiple design variants (tabs) for landing pages | Write, Bash |

---

## 🔧 Available Slash Commands

All commands are located in `.claude/commands/`

| Command | Description | Output |
|---------|-------------|--------|
| `/create-agent` | Create a new Claude Code agent with best practices | `.claude/agents/{name}.md` |
| `/create-command` | Create a new Claude Code slash command with best practices | `.claude/commands/{name}.md` |
| `/swagger` | Generate OpenAPI 3.0 documentation for any Spring Boot architecture | `.claude/tasks/swagger.yaml` |
| `/scalar-doc` | Generate complete API documentation with Scalar and sequence diagrams | Various files |
| `/migrate-old` | Execute complete MVC to Hexagonal migration workflow | Migration files |
| `/hexdev` | Generate complete HU with technical criteria and execute hexagonal development | Implementation files |
| `/landing-variants` | Generate single HTML file with 3 design variants (Moderno, Minimalista, Colorido) | `landing-variants.html` |

---

## 📁 Directory Structure

```
.claude/
├── agents/                    # Specialized agent configurations
│   ├── swagger-expert.md
│   ├── scalar-expert.md
│   ├── java-hex-architect.md
│   ├── domain-extractor.md
│   ├── architecture-analyzer.md
│   ├── hu-generator.md
│   ├── hu-reviewer.md
│   ├── api-mapper.md
│   ├── migration-validator.md
│   └── test-generator.md
│
├── commands/                  # Slash command definitions
│   ├── swagger.md
│   ├── scalar-doc.md
│   ├── migrate-old.md
│   └── hexdev.md
│
├── tasks/                     # Output and template files
│   ├── 03-swagger-template.yaml
│   └── 03-swagger.yaml       # Generated by /swagger
│
├── docs/                      # Documentation
│   ├── INDEX.md              # This file
│   ├── swagger-toolkit-readme.md
│   ├── swagger-command-usage.md
│   └── swagger-example.md
│
├── hooks/                     # Event hooks
├── output-styles/             # Custom output formatting
└── workflows/                 # Multi-step workflows
```

---

## 🚀 Quick Reference

### Create New Agent/Command
```bash
/create-agent    # Create new agent
/create-command  # Create new command
```

### Generate API Documentation
```bash
/swagger
```

### Generate Scalar Documentation
```bash
/scalar-doc
```

### Migrate MVC to Hexagonal
```bash
/migrate-old
```

### Develop with Hexagonal Architecture
```bash
/hexdev
```

---

## 📖 Documentation by Topic

### API Documentation
- [Swagger Toolkit README](swagger-toolkit-readme.md)
- [Swagger Command Usage](swagger-command-usage.md)
- [Swagger Example](swagger-example.md)

### Architecture
- See `CLAUDE.md` in project root for hexagonal architecture guide
- Agent: `java-hex-architect.md`
- Agent: `architecture-analyzer.md`

### Migration
- Command: `/migrate-old`
- Agent: `domain-extractor.md`
- Agent: `migration-validator.md`

### Development Workflow
- Command: `/hexdev`
- Agent: `hu-generator.md`
- Agent: `hu-reviewer.md`

### Testing
- Agent: `test-generator.md`

---

## 🎯 Getting Started

1. **Choose your task**:
   - API Documentation → `/swagger`
   - New feature with hexagonal architecture → `/hexdev`
   - Migrate existing code → `/migrate-old`

2. **Review documentation**:
   - Check this INDEX for relevant docs
   - Read the specific toolkit guide
   - See examples for your use case

3. **Execute**:
   - Run the slash command
   - Review generated output
   - Integrate with your project

---

## 💡 Tips

- All slash commands use specialized agents behind the scenes
- Agents can be invoked directly using the Task tool if needed
- Template files in `.claude/tasks/` serve as references
- Documentation files include real-world examples
- Check `CLAUDE.md` for project-specific architectural guidelines

---

## 🔍 Search This Documentation

Looking for something specific?

**API Documentation**: See Swagger Toolkit section
**Hexagonal Architecture**: See `CLAUDE.md` and `java-hex-architect.md`
**Testing**: See `test-generator.md`
**Migration**: See `/migrate-old` command
**User Stories**: See `hu-generator.md`

---

## 📝 Contributing to Documentation

To add new documentation:

1. **Create agent**: Add to `.claude/agents/[name].md`
2. **Create command**: Add to `.claude/commands/[name].md`
3. **Add docs**: Create guides in `.claude/docs/`
4. **Update INDEX**: Add entry to this file

---

**Last Updated**: 2025-10-19
**Project**: mito-books (Spring Boot 3.5.6 + Hexagonal Architecture)