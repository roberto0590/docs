# Swagger Documentation Toolkit

Complete toolkit for automatic OpenAPI 3.0 documentation generation in Spring Boot projects with hexagonal architecture.

## 📦 What's Included

### 1. Swagger Expert Agent
**Location**: `.claude/agents/swagger-expert.md`

Specialized agent that:
- Analyzes Spring Boot REST controllers
- Extracts DTOs and validation constraints
- Generates complete OpenAPI 3.0 YAML
- Includes realistic examples
- Documents error responses
- Validates output format

### 2. Slash Command
**Location**: `.claude/commands/swagger.md`
**Usage**: `/swagger`

One-command documentation generation:
```bash
/swagger
```

Automatically:
- Discovers project structure
- Analyzes all controllers and DTOs
- Generates schemas with validation
- Saves to `.claude/tasks/03-swagger.yaml`
- Provides integration instructions

### 3. Template
**Location**: `.claude/tasks/03-swagger-template.yaml`

Ready-to-use OpenAPI 3.0 template with:
- Generic response wrappers
- Error schemas
- CRUD operation examples
- Validation constraint patterns
- Security scheme templates

### 4. Documentation
**Location**: `.claude/docs/`

- `swagger-command-usage.md` - Complete usage guide
- `swagger-example.md` - Real-world example with mito-books project
- `swagger-toolkit-readme.md` - This file

## 🚀 Quick Start

### Step 1: Run the command
```bash
/swagger
```

### Step 2: Review output
```bash
cat .claude/tasks/03-swagger.yaml
```

### Step 3: Integrate with Spring Boot

Add to `pom.xml`:
```xml
<dependency>
    <groupId>org.springdoc</groupId>
    <artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
    <version>2.3.0</version>
</dependency>
```

Add to `application.properties`:
```properties
springdoc.api-docs.path=/api-docs
springdoc.swagger-ui.path=/swagger-ui.html
springdoc.swagger-ui.operationsSorter=method
```

### Step 4: Access Swagger UI
```
http://localhost:8080/swagger-ui.html
```

## 🎯 Features

### Automatic Discovery
- ✅ All REST controllers in `infrastructure/in/rest/controller/`
- ✅ Request DTOs with validation annotations
- ✅ Response DTOs with field types
- ✅ Exception handlers and error responses
- ✅ Application metadata (name, version, port)

### Schema Generation
- ✅ Convert Jakarta Bean Validation to OpenAPI constraints
- ✅ Generic response wrappers (`GenericResponse<T>`)
- ✅ Error response schemas
- ✅ Nested object support
- ✅ Array/List handling
- ✅ Enum documentation

### Validation Mapping
| Jakarta Validation | OpenAPI Constraint |
|-------------------|-------------------|
| `@NotNull` | `required: true` |
| `@NotBlank` | `minLength: 1` |
| `@Size(min, max)` | `minLength`, `maxLength` |
| `@Min(value)` | `minimum: value` |
| `@Max(value)` | `maximum: value` |
| `@Positive` | `minimum: 1` |
| `@Email` | `format: email` |
| `@Pattern(regexp)` | `pattern: regexp` |

### Documentation Quality
- ✅ Realistic examples for all operations
- ✅ HTTP status codes (200, 400, 404, 500)
- ✅ Operation IDs (camelCase)
- ✅ Tags for logical grouping
- ✅ Descriptions extracted from JavaDoc
- ✅ OpenAPI 3.0.3 compliance

## 📋 Project Requirements

### Required Structure
```
src/main/java/com/company/{context}/
├── infrastructure/
│   └── in/
│       └── rest/
│           ├── controller/      # Must contain @RestController classes
│           └── dto/             # Request/Response DTOs
└── domain/
    └── model/
        └── exception/           # Domain exceptions
```

### Required Annotations
Controllers must use:
- `@RestController` or `@Controller`
- `@RequestMapping` (class level)
- HTTP method annotations (`@GetMapping`, `@PostMapping`, etc.)

DTOs should use:
- Jakarta Bean Validation (`jakarta.validation.constraints.*`)
- Clear naming: `*RequestDto`, `*ResponseDto`

## 🔧 Customization

### After Generation

1. **Add authentication**:
```yaml
components:
  securitySchemes:
    bearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT

security:
  - bearerAuth: []
```

2. **Enhance descriptions**:
```yaml
paths:
  /api/books:
    get:
      description: |
        Returns paginated list of books.

        **Filters:**
        - By category
        - By price range
```

3. **Add more examples**:
```yaml
examples:
  inStock:
    value: { id: 1, title: "Book", stock: 10 }
  outOfStock:
    value: { id: 2, title: "Book", stock: 0 }
```

### Using the Template

For manual creation or reference:
```bash
cp .claude/tasks/03-swagger-template.yaml swagger.yaml
# Edit as needed
```

## 📊 Output Structure

```yaml
openapi: 3.0.3
info:
  title: [Auto-detected]
  description: [Generated]
  version: [From pom.xml]

servers:
  - url: http://localhost:8080

tags:
  - name: [Entity]
    description: [Generated]

paths:
  [All discovered endpoints with full documentation]

components:
  schemas:
    [All DTOs + Generic wrappers + Error responses]
  responses:
    [Reusable error responses]
  securitySchemes:
    [Optional authentication]
```

## 🧪 Validation

The generated file is validated for:
- ✅ OpenAPI 3.0.3 syntax
- ✅ Schema references integrity
- ✅ Required fields presence
- ✅ Example value types

Additional validation:
```bash
# Online validator
https://editor.swagger.io/

# NPM validator
npx @apidevtools/swagger-cli validate .claude/tasks/03-swagger.yaml
```

## 🔄 Workflow Integration

### Development Workflow
1. Implement new controller/endpoint
2. Run `/swagger` to update documentation
3. Review changes in `.claude/tasks/03-swagger.yaml`
4. Commit to version control

### CI/CD Integration
```bash
# In your pipeline
- name: Generate API Docs
  run: |
    # Use swagger command or agent
    # Validate output
    # Deploy to docs site
```

## 📚 Examples

### Example 1: Simple CRUD
```bash
# Create BookController with 5 endpoints
/swagger
# Output: 5 paths + 6 schemas + examples
```

### Example 2: Complex API
```bash
# Multiple controllers with nested objects
/swagger
# Output: 15 paths + 24 schemas + validation constraints
```

### Example 3: Update Existing
```bash
# After adding new endpoints
/swagger
# Merges new endpoints with existing documentation
```

## 🛠️ Troubleshooting

### No endpoints found
**Solution**: Ensure controllers are in correct package and have `@RestController`

### Missing validation constraints
**Solution**: Use `jakarta.validation.constraints.*` (not `javax.*`)

### Incorrect schemas
**Solution**: Verify DTO field types and naming conventions

### Error responses missing
**Solution**: Check for `GlobalErrorHandler` or exception handler

## 🎓 Best Practices

1. **Run after changes**: Keep docs in sync with code
2. **Review before commit**: Validate accuracy
3. **Customize descriptions**: Add business context
4. **Version your API**: Update `info.version` for breaking changes
5. **Use examples**: Provide realistic sample data
6. **Document errors**: Include all possible HTTP status codes
7. **Tag logically**: Group endpoints by domain entity

## 📖 Related Resources

- [OpenAPI Specification](https://swagger.io/specification/)
- [SpringDoc OpenAPI](https://springdoc.org/)
- [Swagger Editor](https://editor.swagger.io/)
- [Jakarta Bean Validation](https://beanvalidation.org/)

## 🔗 Integration Options

### Option 1: SpringDoc Auto-Generation (Recommended)
SpringDoc scans your code and generates docs at runtime.
```properties
springdoc.api-docs.path=/api-docs
```

### Option 2: Static YAML File
Use the generated file directly:
```bash
cp .claude/tasks/03-swagger.yaml src/main/resources/static/swagger.yaml
```

### Option 3: Hybrid Approach
Generate baseline with `/swagger`, then let SpringDoc enhance it with runtime info.

## 📝 File Locations

```
.claude/
├── agents/
│   └── swagger-expert.md          # Agent configuration
├── commands/
│   └── swagger.md                 # Slash command definition
├── tasks/
│   ├── 03-swagger-template.yaml   # Template file
│   └── 03-swagger.yaml            # Generated output
└── docs/
    ├── swagger-command-usage.md   # Usage guide
    ├── swagger-example.md         # Real example
    └── swagger-toolkit-readme.md  # This file
```

## 🎯 Success Metrics

A successful generation includes:
- ✅ All public endpoints documented
- ✅ All DTOs converted to schemas
- ✅ Validation constraints included
- ✅ Realistic examples provided
- ✅ Error responses documented
- ✅ OpenAPI 3.0.3 valid syntax
- ✅ Integration instructions provided

## 🚦 Getting Started

1. Ensure your Spring Boot project follows hexagonal architecture
2. Run `/swagger` in Claude Code
3. Review generated `.claude/tasks/03-swagger.yaml`
4. Integrate with Spring Boot using SpringDoc
5. Access Swagger UI and test your API

## 💡 Tips

- Use `/swagger` after implementing new features
- Compare with SpringDoc auto-generated docs
- Customize examples for better API understanding
- Add authentication schemes if needed
- Keep documentation in version control
- Update version numbers for breaking changes

## 🤝 Contributing

To improve the toolkit:
1. Enhance the agent prompt in `.claude/agents/swagger-expert.md`
2. Update command workflow in `.claude/commands/swagger.md`
3. Extend template with new patterns in `.claude/tasks/03-swagger-template.yaml`
4. Add examples to documentation

---

**Ready to document your API?**

Run `/swagger` and get comprehensive OpenAPI documentation in seconds!
