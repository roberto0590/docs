import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react-swc'
import path from 'path'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    port: 3000,
    proxy: {
      // Proxy for /api/categories (Hexagonal Architecture)
      '/api': {
        target: 'http://localhost:8080',
        changeOrigin: true,
        configure: (proxy, _options) => {
          proxy.on('error', (err, _req, _res) => {
            console.log('❌ Proxy error:', err);
          });
          proxy.on('proxyReq', (proxyReq, req, _res) => {
            console.log('🔄 [/api] Proxying:', req.method, req.url, '→', 'http://localhost:8080' + req.url);
          });
          proxy.on('proxyRes', (proxyRes, req, _res) => {
            console.log('✅ [/api] Response:', proxyRes.statusCode, req.url);
          });
        },
      },
      // Proxy for /books, /clients, /sales (Traditional MVC)
      '/books': {
        target: 'http://localhost:8080',
        changeOrigin: true,
        configure: (proxy, _options) => {
          proxy.on('proxyReq', (proxyReq, req, _res) => {
            console.log('🔄 [MVC] Proxying:', req.method, req.url, '→', 'http://localhost:8080' + req.url);
          });
        },
      },
      '/clients': {
        target: 'http://localhost:8080',
        changeOrigin: true,
        configure: (proxy, _options) => {
          proxy.on('proxyReq', (proxyReq, req, _res) => {
            console.log('🔄 [MVC] Proxying:', req.method, req.url, '→', 'http://localhost:8080' + req.url);
          });
        },
      },
      '/sales': {
        target: 'http://localhost:8080',
        changeOrigin: true,
        configure: (proxy, _options) => {
          proxy.on('proxyReq', (proxyReq, req, _res) => {
            console.log('🔄 [MVC] Proxying:', req.method, req.url, '→', 'http://localhost:8080' + req.url);
          });
        },
      },
    },
  },
})
