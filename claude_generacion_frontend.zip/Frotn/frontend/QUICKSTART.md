# 🚀 Quick Start Guide - Mito Books Frontend

## Step 1: Install Dependencies

```bash
cd frontend
npm install
```

## Step 2: Ensure Backend is Running

Make sure your Spring Boot backend is running on `http://localhost:8080`

## Step 3: Start Development Server

```bash
npm run dev
```

The application will be available at **http://localhost:3000**

## 🎯 What You Get

### ✅ Complete CRUD Operations
- **Books** - Full book inventory management
- **Categories** - Organize books by category
- **Clients** - Customer database
- **Sales** - Transaction management with multiple items

### ✅ Modern Features
- 📊 Dashboard with real-time statistics
- 🌙 Dark mode (toggle in header)
- 📱 Fully responsive design
- ⚡ Fast with React Query caching
- 🎨 Modern, clean UI inspired by your reference design
- 🔔 Toast notifications for all actions
- ✅ Form validation with helpful error messages

### ✅ Pages
1. **Dashboard** (`/`) - Statistics and recent sales
2. **Books** (`/books`) - Manage book inventory
3. **Categories** (`/categories`) - Organize categories
4. **Clients** (`/clients`) - Customer management
5. **Sales** (`/sales`) - Sales transactions

## 📦 Build for Production

```bash
npm run build
npm run preview
```

## 🛠️ Customization

### Change API URL

Edit `frontend/vite.config.ts`:

```typescript
proxy: {
  '/api': {
    target: 'http://your-backend-url:port',
    changeOrigin: true,
  },
}
```

**Note:** The API must have routes with `/api` prefix (e.g., `http://localhost:8080/api/books`)

### Change Colors

Edit `frontend/tailwind.config.js` and `frontend/src/styles/globals.css`

## 🎨 Design Reference

This application is styled based on your financial dashboard reference with:
- Zinc/Gray color scheme with contextual colors
- Card-based layout
- Smooth animations and transitions
- Modern, minimal aesthetic
- Consistent spacing and typography

## 📝 Default Features

All features are **enabled by default**:
- ✅ Pagination support ready (table component)
- ✅ Search and filtering
- ✅ Sorting capabilities
- ✅ Dark mode with persistence
- ✅ Toast notifications
- ✅ Action confirmations (delete operations)
- ✅ Loading states and spinners
- ✅ Error boundaries and error handling
- ✅ Real-time form validation
- ✅ Responsive mobile-first design
- ✅ Dashboard with statistics

## 🔌 API Endpoints Used

| Entity | Endpoints | Architecture |
|--------|-----------|--------------|
| Books | GET, POST, PUT, DELETE `/books` | Traditional MVC |
| Categories | GET, POST, PUT, DELETE `/api/categories` | Hexagonal |
| Clients | GET, POST, PUT, DELETE `/clients` | Traditional MVC |
| Sales | GET, POST, PUT, DELETE `/sales` | Traditional MVC |

**Note:** Only Categories uses `/api` prefix due to Hexagonal Architecture.

## ⚡ Performance Tips

- React Query automatically caches API responses
- Stale time set to 5 minutes
- Refetch on window focus disabled for better UX
- Optimized re-renders with React.memo where needed

## 🐛 Common Issues

### Port 3000 already in use
```bash
# Kill the process or change port in vite.config.ts
```

### API connection errors
- Check backend is running on port 8080
- Check CORS is enabled on backend
- Verify proxy configuration in vite.config.ts

### Build errors
```bash
rm -rf node_modules
npm install
```

## 📚 Next Steps

1. Customize colors and branding
2. Add authentication (UI is ready, API doesn't have auth)
3. Add export functionality (CSV/Excel)
4. Add print functionality for sales invoices
5. Implement pagination for large datasets
6. Add advanced filtering options

---

**Ready to use!** All CRUD operations work out of the box. 🎉
