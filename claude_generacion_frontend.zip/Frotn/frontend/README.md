# Mito Books - Bookstore Management Frontend

Modern, responsive React frontend application for managing a bookstore, built with TypeScript, Tailwind CSS, and React Query.

## 📚 Overview

This is a complete CRUD application for managing books, categories, clients, and sales in a bookstore environment. It features a modern, clean design inspired by contemporary dashboard interfaces, with full dark mode support.

## ✨ Features

- **📖 Book Management**: Complete CRUD operations for books with category organization
- **📂 Category Management**: Organize books into categories (Hexagonal Architecture backend)
- **👥 Client Management**: Register and manage customer profiles
- **🛒 Sales Management**: Create and track sales transactions with multiple items
- **📊 Dashboard**: Real-time statistics and recent sales overview
- **🌙 Dark Mode**: Full dark mode support with system preference detection
- **📱 Responsive**: Mobile-first design that works on all devices
- **⚡ Fast**: Optimized with React Query for caching and automatic refetching
- **🎨 Modern UI**: Clean, minimal design with smooth animations

## 🛠️ Technology Stack

### Core
- **React 18.3** - UI library
- **TypeScript 5.5** - Type safety
- **Vite 5.3** - Build tool and dev server

### State Management & Data Fetching
- **React Query (@tanstack/react-query)** - Server state management
- **React Router DOM 6.26** - Client-side routing
- **React Hook Form 7.52** - Form state management
- **Zod 3.23** - Schema validation

### UI & Styling
- **Tailwind CSS 3.4** - Utility-first CSS framework
- **Lucide React** - Icon library
- **Sonner** - Toast notifications
- **clsx + tailwind-merge** - Conditional class names

### HTTP Client
- **Axios 1.7** - HTTP requests with interceptors

### Utilities
- **date-fns 3.6** - Date formatting

## 📁 Project Structure

```
frontend/
├── src/
│   ├── api/                      # API layer
│   │   ├── client.ts            # Axios client with interceptors
│   │   ├── types.ts             # TypeScript types from Swagger
│   │   ├── services/            # API services for each entity
│   │   │   ├── bookService.ts
│   │   │   ├── categoryService.ts
│   │   │   ├── clientService.ts
│   │   │   └── saleService.ts
│   │   └── index.ts
│   ├── components/
│   │   ├── common/              # Reusable UI components
│   │   │   ├── Button.tsx
│   │   │   ├── Card.tsx
│   │   │   ├── Input.tsx
│   │   │   ├── Select.tsx
│   │   │   ├── Table.tsx
│   │   │   ├── Modal.tsx
│   │   │   ├── LoadingSpinner.tsx
│   │   │   ├── Badge.tsx
│   │   │   └── index.ts
│   │   ├── layout/              # Layout components
│   │   │   ├── Layout.tsx
│   │   │   ├── Sidebar.tsx
│   │   │   └── Header.tsx
│   │   ├── books/               # Book-specific components
│   │   │   └── BookForm.tsx
│   │   ├── categories/          # Category-specific components
│   │   │   └── CategoryForm.tsx
│   │   ├── clients/             # Client-specific components
│   │   │   └── ClientForm.tsx
│   │   └── sales/               # Sale-specific components
│   │       ├── SaleForm.tsx
│   │       └── SaleDetails.tsx
│   ├── pages/                   # Page components
│   │   ├── DashboardPage.tsx
│   │   ├── BooksPage.tsx
│   │   ├── CategoriesPage.tsx
│   │   ├── ClientsPage.tsx
│   │   └── SalesPage.tsx
│   ├── hooks/                   # Custom React hooks
│   │   └── useTheme.ts
│   ├── utils/                   # Utility functions
│   │   └── cn.ts               # Class name merger
│   ├── styles/                  # Global styles
│   │   └── globals.css
│   ├── App.tsx                  # Root component with routing
│   └── main.tsx                 # Application entry point
├── public/
├── index.html
├── package.json
├── tsconfig.json
├── vite.config.ts
├── tailwind.config.js
├── postcss.config.js
└── README.md
```

## 🚀 Getting Started

### Prerequisites

- Node.js 18+ and npm
- Backend API running on `http://localhost:8080`

### Installation

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Configure API endpoint (if different from default):**

   Edit `vite.config.ts` to change the proxy target:
   ```typescript
   proxy: {
     '/api': {
       target: 'http://your-backend-url:port',
       changeOrigin: true,
     },
   }
   ```

   **Note:** The backend uses different route prefixes:
   - Traditional MVC (Books, Clients, Sales): No prefix (e.g., `http://localhost:8080/books`)
   - Hexagonal Architecture (Categories): `/api` prefix (e.g., `http://localhost:8080/api/categories`)

### Development

Start the development server:

```bash
npm run dev
```

The application will be available at `http://localhost:3000`

### Production Build

```bash
npm run build
npm run preview
```

## 🎨 Design System

### Color Palette

The application uses a neutral zinc-based color palette with contextual colors:

- **Primary**: Zinc 900 (light) / Zinc 50 (dark)
- **Success**: Emerald 600/400
- **Danger**: Red 600/400
- **Warning**: Amber 600/400
- **Info**: Blue 600/400

### Components

All UI components are built with:
- Consistent spacing and sizing
- Dark mode support
- Accessible color contrasts
- Hover and focus states
- Loading states
- Error handling

## 🔌 API Integration

The application connects to the Mito Books backend API with the following endpoints:

### Books (Traditional MVC)
- `GET /books` - Get all books
- `GET /books/{id}` - Get book by ID
- `POST /books` - Create book (manual ID assignment)
- `PUT /books/{id}` - Update book
- `DELETE /books/{id}` - Delete book
- `GET /books/byCategory?category={name}` - Filter by category

### Categories (Hexagonal Architecture)
- `GET /api/categories` - Get all categories
- `GET /api/categories/{id}` - Get category by ID
- `POST /api/categories` - Create category (auto-generated ID)
- `PUT /api/categories/{id}` - Update category
- `DELETE /api/categories/{id}` - Delete category

### Clients (Traditional MVC)
- `GET /clients` - Get all clients
- `GET /clients/{id}` - Get client by ID
- `POST /clients` - Create client
- `PUT /clients/{id}` - Update client
- `DELETE /clients/{id}` - Delete client

### Sales (Traditional MVC)
- `GET /sales` - Get all sales
- `GET /sales/{id}` - Get sale by ID
- `POST /sales` - Create sale (with cascading details)
- `PUT /sales/{id}` - Update sale
- `DELETE /sales/{id}` - Delete sale (cascades to details)

### Response Format

All endpoints return data wrapped in `GenericResponse`:

```typescript
{
  status: number;      // HTTP status code
  message: string;     // 'success', 'bad-request', 'not-found', 'failed'
  data: T[];          // Array of entities
}
```

### Error Handling

Errors are intercepted globally and displayed as toast notifications with user-friendly messages.

## 📝 Form Validation

All forms use Zod schemas for validation:

- **Books**: Required fields, max lengths, valid URLs
- **Categories**: 1-20 character name validation
- **Clients**: 3-20 character names, valid birth date
- **Sales**: At least one item, valid prices and quantities

## 🌙 Dark Mode

Dark mode is:
- Automatically detected from system preferences
- Toggleable via header button
- Persisted in localStorage
- Applied to all components consistently

## 🔍 Key Features Explained

### Book Management
- Manual ID assignment (differs from other entities)
- Category filtering
- ISBN tracking
- Photo URL management
- Status toggle (active/inactive)

### Sales Management
- Multi-item sales with dynamic line items
- Automatic total calculation
- Client association
- Cascading sale details
- Complete transaction view

### Dashboard
- Real-time statistics
- Revenue tracking
- Recent sales list
- Entity counts
- Visual indicators

## 🐛 Troubleshooting

### API Connection Issues

If you see network errors:

1. Ensure the backend is running on `http://localhost:8080`
2. Check the proxy configuration in `vite.config.ts`
3. Verify CORS is enabled on the backend

### Build Errors

If you encounter build errors:

```bash
# Clear node_modules and reinstall
rm -rf node_modules
npm install

# Clear Vite cache
rm -rf node_modules/.vite
npm run dev
```

## 📚 Learn More

- [React Documentation](https://react.dev/)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [Tailwind CSS](https://tailwindcss.com/docs)
- [React Query](https://tanstack.com/query/latest)
- [React Hook Form](https://react-hook-form.com/)
- [Zod](https://zod.dev/)

## 🤝 Contributing

1. Follow the existing code style
2. Use TypeScript for all new files
3. Ensure components are responsive
4. Test dark mode compatibility
5. Update this README for new features

## 📄 License

Apache 2.0

---

**Built with** ❤️ **for Mito Books by Claude Code**

Generated from Swagger/OpenAPI specification using React + TypeScript + Tailwind CSS stack.
