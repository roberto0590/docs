import { format } from 'date-fns';
import type { SaleDTO } from '@/api/types';
import { Badge, Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '@/components/common';

interface SaleDetailsProps {
  sale: SaleDTO;
}

export default function SaleDetails({ sale }: SaleDetailsProps) {
  return (
    <div className="space-y-6">
      {/* Sale Information */}
      <div className="grid grid-cols-2 gap-4 p-4 bg-zinc-50 dark:bg-zinc-900 rounded-lg">
        <div>
          <p className="text-xs text-zinc-600 dark:text-zinc-400">Sale ID</p>
          <p className="text-sm font-mono font-medium text-zinc-900 dark:text-zinc-100">
            #{sale.idSale}
          </p>
        </div>

        <div>
          <p className="text-xs text-zinc-600 dark:text-zinc-400">Date & Time</p>
          <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100">
            {format(new Date(sale.momentSale), 'PPpp')}
          </p>
        </div>

        <div>
          <p className="text-xs text-zinc-600 dark:text-zinc-400">Client</p>
          <p className="text-sm font-medium text-zinc-900 dark:text-zinc-100">
            {sale.client.firstName} {sale.client.surname}
          </p>
        </div>

        <div>
          <p className="text-xs text-zinc-600 dark:text-zinc-400">Status</p>
          <Badge variant={sale.statusSale ? 'success' : 'danger'}>
            {sale.statusSale ? 'Completed' : 'Cancelled'}
          </Badge>
        </div>
      </div>

      {/* Sale Items */}
      <div>
        <h3 className="text-sm font-medium text-zinc-900 dark:text-zinc-100 mb-3">
          Items Purchased
        </h3>

        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Book</TableHead>
              <TableHead>ISBN</TableHead>
              <TableHead className="text-right">Unit Price</TableHead>
              <TableHead className="text-right">Quantity</TableHead>
              <TableHead className="text-right">Subtotal</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sale.details.map((detail, index) => (
              <TableRow key={index}>
                <TableCell className="font-medium">{detail.book.title}</TableCell>
                <TableCell className="font-mono text-xs">{detail.book.isbn}</TableCell>
                <TableCell className="text-right font-mono">
                  ${detail.unitPrice.toFixed(2)}
                </TableCell>
                <TableCell className="text-right">{detail.quantity}</TableCell>
                <TableCell className="text-right font-mono font-medium">
                  ${(detail.unitPrice * detail.quantity).toFixed(2)}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Total */}
      <div className="flex items-center justify-between p-4 bg-zinc-100 dark:bg-zinc-800 rounded-lg">
        <span className="text-sm font-medium text-zinc-900 dark:text-zinc-100">Total:</span>
        <span className="text-2xl font-bold text-zinc-900 dark:text-zinc-100">
          ${sale.totalSale.toFixed(2)}
        </span>
      </div>
    </div>
  );
}
