import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Plus, Trash2 } from 'lucide-react';
import { saleService, clientService, bookService } from '@/api';
import type { SaleDTO } from '@/api/types';
import { Button, Input, Select } from '@/components/common';

const saleDetailSchema = z.object({
  bookId: z.string().min(1, 'Book is required').transform(Number),
  unitPrice: z.string().min(1, 'Price is required').transform(Number),
  quantity: z.string().min(1, 'Quantity is required').transform(Number),
  status: z.boolean(),
});

const saleSchema = z.object({
  clientId: z.string().min(1, 'Client is required').transform(Number),
  momentSale: z.string().min(1, 'Date is required'),
  statusSale: z.boolean(),
  details: z.array(saleDetailSchema).min(1, 'At least one item is required'),
});

type SaleFormData = z.infer<typeof saleSchema>;

interface SaleFormProps {
  sale?: SaleDTO | null;
  onSuccess: () => void;
}

export default function SaleForm({ sale, onSuccess }: SaleFormProps) {
  const queryClient = useQueryClient();
  const isEditing = !!sale;

  const { data: clients = [] } = useQuery({
    queryKey: ['clients'],
    queryFn: clientService.getAll,
  });

  const { data: books = [] } = useQuery({
    queryKey: ['books'],
    queryFn: bookService.getAll,
  });

  const {
    register,
    handleSubmit,
    control,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<SaleFormData>({
    resolver: zodResolver(saleSchema),
    defaultValues: sale
      ? {
          clientId: String(sale.client.idClient),
          momentSale: sale.momentSale.slice(0, 16), // Format for datetime-local
          statusSale: sale.statusSale,
          details: sale.details.map((d) => ({
            bookId: String(d.book.idBook),
            unitPrice: String(d.unitPrice),
            quantity: String(d.quantity),
            status: d.status,
          })),
        }
      : {
          clientId: '',
          momentSale: new Date().toISOString().slice(0, 16),
          statusSale: true,
          details: [{ bookId: '', unitPrice: '', quantity: '1', status: true }],
        },
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: 'details',
  });

  const details = watch('details');
  const totalSale = details.reduce((sum, detail) => {
    const price = Number(detail.unitPrice) || 0;
    const qty = Number(detail.quantity) || 0;
    return sum + price * qty;
  }, 0);

  const createMutation = useMutation({
    mutationFn: saleService.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sales'] });
      toast.success('Sale created successfully');
      onSuccess();
    },
    onError: (error: Error) => {
      toast.error(error.message || 'Failed to create sale');
    },
  });

  const onSubmit = async (data: SaleFormData) => {
    const client = clients.find((c) => c.idClient === data.clientId);
    if (!client) {
      toast.error('Invalid client selected');
      return;
    }

    const saleData = {
      client,
      momentSale: data.momentSale,
      totalSale,
      statusSale: data.statusSale,
      details: data.details.map((d) => {
        const book = books.find((b) => b.idBook === d.bookId);
        if (!book) throw new Error('Invalid book');
        return {
          book,
          unitPrice: d.unitPrice,
          quantity: d.quantity,
          status: d.status,
        };
      }),
    };

    createMutation.mutate(saleData);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <Select
          label="Client"
          {...register('clientId')}
          error={errors.clientId?.message}
          options={clients.map((c) => ({
            value: c.idClient!,
            label: `${c.firstName} ${c.surname}`,
          }))}
          required
        />

        <Input
          label="Sale Date & Time"
          type="datetime-local"
          {...register('momentSale')}
          error={errors.momentSale?.message}
          required
        />
      </div>

      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-medium text-zinc-900 dark:text-zinc-100">
            Sale Items
          </h3>
          <Button
            type="button"
            size="sm"
            variant="outline"
            onClick={() => append({ bookId: '', unitPrice: '', quantity: '1', status: true })}
          >
            <Plus className="h-4 w-4" />
            Add Item
          </Button>
        </div>

        <div className="space-y-3">
          {fields.map((field, index) => (
            <div key={field.id} className="flex gap-2 items-start p-3 bg-zinc-50 dark:bg-zinc-900 rounded-lg">
              <div className="flex-1 grid grid-cols-3 gap-2">
                <Select
                  label="Book"
                  {...register(`details.${index}.bookId`)}
                  error={errors.details?.[index]?.bookId?.message}
                  options={books.map((b) => ({
                    value: b.idBook,
                    label: b.title,
                  }))}
                  required
                />

                <Input
                  label="Unit Price"
                  type="number"
                  step="0.01"
                  {...register(`details.${index}.unitPrice`)}
                  error={errors.details?.[index]?.unitPrice?.message}
                  placeholder="0.00"
                  required
                />

                <Input
                  label="Quantity"
                  type="number"
                  min="1"
                  {...register(`details.${index}.quantity`)}
                  error={errors.details?.[index]?.quantity?.message}
                  required
                />
              </div>

              {fields.length > 1 && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => remove(index)}
                  className="mt-6 text-red-600 hover:text-red-700"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
          ))}
        </div>

        {errors.details?.message && (
          <p className="mt-1.5 text-xs text-red-500">{errors.details.message}</p>
        )}
      </div>

      <div className="flex items-center justify-between p-4 bg-zinc-100 dark:bg-zinc-800 rounded-lg">
        <span className="text-sm font-medium text-zinc-900 dark:text-zinc-100">Total:</span>
        <span className="text-xl font-bold text-zinc-900 dark:text-zinc-100">
          ${totalSale.toFixed(2)}
        </span>
      </div>

      <div className="flex items-center gap-2">
        <input
          type="checkbox"
          id="statusSale"
          {...register('statusSale')}
          className="h-4 w-4 rounded border-zinc-300 text-zinc-900 focus:ring-zinc-900 dark:border-zinc-700 dark:bg-zinc-900"
        />
        <label htmlFor="statusSale" className="text-sm font-medium text-zinc-900 dark:text-zinc-100">
          Mark as completed
        </label>
      </div>

      <div className="flex gap-3 pt-4">
        <Button type="submit" className="flex-1" isLoading={isSubmitting}>
          {isEditing ? 'Update Sale' : 'Create Sale'}
        </Button>
        <Button type="button" variant="outline" onClick={onSuccess}>
          Cancel
        </Button>
      </div>
    </form>
  );
}
