import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { clientService } from '@/api';
import type { ClientDTO } from '@/api/types';
import { Button, Input } from '@/components/common';

const clientSchema = z.object({
  firstName: z.string().min(3, 'First name must be at least 3 characters').max(20, 'First name must be at most 20 characters'),
  surname: z.string().min(3, 'Surname must be at least 3 characters').max(20, 'Surname must be at most 20 characters'),
  birthDateClient: z.string().min(1, 'Birth date is required'),
});

type ClientFormData = z.infer<typeof clientSchema>;

interface ClientFormProps {
  client?: ClientDTO | null;
  onSuccess: () => void;
}

export default function ClientForm({ client, onSuccess }: ClientFormProps) {
  const queryClient = useQueryClient();
  const isEditing = !!client;

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<ClientFormData>({
    resolver: zodResolver(clientSchema),
    defaultValues: client
      ? {
          firstName: client.firstName,
          surname: client.surname,
          birthDateClient: client.birthDateClient,
        }
      : {
          firstName: '',
          surname: '',
          birthDateClient: '',
        },
  });

  const createMutation = useMutation({
    mutationFn: clientService.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clients'] });
      toast.success('Client created successfully');
      onSuccess();
    },
    onError: (error: Error) => {
      toast.error(error.message || 'Failed to create client');
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => clientService.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['clients'] });
      toast.success('Client updated successfully');
      onSuccess();
    },
    onError: (error: Error) => {
      toast.error(error.message || 'Failed to update client');
    },
  });

  const onSubmit = async (data: ClientFormData) => {
    if (isEditing && client?.idClient) {
      updateMutation.mutate({ id: client.idClient, data });
    } else {
      createMutation.mutate(data);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <Input
        label="First Name"
        {...register('firstName')}
        error={errors.firstName?.message}
        placeholder="e.g., John"
        required
      />

      <Input
        label="Surname"
        {...register('surname')}
        error={errors.surname?.message}
        placeholder="e.g., Doe"
        required
      />

      <Input
        label="Birth Date"
        type="date"
        {...register('birthDateClient')}
        error={errors.birthDateClient?.message}
        required
      />

      <div className="flex gap-3 pt-4">
        <Button type="submit" className="flex-1" isLoading={isSubmitting}>
          {isEditing ? 'Update Client' : 'Create Client'}
        </Button>
        <Button type="button" variant="outline" onClick={onSuccess}>
          Cancel
        </Button>
      </div>
    </form>
  );
}
