import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { bookService } from '@/api';
import type { BookDTO, CategoryResponseDto } from '@/api/types';
import { Button, Input, Select } from '@/components/common';

const bookSchema = z.object({
  idBook: z.string().min(1, 'ID is required').transform(Number),
  idCategory: z.string().min(1, 'Category is required').transform(Number),
  title: z.string().min(1, 'Title is required').max(50, 'Title must be at most 50 characters'),
  isbn: z.string().min(1, 'ISBN is required').max(30, 'ISBN must be at most 30 characters'),
  photoUrl: z.string().url('Must be a valid URL').max(100, 'URL must be at most 100 characters'),
  status: z.boolean(),
});

type BookFormData = z.infer<typeof bookSchema>;

interface BookFormProps {
  book?: BookDTO | null;
  categories: CategoryResponseDto[];
  onSuccess: () => void;
}

export default function BookForm({ book, categories, onSuccess }: BookFormProps) {
  const queryClient = useQueryClient();
  const isEditing = !!book;

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<BookFormData>({
    resolver: zodResolver(bookSchema),
    defaultValues: book
      ? {
          idBook: String(book.idBook),
          idCategory: String(book.idCategory),
          title: book.title,
          isbn: book.isbn,
          photoUrl: book.photoUrl,
          status: book.status,
        }
      : {
          idBook: '',
          idCategory: '',
          title: '',
          isbn: '',
          photoUrl: '',
          status: true,
        },
  });

  const createMutation = useMutation({
    mutationFn: bookService.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['books'] });
      toast.success('Book created successfully');
      onSuccess();
    },
    onError: (error: Error) => {
      toast.error(error.message || 'Failed to create book');
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => bookService.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['books'] });
      toast.success('Book updated successfully');
      onSuccess();
    },
    onError: (error: Error) => {
      toast.error(error.message || 'Failed to update book');
    },
  });

  const onSubmit = async (data: BookFormData) => {
    if (isEditing) {
      updateMutation.mutate({ id: data.idBook, data });
    } else {
      createMutation.mutate(data);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <Input
        label="Book ID"
        type="number"
        {...register('idBook')}
        error={errors.idBook?.message}
        disabled={isEditing}
        placeholder="e.g., 1"
        required
      />

      <Select
        label="Category"
        {...register('idCategory')}
        error={errors.idCategory?.message}
        options={categories.map((cat) => ({
          value: cat.idCategory,
          label: cat.categoryName,
        }))}
        required
      />

      <Input
        label="Title"
        {...register('title')}
        error={errors.title?.message}
        placeholder="e.g., Clean Code"
        required
      />

      <Input
        label="ISBN"
        {...register('isbn')}
        error={errors.isbn?.message}
        placeholder="e.g., 978-0132350884"
        required
      />

      <Input
        label="Photo URL"
        type="url"
        {...register('photoUrl')}
        error={errors.photoUrl?.message}
        placeholder="https://example.com/book-cover.jpg"
        required
      />

      <div className="flex items-center gap-2">
        <input
          type="checkbox"
          id="status"
          {...register('status')}
          className="h-4 w-4 rounded border-zinc-300 text-zinc-900 focus:ring-zinc-900 dark:border-zinc-700 dark:bg-zinc-900"
        />
        <label htmlFor="status" className="text-sm font-medium text-zinc-900 dark:text-zinc-100">
          Active
        </label>
      </div>

      <div className="flex gap-3 pt-4">
        <Button type="submit" className="flex-1" isLoading={isSubmitting}>
          {isEditing ? 'Update Book' : 'Create Book'}
        </Button>
        <Button type="button" variant="outline" onClick={onSuccess}>
          Cancel
        </Button>
      </div>
    </form>
  );
}
