import { Moon, Sun } from 'lucide-react';
import { useTheme } from '@/hooks/useTheme';
import Button from '@/components/common/Button';

export default function Header() {
  const { theme, setTheme } = useTheme();

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white/95 dark:bg-[#0F0F12]/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 dark:supports-[backdrop-filter]:bg-[#0F0F12]/60 border-b border-zinc-200 dark:border-zinc-800">
      <div className="flex h-16 items-center px-6 justify-between">
        {/* Mobile Logo */}
        <div className="flex md:hidden items-center gap-2">
          <h1 className="text-lg font-bold text-zinc-900 dark:text-zinc-100">Mito Books</h1>
        </div>

        {/* Spacer for desktop */}
        <div className="flex-1" />

        {/* Actions */}
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleTheme}
            className="h-9 w-9 p-0 rounded-full"
          >
            {theme === 'dark' ? (
              <Sun className="h-5 w-5" />
            ) : (
              <Moon className="h-5 w-5" />
            )}
          </Button>
        </div>
      </div>
    </header>
  );
}
