import { NavLink } from 'react-router-dom';
import { Book, FolderTree, Users, ShoppingCart, LayoutDashboard } from 'lucide-react';
import { cn } from '@/utils/cn';

const navigation = [
  { name: 'Dashboard', href: '/', icon: LayoutDashboard },
  { name: 'Books', href: '/books', icon: Book },
  { name: 'Categories', href: '/categories', icon: FolderTree },
  { name: 'Clients', href: '/clients', icon: Users },
  { name: 'Sales', href: '/sales', icon: ShoppingCart },
];

export default function Sidebar() {
  return (
    <aside className="hidden md:flex md:flex-col w-64 bg-white dark:bg-[#0F0F12] border-r border-zinc-200 dark:border-zinc-800 h-screen sticky top-0">
      {/* Logo */}
      <div className="p-6 border-b border-zinc-200 dark:border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-zinc-900 dark:bg-zinc-50 rounded-lg">
            <Book className="h-6 w-6 text-zinc-50 dark:text-zinc-900" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-zinc-900 dark:text-zinc-100">Mito Books</h1>
            <p className="text-xs text-zinc-600 dark:text-zinc-400">Bookstore Management</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1">
        {navigation.map((item) => (
          <NavLink
            key={item.name}
            to={item.href}
            className={({ isActive }) =>
              cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200',
                isActive
                  ? 'bg-zinc-900 dark:bg-zinc-50 text-zinc-50 dark:text-zinc-900 shadow-sm'
                  : 'text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800/50 hover:text-zinc-900 dark:hover:text-zinc-100'
              )
            }
          >
            {({ isActive }) => (
              <>
                <item.icon className="h-5 w-5 flex-shrink-0" />
                <span>{item.name}</span>
              </>
            )}
          </NavLink>
        ))}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-zinc-200 dark:border-zinc-800">
        <div className="px-3 py-2">
          <p className="text-xs text-zinc-500 dark:text-zinc-500">
            © 2025 Mito Books
          </p>
          <p className="text-xs text-zinc-500 dark:text-zinc-500">Version 1.0.0</p>
        </div>
      </div>
    </aside>
  );
}
