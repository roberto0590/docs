import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { categoryService } from '@/api';
import type { CategoryResponseDto } from '@/api/types';
import { Button, Input } from '@/components/common';

const categorySchema = z.object({
  categoryName: z.string().min(1, 'Name is required').max(20, 'Name must be at most 20 characters'),
  status: z.boolean(),
});

type CategoryFormData = z.infer<typeof categorySchema>;

interface CategoryFormProps {
  category?: CategoryResponseDto | null;
  onSuccess: () => void;
}

export default function CategoryForm({ category, onSuccess }: CategoryFormProps) {
  const queryClient = useQueryClient();
  const isEditing = !!category;

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<CategoryFormData>({
    resolver: zodResolver(categorySchema),
    defaultValues: category
      ? {
          categoryName: category.categoryName,
          status: category.status,
        }
      : {
          categoryName: '',
          status: true,
        },
  });

  const createMutation = useMutation({
    mutationFn: categoryService.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['categories'] });
      toast.success('Category created successfully');
      onSuccess();
    },
    onError: (error: Error) => {
      toast.error(error.message || 'Failed to create category');
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => categoryService.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['categories'] });
      toast.success('Category updated successfully');
      onSuccess();
    },
    onError: (error: Error) => {
      toast.error(error.message || 'Failed to update category');
    },
  });

  const onSubmit = async (data: CategoryFormData) => {
    if (isEditing && category) {
      updateMutation.mutate({ id: category.idCategory, data });
    } else {
      createMutation.mutate(data);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <Input
        label="Category Name"
        {...register('categoryName')}
        error={errors.categoryName?.message}
        placeholder="e.g., Programming"
        required
      />

      <div className="flex items-center gap-2">
        <input
          type="checkbox"
          id="status"
          {...register('status')}
          className="h-4 w-4 rounded border-zinc-300 text-zinc-900 focus:ring-zinc-900 dark:border-zinc-700 dark:bg-zinc-900"
        />
        <label htmlFor="status" className="text-sm font-medium text-zinc-900 dark:text-zinc-100">
          Active
        </label>
      </div>

      <div className="flex gap-3 pt-4">
        <Button type="submit" className="flex-1" isLoading={isSubmitting}>
          {isEditing ? 'Update Category' : 'Create Category'}
        </Button>
        <Button type="button" variant="outline" onClick={onSuccess}>
          Cancel
        </Button>
      </div>
    </form>
  );
}
