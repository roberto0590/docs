import axios, { AxiosError } from 'axios';
import type { GenericErrorResponse } from './types';

// ============================================================================
// Axios Client Configuration
// ============================================================================

export const apiClient = axios.create({
  baseURL: '/', // Base URL for API calls (proxied to http://localhost:8080)
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000,
});

// ============================================================================
// Request Interceptor
// ============================================================================

apiClient.interceptors.request.use(
  (config) => {
    // Add any authentication tokens here if needed in the future
    // const token = localStorage.getItem('authToken');
    // if (token) {
    //   config.headers.Authorization = `Bearer ${token}`;
    // }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// ============================================================================
// Response Interceptor
// ============================================================================

apiClient.interceptors.response.use(
  (response) => {
    return response;
  },
  (error: AxiosError<GenericErrorResponse>) => {
    // Handle errors globally
    if (error.response) {
      const errorData = error.response.data;

      // Extract error message from GenericResponse<CustomErrorResponse>
      const errorMessage = errorData?.data?.[0]?.message || errorData?.message || 'An error occurred';

      console.error('API Error:', {
        status: error.response.status,
        message: errorMessage,
        path: errorData?.data?.[0]?.path,
      });

      // Create a more user-friendly error
      const customError = new Error(errorMessage);
      (customError as any).status = error.response.status;
      (customError as any).code = errorData?.message; // 'bad-request', 'not-found', 'failed'

      return Promise.reject(customError);
    } else if (error.request) {
      // Network error
      const networkError = new Error('Network error - please check your connection');
      return Promise.reject(networkError);
    } else {
      return Promise.reject(error);
    }
  }
);

export default apiClient;
