// ============================================================================
// TypeScript Types Generated from Swagger/OpenAPI Specification
// API: Mito Books - Bookstore Management API
// Version: 0.0.1-SNAPSHOT
// ============================================================================

// ============================================================================
// Generic Response Types
// ============================================================================

export interface GenericResponse<T> {
  status: number;
  message: string;
  data: T[];
}

export interface CustomErrorResponse {
  datetime: string;
  message: string;
  path: string;
}

export type GenericErrorResponse = GenericResponse<CustomErrorResponse>;

// ============================================================================
// Book Types
// ============================================================================

export interface BookDTO {
  idBook: number;
  idCategory: number;
  title: string;
  isbn: string;
  photoUrl: string;
  status: boolean;
}

export interface CreateBookDTO {
  idBook: number; // Manually assigned - must be unique
  idCategory: number; // 1-100
  title: string; // max 50
  isbn: string; // max 30
  photoUrl: string; // max 100
  status: boolean;
}

export interface UpdateBookDTO extends CreateBookDTO {}

export type BookListResponse = GenericResponse<BookDTO>;

// ============================================================================
// Category Types
// ============================================================================

export interface CategoryDTO {
  idCategory?: number; // Auto-generated (read-only on create)
  categoryName: string; // max 20
  status: boolean;
}

export interface CreateCategoryRequestDto {
  categoryName: string; // required, max 20
  status?: boolean; // default true
}

export interface UpdateCategoryRequestDto {
  categoryName: string; // required, max 20
  status: boolean;
}

export interface CategoryResponseDto {
  idCategory: number;
  categoryName: string;
  status: boolean;
}

export type CategoryListResponse = GenericResponse<CategoryResponseDto>;

// ============================================================================
// Client Types
// ============================================================================

export interface ClientDTO {
  idClient?: number; // Auto-generated (read-only on create)
  firstName: string; // 3-20 characters
  surname: string; // 3-20 characters
  birthDateClient: string; // LocalDate format: YYYY-MM-DD
}

export interface CreateClientDTO {
  firstName: string;
  surname: string;
  birthDateClient: string;
}

export interface UpdateClientDTO extends CreateClientDTO {
  idClient?: number;
}

export type ClientListResponse = GenericResponse<ClientDTO>;

// ============================================================================
// Sale Types
// ============================================================================

export interface SaleDetailDTO {
  book: BookDTO;
  unitPrice: number;
  quantity: number;
  status: boolean;
}

export interface SaleDTO {
  idSale?: number; // Auto-generated (read-only on create)
  client: ClientDTO;
  momentSale: string; // LocalDateTime format: YYYY-MM-DDTHH:mm:ss
  totalSale: number;
  statusSale: boolean;
  details: SaleDetailDTO[]; // At least one detail required
}

export interface CreateSaleDTO {
  client: ClientDTO;
  momentSale: string;
  totalSale: number;
  statusSale: boolean;
  details: SaleDetailDTO[];
}

export interface UpdateSaleDTO extends CreateSaleDTO {
  idSale?: number;
}

export type SaleListResponse = GenericResponse<SaleDTO>;

// ============================================================================
// Form Types (for React Hook Form)
// ============================================================================

export interface BookFormData {
  idBook: string; // Form inputs are strings initially
  idCategory: string;
  title: string;
  isbn: string;
  photoUrl: string;
  status: boolean;
}

export interface CategoryFormData {
  categoryName: string;
  status: boolean;
}

export interface ClientFormData {
  firstName: string;
  surname: string;
  birthDateClient: string; // Date input value
}

export interface SaleDetailFormData {
  bookId: string;
  unitPrice: string;
  quantity: string;
  status: boolean;
}

export interface SaleFormData {
  clientId: string;
  momentSale: string;
  totalSale: string;
  statusSale: boolean;
  details: SaleDetailFormData[];
}

// ============================================================================
// API Query Types
// ============================================================================

export interface BooksByCategoryParams {
  category: string; // Partial match, case-insensitive
}

// ============================================================================
// Statistics Types (for Dashboard)
// ============================================================================

export interface DashboardStats {
  totalBooks: number;
  activeBooks: number;
  totalCategories: number;
  totalClients: number;
  totalSales: number;
  totalRevenue: number;
  recentSales: SaleDTO[];
  topBooks: Array<{
    book: BookDTO;
    totalSold: number;
    revenue: number;
  }>;
}
