import apiClient from '../client';
import type {
  BookDTO,
  CreateBookDTO,
  UpdateBookDTO,
  BookListResponse,
  BooksByCategoryParams,
} from '../types';

// ============================================================================
// Book Service - CRUD Operations
// Architecture: Traditional MVC (Controller → Service → Repository)
// ============================================================================

export const bookService = {
  /**
   * GET /books - Get all books
   * Returns: List of all books with category information
   */
  getAll: async (): Promise<BookDTO[]> => {
    const response = await apiClient.get<BookListResponse>('/books');
    return response.data.data;
  },

  /**
   * GET /books/{id} - Get book by ID
   * @param id - Book unique identifier
   * Returns: Single book object
   */
  getById: async (id: number): Promise<BookDTO> => {
    const response = await apiClient.get<BookListResponse>(`/books/${id}`);
    return response.data.data[0]; // API returns array with single item
  },

  /**
   * POST /books - Create a new book
   * @param book - Book data (includes manually assigned idBook)
   * Returns: void (201 Created with Location header)
   * Note: idBook must be manually assigned and unique
   */
  create: async (book: CreateBookDTO): Promise<void> => {
    await apiClient.post('/books', book);
  },

  /**
   * PUT /books/{id} - Update an existing book
   * @param id - Book ID to update
   * @param book - Updated book data
   * Returns: Updated book object
   */
  update: async (id: number, book: UpdateBookDTO): Promise<BookDTO> => {
    const response = await apiClient.put<BookListResponse>(`/books/${id}`, book);
    return response.data.data[0];
  },

  /**
   * DELETE /books/{id} - Delete a book
   * @param id - Book ID to delete
   * Returns: void (204 No Content)
   */
  delete: async (id: number): Promise<void> => {
    await apiClient.delete(`/books/${id}`);
  },

  /**
   * GET /books/byCategory?category={name} - Get books by category
   * @param params - Category filter params (partial match, case-insensitive)
   * Returns: List of books matching the category filter
   */
  getByCategory: async (params: BooksByCategoryParams): Promise<BookDTO[]> => {
    const response = await apiClient.get<BookListResponse>('/books/byCategory', {
      params,
    });
    return response.data.data;
  },
};

export default bookService;
