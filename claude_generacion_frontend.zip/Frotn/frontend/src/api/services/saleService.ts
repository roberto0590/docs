import apiClient from '../client';
import type {
  SaleDTO,
  CreateSaleDTO,
  UpdateSaleDTO,
  SaleListResponse,
} from '../types';

// ============================================================================
// Sale Service - CRUD Operations
// Architecture: Traditional MVC with Cascading (Controller → Service → Repository)
// Note: Sale details are saved with cascade operation
// ============================================================================

export const saleService = {
  /**
   * GET /sales - Get all sales
   * Returns: List of all sales with client and sale details (books)
   */
  getAll: async (): Promise<SaleDTO[]> => {
    const response = await apiClient.get<SaleListResponse>('/sales');
    return response.data.data;
  },

  /**
   * GET /sales/{id} - Get sale by ID
   * @param id - Sale unique identifier
   * Returns: Single sale object with client and details
   */
  getById: async (id: number): Promise<SaleDTO> => {
    const response = await apiClient.get<SaleListResponse>(`/sales/${id}`);
    return response.data.data[0];
  },

  /**
   * POST /sales - Create a new sale
   * @param sale - Sale data (client, momentSale, totalSale, details)
   * Returns: void (201 Created with Location header)
   * Business Rules:
   *  - At least one sale detail required
   *  - totalSale should match sum of (unitPrice × quantity) for all details
   *  - Sale details are saved with CASCADE operation
   */
  create: async (sale: CreateSaleDTO): Promise<void> => {
    await apiClient.post('/sales', sale);
  },

  /**
   * PUT /sales/{id} - Update an existing sale
   * @param id - Sale ID to update
   * @param sale - Updated sale data
   * Returns: Updated sale object
   * Warning: Updating completed sales may affect accounting
   */
  update: async (id: number, sale: UpdateSaleDTO): Promise<SaleDTO> => {
    const response = await apiClient.put<SaleListResponse>(`/sales/${id}`, sale);
    return response.data.data[0];
  },

  /**
   * DELETE /sales/{id} - Delete a sale
   * @param id - Sale ID to delete
   * Returns: void (204 No Content)
   * Warning: Deletes sale and all associated sale details (CASCADE)
   * Consider soft delete (status flag) for audit purposes
   */
  delete: async (id: number): Promise<void> => {
    await apiClient.delete(`/sales/${id}`);
  },
};

export default saleService;
