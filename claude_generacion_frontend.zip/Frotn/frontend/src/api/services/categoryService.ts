import apiClient from '../client';
import type {
  CategoryResponseDto,
  CreateCategoryRequestDto,
  UpdateCategoryRequestDto,
  CategoryListResponse,
} from '../types';

// ============================================================================
// Category Service - CRUD Operations
// Architecture: Hexagonal Architecture (Ports & Adapters)
// Flow: Controller → Facade → Use Case → Domain → Repository Port → Adapter
// ============================================================================

export const categoryService = {
  /**
   * GET /api/categories - Get all categories
   * Returns: List of all categories
   */
  getAll: async (): Promise<CategoryResponseDto[]> => {
    const response = await apiClient.get<CategoryListResponse>('/api/categories');
    return response.data.data;
  },

  /**
   * GET /api/categories/{id} - Get category by ID
   * @param id - Category unique identifier
   * Returns: Single category object
   * Throws: CategoryNotFoundException if not found
   */
  getById: async (id: number): Promise<CategoryResponseDto> => {
    const response = await apiClient.get<CategoryListResponse>(`/api/categories/${id}`);
    return response.data.data[0];
  },

  /**
   * POST /api/categories - Create a new category
   * @param category - Category data (categoryName required, status optional)
   * Returns: void (201 Created with Location header)
   * Note: idCategory is auto-generated
   */
  create: async (category: CreateCategoryRequestDto): Promise<void> => {
    await apiClient.post('/api/categories', category);
  },

  /**
   * PUT /api/categories/{id} - Update an existing category
   * @param id - Category ID to update
   * @param category - Updated category data
   * Returns: Updated category object
   */
  update: async (
    id: number,
    category: UpdateCategoryRequestDto
  ): Promise<CategoryResponseDto> => {
    const response = await apiClient.put<CategoryListResponse>(`/api/categories/${id}`, category);
    return response.data.data[0];
  },

  /**
   * DELETE /api/categories/{id} - Delete a category
   * @param id - Category ID to delete
   * Returns: void (204 No Content)
   * Warning: May affect books assigned to this category
   */
  delete: async (id: number): Promise<void> => {
    await apiClient.delete(`/api/categories/${id}`);
  },
};

export default categoryService;
