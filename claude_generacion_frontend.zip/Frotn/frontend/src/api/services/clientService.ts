import apiClient from '../client';
import type {
  ClientDTO,
  CreateClientDTO,
  UpdateClientDTO,
  ClientListResponse,
} from '../types';

// ============================================================================
// Client Service - CRUD Operations
// Architecture: Traditional MVC (Controller → Service → Repository)
// ============================================================================

export const clientService = {
  /**
   * GET /clients - Get all clients
   * Returns: List of all clients (customers)
   */
  getAll: async (): Promise<ClientDTO[]> => {
    const response = await apiClient.get<ClientListResponse>('/clients');
    return response.data.data;
  },

  /**
   * GET /clients/{id} - Get client by ID
   * @param id - Client unique identifier
   * Returns: Single client object
   */
  getById: async (id: number): Promise<ClientDTO> => {
    const response = await apiClient.get<ClientListResponse>(`/clients/${id}`);
    return response.data.data[0];
  },

  /**
   * POST /clients - Create a new client
   * @param client - Client data (firstName, surname, birthDateClient)
   * Returns: void (201 Created with Location header)
   * Validation:
   *  - firstName: 3-20 characters
   *  - surname: 3-20 characters
   *  - birthDateClient: Valid date (YYYY-MM-DD)
   */
  create: async (client: CreateClientDTO): Promise<void> => {
    await apiClient.post('/clients', client);
  },

  /**
   * PUT /clients/{id} - Update an existing client
   * @param id - Client ID to update
   * @param client - Updated client data
   * Returns: Updated client object
   */
  update: async (id: number, client: UpdateClientDTO): Promise<ClientDTO> => {
    const response = await apiClient.put<ClientListResponse>(`/clients/${id}`, client);
    return response.data.data[0];
  },

  /**
   * DELETE /clients/{id} - Delete a client
   * @param id - Client ID to delete
   * Returns: void (204 No Content)
   * Warning: May affect existing sales records
   */
  delete: async (id: number): Promise<void> => {
    await apiClient.delete(`/clients/${id}`);
  },
};

export default clientService;
