import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Pencil, Trash2, ShoppingCart, Eye } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { saleService } from '@/api';
import type { SaleDTO } from '@/api/types';
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  Button,
  LoadingSpinner,
  Modal,
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
  Badge,
} from '@/components/common';
import SaleForm from '@/components/sales/SaleForm';
import SaleDetails from '@/components/sales/SaleDetails';

export default function SalesPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSale, setEditingSale] = useState<SaleDTO | null>(null);
  const [viewingSale, setViewingSale] = useState<SaleDTO | null>(null);
  const queryClient = useQueryClient();

  const { data: sales = [], isLoading } = useQuery({
    queryKey: ['sales'],
    queryFn: saleService.getAll,
  });

  const deleteMutation = useMutation({
    mutationFn: saleService.delete,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sales'] });
      toast.success('Sale deleted successfully');
    },
    onError: (error: Error) => {
      toast.error(error.message || 'Failed to delete sale');
    },
  });

  const handleEdit = (sale: SaleDTO) => {
    setEditingSale(sale);
    setIsModalOpen(true);
  };

  const handleView = (sale: SaleDTO) => {
    setViewingSale(sale);
  };

  const handleDelete = async (id: number) => {
    if (confirm('Are you sure you want to delete this sale? This will also delete all sale details.')) {
      deleteMutation.mutate(id);
    }
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingSale(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-zinc-900 dark:text-zinc-100">Sales</h1>
          <p className="text-zinc-600 dark:text-zinc-400 mt-1">
            Track and manage sales transactions
          </p>
        </div>
        <Button onClick={() => setIsModalOpen(true)}>
          <Plus className="h-4 w-4" />
          New Sale
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>
            <ShoppingCart className="h-5 w-5" />
            All Sales ({sales.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <LoadingSpinner />
          ) : sales.length === 0 ? (
            <div className="text-center py-12">
              <ShoppingCart className="h-12 w-12 mx-auto text-zinc-400 mb-4" />
              <p className="text-zinc-600 dark:text-zinc-400">No sales found</p>
              <Button className="mt-4" onClick={() => setIsModalOpen(true)}>
                Create your first sale
              </Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Client</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Items</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sales.map((sale) => (
                  <TableRow key={sale.idSale}>
                    <TableCell className="font-mono text-xs">{sale.idSale}</TableCell>
                    <TableCell className="font-medium">
                      {sale.client.firstName} {sale.client.surname}
                    </TableCell>
                    <TableCell>
                      {format(new Date(sale.momentSale), 'MMM dd, yyyy HH:mm')}
                    </TableCell>
                    <TableCell>
                      <Badge variant="info">{sale.details.length} items</Badge>
                    </TableCell>
                    <TableCell className="font-mono font-medium">
                      ${sale.totalSale.toFixed(2)}
                    </TableCell>
                    <TableCell>
                      <Badge variant={sale.statusSale ? 'success' : 'danger'}>
                        {sale.statusSale ? 'Completed' : 'Cancelled'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleView(sale)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(sale.idSale!)}
                          className="text-red-600 hover:text-red-700 dark:text-red-400"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Modal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        title={editingSale ? 'Edit Sale' : 'New Sale'}
        size="xl"
      >
        <SaleForm sale={editingSale} onSuccess={handleCloseModal} />
      </Modal>

      <Modal
        isOpen={!!viewingSale}
        onClose={() => setViewingSale(null)}
        title="Sale Details"
        size="lg"
      >
        {viewingSale && <SaleDetails sale={viewingSale} />}
      </Modal>
    </div>
  );
}
