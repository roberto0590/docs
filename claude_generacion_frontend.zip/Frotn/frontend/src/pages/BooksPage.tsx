import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Pencil, Trash2, Book as BookIcon } from 'lucide-react';
import { toast } from 'sonner';
import { bookService, categoryService } from '@/api';
import type { BookDTO, CategoryResponseDto } from '@/api/types';
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  Button,
  LoadingSpinner,
  Modal,
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
  Badge,
} from '@/components/common';
import BookForm from '@/components/books/BookForm';

export default function BooksPage() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBook, setEditingBook] = useState<BookDTO | null>(null);
  const queryClient = useQueryClient();

  // Fetch books
  const { data: books = [], isLoading } = useQuery({
    queryKey: ['books'],
    queryFn: bookService.getAll,
  });

  // Fetch categories for the form
  const { data: categories = [] } = useQuery({
    queryKey: ['categories'],
    queryFn: categoryService.getAll,
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: bookService.delete,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['books'] });
      toast.success('Book deleted successfully');
    },
    onError: (error: Error) => {
      toast.error(error.message || 'Failed to delete book');
    },
  });

  const handleEdit = (book: BookDTO) => {
    setEditingBook(book);
    setIsModalOpen(true);
  };

  const handleDelete = async (id: number, title: string) => {
    if (confirm(`Are you sure you want to delete "${title}"?`)) {
      deleteMutation.mutate(id);
    }
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingBook(null);
  };

  const getCategoryName = (idCategory: number): string => {
    return categories.find((cat) => cat.idCategory === idCategory)?.categoryName || 'Unknown';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-zinc-900 dark:text-zinc-100">Books</h1>
          <p className="text-zinc-600 dark:text-zinc-400 mt-1">
            Manage your bookstore inventory
          </p>
        </div>
        <Button onClick={() => setIsModalOpen(true)}>
          <Plus className="h-4 w-4" />
          Add Book
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>
            <BookIcon className="h-5 w-5" />
            All Books ({books.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <LoadingSpinner />
          ) : books.length === 0 ? (
            <div className="text-center py-12">
              <BookIcon className="h-12 w-12 mx-auto text-zinc-400 mb-4" />
              <p className="text-zinc-600 dark:text-zinc-400">No books found</p>
              <Button className="mt-4" onClick={() => setIsModalOpen(true)}>
                Add your first book
              </Button>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Title</TableHead>
                  <TableHead>ISBN</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {books.map((book) => (
                  <TableRow key={book.idBook}>
                    <TableCell className="font-mono text-xs">{book.idBook}</TableCell>
                    <TableCell className="font-medium">{book.title}</TableCell>
                    <TableCell className="font-mono text-xs">{book.isbn}</TableCell>
                    <TableCell>
                      <Badge variant="info">{getCategoryName(book.idCategory)}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={book.status ? 'success' : 'danger'}>
                        {book.status ? 'Active' : 'Inactive'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(book)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(book.idBook, book.title)}
                          className="text-red-600 hover:text-red-700 dark:text-red-400"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Modal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        title={editingBook ? 'Edit Book' : 'Add New Book'}
        size="lg"
      >
        <BookForm
          book={editingBook}
          categories={categories}
          onSuccess={handleCloseModal}
        />
      </Modal>
    </div>
  );
}
