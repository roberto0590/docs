import { useQuery } from '@tanstack/react-query';
import { Book, FolderTree, Users, ShoppingCart, TrendingUp, DollarSign } from 'lucide-react';
import { format } from 'date-fns';
import { bookService, categoryService, clientService, saleService } from '@/api';
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  LoadingSpinner,
  Badge,
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from '@/components/common';

export default function DashboardPage() {
  const { data: books = [], isLoading: booksLoading } = useQuery({
    queryKey: ['books'],
    queryFn: bookService.getAll,
  });

  const { data: categories = [], isLoading: categoriesLoading } = useQuery({
    queryKey: ['categories'],
    queryFn: categoryService.getAll,
  });

  const { data: clients = [], isLoading: clientsLoading } = useQuery({
    queryKey: ['clients'],
    queryFn: clientService.getAll,
  });

  const { data: sales = [], isLoading: salesLoading } = useQuery({
    queryKey: ['sales'],
    queryFn: saleService.getAll,
  });

  const isLoading = booksLoading || categoriesLoading || clientsLoading || salesLoading;

  // Calculate statistics
  const activeBooks = books.filter((b) => b.status).length;
  const totalRevenue = sales.reduce((sum, sale) => sum + sale.totalSale, 0);
  const recentSales = [...sales]
    .sort((a, b) => new Date(b.momentSale).getTime() - new Date(a.momentSale).getTime())
    .slice(0, 5);

  const stats = [
    {
      title: 'Total Books',
      value: books.length,
      subtitle: `${activeBooks} active`,
      icon: Book,
      color: 'text-emerald-600 dark:text-emerald-400',
      bgColor: 'bg-emerald-100 dark:bg-emerald-900/30',
    },
    {
      title: 'Categories',
      value: categories.length,
      subtitle: 'Book categories',
      icon: FolderTree,
      color: 'text-blue-600 dark:text-blue-400',
      bgColor: 'bg-blue-100 dark:bg-blue-900/30',
    },
    {
      title: 'Clients',
      value: clients.length,
      subtitle: 'Registered customers',
      icon: Users,
      color: 'text-purple-600 dark:text-purple-400',
      bgColor: 'bg-purple-100 dark:bg-purple-900/30',
    },
    {
      title: 'Total Sales',
      value: sales.length,
      subtitle: 'Transactions',
      icon: ShoppingCart,
      color: 'text-amber-600 dark:text-amber-400',
      bgColor: 'bg-amber-100 dark:bg-amber-900/30',
    },
  ];

  if (isLoading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-zinc-900 dark:text-zinc-100">Dashboard</h1>
        <p className="text-zinc-600 dark:text-zinc-400 mt-1">
          Welcome to Mito Books Management System
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-zinc-600 dark:text-zinc-400">{stat.title}</p>
                  <h3 className="text-3xl font-bold text-zinc-900 dark:text-zinc-100 mt-2">
                    {stat.value}
                  </h3>
                  <p className="text-xs text-zinc-600 dark:text-zinc-400 mt-1">
                    {stat.subtitle}
                  </p>
                </div>
                <div className={`p-3 rounded-lg ${stat.bgColor}`}>
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Revenue Card */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-zinc-600 dark:text-zinc-400">Total Revenue</p>
              <h3 className="text-3xl font-bold text-zinc-900 dark:text-zinc-100 mt-2">
                ${totalRevenue.toFixed(2)}
              </h3>
              <p className="text-xs text-zinc-600 dark:text-zinc-400 mt-1">
                From {sales.length} sales
              </p>
            </div>
            <div className="p-3 rounded-lg bg-green-100 dark:bg-green-900/30">
              <DollarSign className="h-6 w-6 text-green-600 dark:text-green-400" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Sales */}
      <Card>
        <CardHeader>
          <CardTitle>
            <TrendingUp className="h-5 w-5" />
            Recent Sales
          </CardTitle>
        </CardHeader>
        <CardContent>
          {recentSales.length === 0 ? (
            <div className="text-center py-8">
              <ShoppingCart className="h-12 w-12 mx-auto text-zinc-400 mb-2" />
              <p className="text-zinc-600 dark:text-zinc-400">No sales yet</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Client</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Items</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentSales.map((sale) => (
                  <TableRow key={sale.idSale}>
                    <TableCell className="font-mono text-xs">#{sale.idSale}</TableCell>
                    <TableCell className="font-medium">
                      {sale.client.firstName} {sale.client.surname}
                    </TableCell>
                    <TableCell>
                      {format(new Date(sale.momentSale), 'MMM dd, HH:mm')}
                    </TableCell>
                    <TableCell>
                      <Badge variant="info">{sale.details.length} items</Badge>
                    </TableCell>
                    <TableCell className="text-right font-mono font-medium">
                      ${sale.totalSale.toFixed(2)}
                    </TableCell>
                    <TableCell>
                      <Badge variant={sale.statusSale ? 'success' : 'danger'}>
                        {sale.statusSale ? 'Completed' : 'Cancelled'}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
